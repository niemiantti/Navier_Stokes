"""Prepare a 3D snapshot for rendering: Coulomb-gauge vector potential by FFT, the 3D function Psi3 = r A_phi = x A_y - y A_x
(the poloidal flux function where the field is axisymmetric), |B|, and the azimuthal averages of Psi3, B_phi and |B| on an
(r, z) grid.   usage: python3 d3prep.py snap3d.npz out.npz"""
import sys, json, numpy as np
from scipy.ndimage import map_coordinates

fn, out = sys.argv[1], sys.argv[2]
F = np.load(fn, allow_pickle=True)
x, y, z = F["x"].astype(np.float64), F["y"].astype(np.float64), F["z"].astype(np.float64); t = float(F["t"])
B = F["B"].astype(np.float32); nx, ny, nz = B.shape[1:]
hx, hy, hz = x[1] - x[0], y[1] - y[0], z[1] - z[0]
kx = (2 * np.pi * np.fft.fftfreq(nx, d=hx)).astype(np.float32); ky = (2 * np.pi * np.fft.fftfreq(ny, d=hy)).astype(np.float32)
kz = (2 * np.pi * np.fft.rfftfreq(nz, d=hz)).astype(np.float32)
KX, KY, KZ = kx[:, None, None], ky[None, :, None], kz[None, None, :]
K2 = KX**2 + KY**2 + KZ**2; K2[0, 0, 0] = 1.0
Bk = [np.fft.rfftn(B[c]).astype(np.complex64) for c in range(3)]
# A = i k x B / k^2 (Coulomb gauge, zero mean)
Ax = np.fft.irfftn(1j * (KY * Bk[2] - KZ * Bk[1]) / K2, s=(nx, ny, nz)).astype(np.float32)
Ay = np.fft.irfftn(1j * (KZ * Bk[0] - KX * Bk[2]) / K2, s=(nx, ny, nz)).astype(np.float32)
divB = np.fft.irfftn(1j * (KX * Bk[0] + KY * Bk[1] + KZ * Bk[2]), s=(nx, ny, nz)).astype(np.float32)
del Bk
X = x[:, None, None].astype(np.float32); Y = y[None, :, None].astype(np.float32)
Psi3 = X * Ay - Y * Ax; del Ax, Ay
Bmag = np.sqrt((B**2).sum(0))
print(f"t = {t}, grid {nx}x{ny}x{nz}, cells {hx:.4f} {hy:.4f} {hz:.4f}, |B| max {Bmag.max():.4f}, Psi3 max {Psi3.max():.5f}, "
      f"rms div B / rms |B| k {np.sqrt((divB**2).mean()) / np.sqrt((Bmag**2).mean()):.2e}")
# azimuthal averages
rmax = min(-x[0], x[-1], -y[0], y[-1]) - 2 * hx
r = np.arange(0.0, rmax, 0.02); ph = np.linspace(0, 2 * np.pi, 256, endpoint=False)
R, PH = np.meshgrid(r, ph, indexing="ij")
def avg(Fld, fz=None):
    out = np.zeros((len(r), nz), np.float32)
    ix = ((R * np.cos(PH)) - x[0]) / hx; iy = ((R * np.sin(PH)) - y[0]) / hy
    for k in range(nz):
        out[:, k] = map_coordinates(Fld[:, :, k], [ix.ravel(), iy.ravel()], order=1, mode="nearest").reshape(R.shape).mean(axis=1)
    return out
PsiA = avg(Psi3); BmagA = avg(Bmag)
Rr = np.sqrt(X**2 + Y**2) + 1e-6
Bphi = (-B[0] * Y + B[1] * X) / Rr; BphiA = avg(Bphi); del Bphi
# non-axisymmetric part of Psi3 at the scale of the structure: rms over phi of Psi3 - <Psi3>
dev = np.zeros((len(r), nz), np.float32)
ix = ((R * np.cos(PH)) - x[0]) / hx; iy = ((R * np.sin(PH)) - y[0]) / hy
for k in range(nz):
    v = map_coordinates(Psi3[:, :, k], [ix.ravel(), iy.ravel()], order=1, mode="nearest").reshape(R.shape)
    dev[:, k] = v.std(axis=1)
print(f"azimuthal average: Psi max {PsiA.max():.5f}; max over (r, z) of the rms deviation in phi / Psi max = {dev.max() / PsiA.max():.3e}")
np.savez_compressed(out, t=t, x=x, y=y, z=z, Psi3=Psi3.astype(np.float32), Bmag=Bmag.astype(np.float16), r=r, PsiA=PsiA, BphiA=BphiA, BmagA=BmagA,
                    dev=dev, config=str(F["config"]) if "config" in F.files else "")
print("written", out)
