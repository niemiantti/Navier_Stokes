import json, glob, os, sys, numpy as np
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
sys.path.insert(0, B + "/analysis"); import cuspfit as Cf
R = B + "/figures/data/results/"
# --- independent R(beta)
def R_mine(beta):
    beta = abs(beta)
    if beta >= np.sqrt(4/27): return 0.0
    z = np.roots([1, 0, -1, -beta]); z = np.sort(z.real[np.abs(z.imag) < 1e-9])
    f = -z**4/4 + z**2/2 + beta*z
    d1, d2 = f[0]-f[1], f[2]-f[1]; return min(d1, d2)/max(d1, d2)
for b in (0, 0.03, 0.1, 0.2, 0.26, 0.3, 0.38):
    assert abs(R_mine(b) - Cf.cusp_ratio(b)) < 1e-9, b
# check beta_from_points on synthetic roots with shift + scale
for b in (0.05, 0.2, 0.35):
    z = np.sort(np.roots([1, 0, -1, -b]).real); zz = 0.37*z + 1.3
    assert abs(abs(Cf.beta_from_points(*zz)[0]) - b) < 1e-9
print("helper R(beta) and beta_from_points agree with independent implementation")
def Rinv_range(b25, b75):
    bs = np.linspace(b25, b75, 200); v = [R_mine(x) for x in bs]; return min(v), max(v)
res = []
for d in sorted(glob.glob(R + "*/")):
    if "LRref" in d: continue
    s = json.load(open(d + "data/summary.json")); p = json.load(open(d + "data/params.json"))
    ts = (s.get("split") or {}).get("t_s")
    if ts is None: continue
    tr = json.load(open(d + "data/tracks.json"))
    rows = Cf.tracks_beta(tr, t_window=(ts - 0.001, ts + 0.06), dmin=5e-4)[:15]
    b = np.array([r["beta"] for r in rows]); q = np.array([r["ratio"] for r in rows])
    rec0 = [x for x in tr if abs(x["t"] - rows[0]["t"]) < 1e-12][0]
    c = sorted(rec0["cps"], key=lambda x: x["z"]); pm = max(x["psi"] for x in c)
    isl = [min(c[i-1]["psi"], c[i+1]["psi"]) - x["psi"] for i, x in enumerate(c) if x["kind"] == "X" and 0 < i < len(c)-1]
    nisl = sum(1 for v in isl if v > 2e-4*pm)
    bm, qm = np.median(b), np.median(q); b25, b75 = np.percentile(b, [25, 75]); q25, q75 = np.percentile(q, [25, 75])
    Rlo, Rhi = Rinv_range(b25, b75)
    overlap = (Rhi >= q25) and (Rlo <= q75)
    res.append(dict(name=os.path.basename(d[:-1])[:26], eps=p["eps_b"], eta=p["eta"], n=len(rows), nisl=nisl, isl=sorted(isl, reverse=True)[:4], beta=bm, b25=b25, b75=b75,
                    ratio=qm, q25=q25, q75=q75, R=R_mine(bm), dev=qm - R_mine(bm), Rlo=Rlo, Rhi=Rhi, overlap=overlap, span=rows[-1]["t"] - rows[0]["t"], t0=rows[0]["t"], ts=ts))
res.sort(key=lambda r: (-r["eta"], r["eps"], r["name"]))
for r in res:
    print(f"{r['name']:26s} eps={r['eps']:>5g} eta={r['eta']:<5g} n={r['n']} nisl={r['nisl']} isl={np.round(r['isl'],5)} t0-ts={r['t0']-r['ts']:+.4f} span={r['span']:.4f} "
          f"beta={r['beta']:.3f}[{r['b25']:.3f},{r['b75']:.3f}] ratio={r['ratio']:.3f}[{r['q25']:.3f},{r['q75']:.3f}] R(beta_med)={r['R']:.3f} dev={r['dev']:+.3f} R(IQRbeta)=[{r['Rlo']:.3f},{r['Rhi']:.3f}] overlap={r['overlap']}")
print("window span range: %.4f - %.4f" % (min(r['span'] for r in res if 'legacy' not in r['name'] or 'd5fc' in r['name']), max(r['span'] for r in res)))
