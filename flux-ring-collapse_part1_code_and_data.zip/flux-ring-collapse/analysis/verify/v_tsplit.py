import json, glob, os, numpy as np
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
R = B + "/figures/data/results/"
def resolve(cps, dz=16.0/1024, dmin=1e-3, cells=3):   # copy of fig3.py resolve()
    c = sorted(cps, key=lambda q: q["z"])
    while True:
        worst = None
        for i, q in enumerate(c):
            if q["kind"] != "X" or i == 0 or i == len(c) - 1: continue
            lo, hi = c[i-1], c[i+1]; d = min(lo["psi"], hi["psi"]) - q["psi"]; sh = lo if lo["psi"] < hi["psi"] else hi
            sc = min(d/dmin, abs(sh["z"]-q["z"])/(cells*dz))
            if sc < 1 and (worst is None or sc < worst[0]): worst = (sc, i, c.index(sh))
        if worst is None: return c
        i, j = sorted(worst[1:]); del c[j]; del c[i]
out = []
for d in sorted(glob.glob(R + "*/")):
    if "LRref" in d or "d87ab6" in d: continue
    s = json.load(open(d + "data/summary.json")); p = json.load(open(d + "data/params.json"))
    ts = (s.get("split") or {}).get("t_s")
    tr = [q for q in json.load(open(d + "data/tracks.json")) if q["t"] <= 1.0 + 1e-9]
    first = next((q for q in tr if sum(x["kind"] == "X" for x in resolve(q["cps"])) >= 1), None)
    # depth-only (1e-3) without width
    first_d = next((q for q in tr if any(x["kind"] == "X" for x in resolve(q["cps"], cells=1e-9))), None)
    out.append((p["eta"], p["eps_b"], ts, first["t"] if first else None, first_d["t"] if first_d else None))
out.sort(key=lambda r: (-r[0], r[1]))
print("eta eps  t_s(plotted)  first resolved (>=1e-3 & >=3 cells, fig3 resolve)  first >=1e-3 (any width)")
for r in out:
    f = lambda v: "none" if v is None else f"{v:.4f}"
    print(f"{r[0]:<5g} {r[1]:>5g}  {f(r[2])}  {f(r[3])}  {f(r[4])}")
