# Three-dimensional code (mhd3d_vs2, solver version 2.0)

`mhd3d_vs2.py` solves the same equations as the axisymmetric code in a periodic Cartesian box, pseudo-spectral with
N x N x Nz points, 2/3 dealiasing and SSP-RK3 time stepping with an integrating factor for the diffusion terms and
the Alfvén speed in the CFL condition. The background flow and the seed are the axisymmetric ones, evaluated on an
(r, z) table with the kernel `../axisymmetric/openai_mhd_3d.py` (imported from there; the only change from the
version that produced the runs is this import path) and mapped to the cube, with the background tapered to zero
before the box faces. A random, smooth, solenoidal magnetic perturbation of relative L2 amplitude 1e-3 is added to
the seed. The release at t = 1 transfers the Fourier representation of the background to the response.

Runs of the paper (configurations in `../runs/three_dimensional/`):

    python3 mhd3d_vs2.py --preset e50_eta0.01       # eps_B = 50, eta = 0.01, box |x|,|y| < 4, |z| < 5.5, 256^3, t = 0 to 4
    python3 mhd3d_vs2.py --preset e1000_eta0.05     # eps_B = 1000, eta = 0.05, box |x|,|y| < 5, |z| < 7, 256^3, t = 0 to 4
    python3 mhd3d_vs2.py --extend runs/e50_eta0.01_nu0.1_N256_box4x4x5.5 --set N=320 --set Nz=384 --set "box=[5.0,5.0,8.25]" --set t_end=8 --set "snap_times=[5,6,7,8]"

The third line continues the first run from t = 4 to 8 in the larger box with the same cells (Supplementary Note 7
and Supplementary Movie 3). Any entry of the configuration can be changed with `--set key=value`; `--resume RUNDIR`
continues an interrupted run. A quick test: `--preset e50_eta0.01 --set N=64 --set t_end=0.1 --set table_nr=128 --set table_nz=256`.

Outputs in `runs/<name>/`: `diag.csv` (energies, helicity, peak values and the fractions of the magnetic energy in
the azimuthal modes m = 1 to 4 and in all m >= 1, measured inside r < 2 and |z| < 0.8 L_z, every 0.02),
`avg2d_t*.npz` (azimuthal averages of the field and the velocity every 0.1), `snap3d_t*.npz` (full field and
velocity at the snapshot times) and checkpoints.

Cost: each step is 54 FFTs of N x N x Nz. With torch on a GPU expect 1–2 s per step at 256^3, on the CPU path
(scipy.fft) about 10 s; a run to t = 4 needs 6000–9000 steps. Memory about 6 GB at 256^3, 14 GB at 320 x 320 x 384.

`make_movie_vs2.py` draws the Supplementary Movies from the azimuthal averages (needs pyvista, contourpy, pillow
and ffmpeg):

    python3 make_movie_vs2.py out.mp4 "title" 3.0 7.0 runs/e50_eta0.01_nu0.1_N256_box4x4x5.5 runs/ext_e50_eta0.01_nu0.1_N320x384_box5x5x8.25
