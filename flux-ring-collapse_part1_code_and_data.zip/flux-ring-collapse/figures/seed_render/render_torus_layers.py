"""The initial torus in 3D with the colour code of the movies (make_movie_vs2.py): flux surfaces at 90, 60 and 30 % of the ring's
private flux (red, orange, green) and the outermost surface at 5 % of the peak flux (translucent blue), revolved about the axis
with the staircase cut-away (1.85, 1.6, 1.35, 1.1 pi), orthographic camera of the movies. Optional field lines (dark).
usage: python3 render_torus_layers.py W H out.png [scale] [nlines]"""
import sys, numpy as np, contourpy, pyvista as pv
from matplotlib.path import Path
from scipy.ndimage import map_coordinates
sys.path.insert(0, __file__.rsplit("/", 1)[0] if "/" in __file__ else ".")
from seed import fields
pv.OFF_SCREEN = True
try: pv.start_xvfb()
except Exception: pass
W, H, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
scale = float(sys.argv[4]) if len(sys.argv) > 4 else 1.12
nlines = int(sys.argv[5]) if len(sys.argv) > 5 else 0

r = np.linspace(0, 1.2, 1201); z = np.linspace(-1.2, 1.2, 2401); R, Z = np.meshgrid(r, z, indexing="ij")
Psi, Br, Bz, Bphi = fields(R, Z)
Pmax = Psi.max(); im = np.unravel_index(np.argmax(Psi), Psi.shape); axis = (r[im[0]], z[im[1]])
gen = contourpy.contour_generator(r, z, Psi.T)
# as in make_movie_vs2.py for a ring that is alone: its private flux runs from the axis down to the 5 % floor
d_eff = 0.95
import os
# opacities (blue, green, orange, red): the movies use 0.55, 1, 1, 1; OPAC=v2 gives the translucent sheets of the earlier panel
OP = (0.38, 0.50, 0.62, 0.85) if os.environ.get("OPAC") == "v2" else (0.55, 1.0, 1.0, 1.0)
LAYERS = ((0.9, "#d7301f", OP[3], 1.85), (0.6, "#fc8d59", OP[2], 1.6), (0.3, "#41ab5d", OP[1], 1.35))
surfaces = [(min((sg for sg in gen.lines(0.05 * Pmax) if len(sg) > 8), key=lambda a: -len(a)), "#6baed6", OP[0], 1.1)]
for frac, col, al, ang in LAYERS:
    lev = Pmax - (1 - frac) * d_eff * Pmax
    segs = [sg for sg in gen.lines(lev) if len(sg) > 8 and Path(sg).contains_point(axis)]
    surfaces.append((min(segs, key=len), col, al, ang))

p = pv.Plotter(off_screen=True, window_size=(W, H), lighting="three lights"); p.set_background("white")
if OP[1] < 1.0:
    try: p.enable_depth_peeling(number_of_peels=12, occlusion_ratio=0.0)
    except Exception as e: print("no depth peeling:", e)
for seg, col, al, ang in surfaces:
    rs, zs = seg[:, 0], seg[:, 1]; PH = np.linspace(0, ang * np.pi, 160)
    X = rs[:, None] * np.cos(PH)[None, :]; Y = rs[:, None] * np.sin(PH)[None, :]; Zc = np.repeat(zs[:, None], len(PH), axis=1)
    p.add_mesh(pv.StructuredGrid(X, Y, Zc), color=col, opacity=al, smooth_shading=True, specular=0.4, specular_power=20)
if nlines:
    # magnetic field lines as in the earlier version of the panel: seeded on the midplane on five flux surfaces (12-90 % of
    # the peak flux), traced along B, drawn as tubes coloured by |B| (YlOrBr); they wind helically on their surfaces and are
    # hidden where an opaque layer lies in front of them, so each is seen where its surface is cut open
    Bmag = np.sqrt(Br**2 + Bz**2 + Bphi**2); bmax = float(Bmag.max())
    import matplotlib; from matplotlib.colors import LinearSegmentedColormap
    LINE_CMAP = LinearSegmentedColormap.from_list("ylorbr_sat", matplotlib.colormaps["YlOrBr"](np.linspace(0.30, 0.95, 256)))
    dr_, dz_ = r[1] - r[0], z[1] - z[0]
    def smp(F, rr, zz): return map_coordinates(F, np.array([rr / dr_, (zz - z[0]) / dz_]), order=1, mode="nearest")
    def vel(q):
        br = smp(Br, q[:, 0], q[:, 1]); bz = smp(Bz, q[:, 0], q[:, 1]); bp = smp(Bphi, q[:, 0], q[:, 1])
        m = np.sqrt(br**2 + bz**2 + bp**2) + 1e-12
        return np.c_[br / m, bz / m, bp / (m * np.maximum(q[:, 0], 0.02))]
    prof = Psi[:, im[1]]; i0 = im[0]
    fr = (0.12, 0.30, 0.50, 0.70, 0.90)[:nlines]
    q = np.array([[r[i0 + np.argmin(np.abs(prof[i0:] - f * Pmax))], axis[1], 0.0] for f in fr]); P = [q.copy()]; ds = 0.004
    for _ in range(int(14 / ds)):
        k1 = vel(q); k2 = vel(q + 0.5 * ds * k1); k3 = vel(q + 0.5 * ds * k2); k4 = vel(q + ds * k3)
        q = q + ds * (k1 + 2 * k2 + 2 * k3 + k4) / 6; P.append(q.copy())
    P = np.array(P)
    for j in range(P.shape[1]):
        L = P[:, j][::3]; XYZ = np.c_[L[:, 0] * np.cos(L[:, 2]), L[:, 0] * np.sin(L[:, 2]), L[:, 1]]
        poly = pv.lines_from_points(XYZ); poly["B"] = smp(Bmag, L[:, 0], L[:, 1])
        p.add_mesh(poly.tube(radius=0.009, n_sides=10), scalars="B", cmap=LINE_CMAP, clim=(0.0, bmax),
                   smooth_shading=True, specular=0.3, show_scalar_bar=False)
p.enable_parallel_projection()
p.camera_position = [(0.3 * 10, -4.0 * 10, 0.9 * 10), (0, 0, 0), (0, 0, 1)]; p.camera.focal_point = (0, 0, 0)
p.camera.parallel_scale = scale
p.enable_anti_aliasing("ssaa"); p.screenshot(out); p.close()
print("written", out, "Psi_max %.5f axis r = %.3f" % (Pmax, axis[0]))
