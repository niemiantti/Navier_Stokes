# Use of AI tools

The simulation codes (`axisymmetric/`, `three_dimensional/`), the analysis scripts (`analysis/`) and the figure
scripts (`figures/`) in this repository were written with the assistance of large language models (Anthropic Claude)
under the direction of the author, who specified the model, the numerical choices, the diagnostics and the figures,
and who reviewed the code. All simulations were run by the author on local hardware. The author takes full
responsibility for the code and for the results obtained with it.
