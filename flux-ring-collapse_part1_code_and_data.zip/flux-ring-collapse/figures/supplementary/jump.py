"""The acceleration jump at the release, evaluated with the production kernel on the production lattice.
[d_t zeta] = -(U.grad) zeta_U + d_z(Omega_U^2) + nu L5 zeta_U,  [d_t Omega] = -(U.grad) Omega_U - 2 alpha_U Omega_U + nu L5 Omega_U,
compared with the fields themselves and with the pre-release accelerations d_t U = -(tau/tau_e) d_{tau_e} U."""
import sys, os, json, numpy as np
from paths import *
import openai_mhd_3d as mhd, configuration as cfg
from silib import params_of

d = params_of(50, 0.05); p = cfg.make_params(d); p.t_off = 1.0e9
g = mhd.Grid(p, build_poisson=True)
r = g.rc; dV = g.dV; nu = p.nu
print("lattice", p.nr, p.nz, "box", p.rbox, p.zbox, "nu", nu, "tau_f", p.tau_f)

def fields(tau):
    bg = g.background_terms(tau)
    return bg

def vel_from_zeta(zeta):
    Sx = g.solve_poisson(zeta); Sg = g.pad(Sx)
    return -r * g.ddz(Sg), 2 * Sx + r * g.ddr(Sg)

def norms(Ur, Uz, Up):
    return np.sqrt(np.sum((Ur**2 + Uz**2 + Up**2) * dV)), np.sqrt((Ur**2 + Uz**2 + Up**2).max())

bg = fields(0.0)
Ur, Uz, OU, zU, aU = bg["Ur"], bg["Uz"], bg["OU"], bg["zetaU"], bg["alphaU"]
Up = r * OU
# the jump of the vorticity and swirl rates (the Helmholtz rates of the frozen imposed flow)
zg = g.pad(zU); OUg = g.pad(OU, "odd", "even")
dz_dt = -g.advect(zg, Ur, Uz) + g.ddz(g.pad(OU**2, "odd", "even")) + nu * g.L5(zg)
da_dt = -g.advect(OUg, Ur, Uz) - 2.0 * aU * OU + nu * g.L5(OUg)
# the corresponding velocity rates: poloidal from the Poisson solve, azimuthal r*da_dt
dUr, dUz = vel_from_zeta(dz_dt); dUp = r * da_dt
nU, mU = norms(Ur, Uz, Up); nA, mA = norms(dUr, dUz, dUp)
K = 0.5 * nU**2
print(f"t = 1: ||U||_2 = {nU:.4g} (K_U = {K:.4g}), max|U| = {mU:.3g}")
print(f"jump [d_t U]: ||.||_2 = {nA:.4g}, max = {mA:.4g};  time scale ||U||/||[d_t U]|| = {nU/nA:.4f}")
# split: poloidal and swirl parts
nUp_, _ = norms(Ur, Uz, 0*Up); nUs, _ = norms(0*Ur, 0*Uz, Up)
nAp, mAp = norms(dUr, dUz, 0*dUp); nAs, mAs = norms(0*dUr, 0*dUz, dUp)
print(f"  poloidal: ||U_p|| = {nUp_:.4g}, ||[d_t U_p]|| = {nAp:.4g} (max {mAp:.3g}), T = {nUp_/nAp:.4f}")
print(f"  swirl:    ||U_phi|| = {nUs:.4g}, ||[d_t U_phi]|| = {nAs:.4g} (max {mAs:.3g}), T = {nUs/nAs:.4f}")
# vorticity: omega_phi = r zeta
om = r * zU; dom = r * dz_dt
print(f"  omega_phi: ||omega|| = {np.sqrt(np.sum(om**2*dV)):.4g}, ||[d_t omega]|| = {np.sqrt(np.sum(dom**2*dV)):.4g}, T = {np.sqrt(np.sum(om**2*dV))/np.sqrt(np.sum(dom**2*dV)):.4f}, max|omega| = {np.abs(om).max():.3g}")
# where is the jump concentrated: fraction of ||[d_t U]||^2 inside r < 1.5 and |z| < 1
m = (r < 1.5) & (np.abs(g.z)[None, :] < 1.0)
frac = np.sum(((dUr**2 + dUz**2 + dUp**2) * dV)[m]) / nA**2
print(f"  fraction of the jump energy inside r < 1.5, |z| < 1: {frac:.3f}")
# the viscous part alone
dUr_v, dUz_v = vel_from_zeta(nu * g.L5(zg)); dUp_v = r * nu * g.L5(OUg)
nAv, mAv = norms(dUr_v, dUz_v, dUp_v); print(f"  viscous part alone: ||nu lap U|| = {nAv:.4g} (max {mAv:.3g})")
# the inertial part alone
dUr_i, dUz_i = vel_from_zeta(-g.advect(zg, Ur, Uz) + g.ddz(g.pad(OU**2, "odd", "even"))); dUp_i = r * (-g.advect(OUg, Ur, Uz) - 2.0 * aU * OU)
nAi, mAi = norms(dUr_i, dUz_i, dUp_i); print(f"  inertial part alone: ||P(U x omega)|| = {nAi:.4g} (max {mAi:.3g})")
# pre-release accelerations of the imposed flow: d_t U = -(tau/tau_e) dU/dtau_e, by finite differences in tau
print("pre-release Eulerian acceleration of the imposed flow, d_t U = -dU/dtau:")
out = dict(t1=dict(normU=nU, K=K, maxU=mU, jump_norm=nA, jump_max=mA, T=nU/nA, pol=dict(normU=nUp_, jump=nAp, T=nUp_/nAp), swirl=dict(normU=nUs, jump=nAs, T=nUs/nAs),
                   viscous_norm=nAv, inertial_norm=nAi, frac_core=frac), pre=[])
for tau in (0.5, 0.3, 0.2, 0.1, 0.07, 0.05, 0.03, 0.02, 0.01, 0.005):
    h = 1e-3 * max(tau, 0.01)
    b1, b2 = fields(tau + h), fields(tau - h)
    dUr_t = -(b1["Ur"] - b2["Ur"]) / (2 * h); dUz_t = -(b1["Uz"] - b2["Uz"]) / (2 * h); dUp_t = -r * (b1["OU"] - b2["OU"]) / (2 * h)
    b0 = fields(tau); n0, m0 = norms(b0["Ur"], b0["Uz"], r * b0["OU"]); n1, m1 = norms(dUr_t, dUz_t, dUp_t)
    # material acceleration D_t U = d_t U + (U.grad)U: its solenoidal part equals d_t U + P[(U.grad)U] = d_t U - P[U x omega]
    print(f"  t = {1-tau:.3f}: ||d_t U|| = {n1:.4g} (max {m1:.3g}), ||U|| = {n0:.4g}, T = ||U||/||d_t U|| = {n0/n1:.4f}, tau_e = {np.sqrt(tau**2+p.tau_f**2):.4f}")
    out["pre"].append(dict(t=1 - tau, tau=tau, norm_dtU=n1, max_dtU=m1, normU=n0, T=n0/n1))
json.dump(out, open(HERE + "/jump.json", "w"), indent=1)
