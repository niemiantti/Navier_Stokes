#!/usr/bin/env python3
"""
make_movie_vs2.py - movie of an mhd3d_vs2 run (or of a chain of runs: the t = 0-4 run and its --extend continuations)
from the azimuthal averages avg2d_t*.npz, showing the magnetic structure together with the swirling fluid.

  left : meridional section (matplotlib). Four coloured flux layers per magnetic ring (red 90 %, orange 60 %, green 30 %
         of the ring's private flux, measured from its axis down to the pass that separates it from the others; blue =
         the 5 % outermost surface), thin black flux surfaces, the magnetic axes in gold, and the fluid as thin light-blue
         filaments: streamlines of the meridional velocity (Vr, Vz), slightly thicker where the fluid moves faster.
  right: the same flux surfaces revolved about the axis with a staircase cut-away (pyvista, orthographic projection with
         the same vertical scale as the section), and the fluid as thin light-blue filaments in three dimensions:
         streamlines of the full velocity (Vr, Vphi, Vz) seeded around the structure, which wind around the axis where
         the fluid swirls.

usage:  python3 make_movie_vs2.py out.mp4 "title" rwin zwin rundir [rundir2 rundir3 ...]
        rwin, zwin: half-width and half-height of the window in world units (e.g. 3.0 7.0 for the eps_B = 50 run to t = 8).
        Several run directories (a run and its extensions) are joined in time; all frames are put on the (r, z) grid of
        the last directory, which has the largest box. The velocity is read from the avg2d files written by
        mhd3d_vs2.py (Vr, Vphi, Vz); files without it (old mhd3d runs) are drawn without the fluid.
        Frames are cached in frames_<out>/ so an interrupted rendering continues where it stopped (delete the folder to
        re-render). Environment: SUB=4 interpolated frames between stored averages (24 frames/s), NSEED=3 azimuthal
        seeds per position of the 3D filaments, TUBE=0.006 their radius, LEN3D=7 their length (units of zwin/5),
        FLOW=0 switches the fluid off on both panels, FLOW3D=0 only on the right one (3D) panel.
"""
import sys, glob, os, numpy as np, contourpy, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.path import Path
from scipy import ndimage
from scipy.ndimage import map_coordinates
from scipy.interpolate import RegularGridInterpolator
import pyvista as pv
from PIL import Image, ImageDraw, ImageFont

pv.OFF_SCREEN = True
try:
    pv.start_xvfb()
except Exception:
    pass
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})

# ----------------------------------------------------------------------------------------------------- flux maxima
def persistence_rings(P, r, z, r_lim):
    """Every flux maximum (5x5 local maximum above 1 % of the peak) with its depth: peak minus the highest pass
    (saddle) that connects it to a higher maximum, from a union-find sweep over the levels of Psi (4-connectivity)."""
    nr_, nz_ = P.shape; flat = P.ravel(); N = flat.size
    order = np.argsort(-flat, kind="stable")
    parent = np.full(N, -1, dtype=np.int64); top = np.zeros(N, dtype=np.int64)
    death = {}

    def find(i):
        root = i
        while parent[root] != root:
            root = parent[root]
        while parent[i] != root:
            parent[i], i = root, parent[i]
        return root
    for idx in order:
        parent[idx] = idx; top[idx] = idx
        i, j = divmod(int(idx), nz_)
        roots = set()
        for ii, jj in ((i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)):
            if 0 <= ii < nr_ and 0 <= jj < nz_:
                n = ii * nz_ + jj
                if parent[n] != -1:
                    roots.add(find(n))
        if roots:
            best = max(roots, key=lambda q: flat[top[q]])
            for q in roots:
                if q != best:
                    death[int(top[q])] = float(flat[idx]); parent[q] = best
            parent[idx] = best
    pmax = flat.max()
    mx = (P == ndimage.maximum_filter(P, size=5)) & (P > 0.01 * pmax)
    rings = []
    for i, j in zip(*np.nonzero(mx)):
        k = i * nz_ + j
        if k in death and r[i] <= r_lim:
            rings.append(dict(depth=float((flat[k] - death[k]) / pmax), r=float(r[i]), z=float(z[j])))
    return sorted(rings, key=lambda x: -x["depth"])

# ----------------------------------------------------------------------------------------------------- input
if len(sys.argv) < 6:
    print(__doc__); sys.exit(1)
out, title = sys.argv[1], sys.argv[2]; rwin = float(sys.argv[3]); zwin = float(sys.argv[4]); rundirs = sys.argv[5:]
SUB = int(os.environ.get("SUB", "4")); NSEED = int(os.environ.get("NSEED", "2")); FLOW = os.environ.get("FLOW", "1") != "0"; FLOW3D = os.environ.get("FLOW3D", "1") != "0"
TUBE = float(os.environ.get("TUBE", "0.006")); LEN3D = float(os.environ.get("LEN3D", "7.0"))      # filament radius and length (units of zwin/5; TUBE=0.011 was the thick dark first version)
FIELDS = ("Psi", "Bphi", "Br", "Bz", "Vr", "Vphi", "Vz", "PsiV")

files = {}                                                      # t -> file; later directories override earlier ones
for d in rundirs:
    fs = glob.glob(os.path.join(d, "avg2d_t*.npz"))
    if not fs:
        sys.exit(f"no avg2d_t*.npz in {d}")
    for f in fs:
        files[round(float(os.path.basename(f)[7:-4]), 4)] = f
T = np.array(sorted(files)); files = [files[t] for t in T]
ref = np.load(files[-1]); r, z = ref["r"].astype(float), ref["z"].astype(float)       # common grid: the last (largest) run
RR, ZZ = np.meshgrid(r, z, indexing="ij")
have_flow = FLOW and all("Vr" in np.load(f).files for f in files)
if FLOW and not have_flow:
    print("note: some avg2d files carry no velocity (written by mhd3d, not mhd3d_vs2); the fluid is not drawn")
_cache = {}

def frame(i):
    """the i-th stored average on the common grid (resampled if the run had a smaller box)"""
    if i in _cache:
        return _cache[i]
    a = np.load(files[i]); same = a["Psi"].shape == ref["Psi"].shape and np.allclose(a["r"], r) and np.allclose(a["z"], z)
    F = {}
    for k in FIELDS:
        if k not in a.files:
            continue
        F[k] = a[k].astype(np.float32) if same else RegularGridInterpolator((a["r"].astype(float), a["z"].astype(float)), a[k].astype(float),
                                                                            bounds_error=False, fill_value=0.0)(np.c_[RR.ravel(), ZZ.ravel()]).reshape(RR.shape).astype(np.float32)
    for k in list(_cache):
        if k < i - 1:
            del _cache[k]
    _cache[i] = F
    return F

tt = [(i, k / SUB) for i in range(len(T) - 1) for k in range(SUB)] + [(len(T) - 1, 0.0)]
LAYERS = ((0.9, "#d7301f", 1.0, 1.85), (0.6, "#fc8d59", 1.0, 1.6), (0.3, "#41ab5d", 1.0, 1.35), (None, "#6baed6", 0.55, 1.1))   # (level, colour, opacity, angle/pi)
ORDER = {LAYERS[3][1]: 0, LAYERS[2][1]: 1, LAYERS[1][1]: 2, LAYERS[0][1]: 3}
FLUID = "#4dabf7"; FLUID3D = "#74c0fc"
fdir = "frames_" + os.path.splitext(os.path.basename(out))[0]; os.makedirs(fdir, exist_ok=True)
H = 640; WL = 560; WR = 560
dr_, dz_ = r[1] - r[0], z[1] - z[0]
print(f"{len(T)} stored averages, t = {T[0]:g} .. {T[-1]:g}, {len(tt)} frames, grid r < {r[-1]:.2f}, |z| < {z[-1]:.2f}, fluid: {have_flow}", flush=True)

for n, (i, w) in enumerate(tt):
    if os.path.exists(f"{fdir}/f{n:04d}.png"):
        continue
    A, B = frame(i), frame(min(i + 1, len(T) - 1))
    mix = lambda k: (1 - w) * A[k] + w * B[k]
    Psi, Bphi = mix("Psi"), mix("Bphi"); t = (1 - w) * T[i] + w * T[min(i + 1, len(T) - 1)]
    # ---- rings and the four layers of each
    rings = persistence_rings(Psi, r, z, 4.5); im = np.unravel_index(np.argmax(Psi), Psi.shape)
    axes = [(r[im[0]], z[im[1]])] + [(q["r"], q["z"]) for q in rings if q["depth"] >= 0.05]
    gen = contourpy.contour_generator(r, z, Psi.T)
    items = [(axes[0], 1.0, True)] + [((q["r"], q["z"]), q["depth"], False) for q in rings if q["depth"] >= 0.05]
    surfaces = []
    for seg in gen.lines(0.05 * Psi.max()):
        if len(seg) > 8:
            surfaces.append((seg,) + LAYERS[3][1:])
    # each ring's layers span its own private flux: from its axis down to the pass that separates it from the others
    # (for the main ring, the highest pass of the secondary rings; the 5 % floor if it is alone)
    sec = [(Psi[np.argmin(abs(r - q["r"])), np.argmin(abs(z - q["z"]))] - q["depth"] * Psi.max()) for q in rings if q["depth"] >= 0.05]
    p_pass = max(sec) if sec else 0.05 * Psi.max()
    for (pt, dep, main) in items:
        pO = Psi[np.argmin(abs(r - pt[0])), np.argmin(abs(z - pt[1]))]
        d_eff = (pO - p_pass) / Psi.max() if main else dep
        for frac, col, al, ang in LAYERS[:3]:
            lev = pO - (1 - frac) * d_eff * Psi.max()
            segs = [sg for sg in gen.lines(lev) if len(sg) > 8 and Path(sg).contains_point(pt)]
            if segs:
                surfaces.append((min(segs, key=len), col, al, ang))
    # extent of the structure (outermost surface), used to seed the 3D filaments around it
    outer = [s for s in surfaces if s[1] == LAYERS[3][1]]
    if outer:
        allp = np.vstack([s[0] for s in outer]); r_ext = min(max(allp[:, 0].max(), 0.3 * rwin), rwin); z_lo, z_hi = max(allp[:, 1].min(), -zwin), min(allp[:, 1].max(), zwin)
    else:
        r_ext, z_lo, z_hi = 0.6 * rwin, -0.6 * zwin, 0.6 * zwin
    if have_flow:
        Vr, Vz, Vphi = mix("Vr"), mix("Vz"), mix("Vphi")
    # ---- left panel: section
    fig = plt.figure(figsize=(WL / 100, H / 100), dpi=100); a = fig.add_axes([0.17, 0.08, 0.80, 0.84])
    m = r <= rwin; nz = np.abs(z) <= zwin; rr = np.concatenate([-r[m][::-1], r[m]])
    PP = np.concatenate([Psi[m][::-1], Psi[m]])[:, nz]
    for seg, col, al, ang in sorted(surfaces, key=lambda u: ORDER[u[1]]):       # outer layer first, inner on top
        alpha = 0.5 if ORDER[col] == 0 else 0.9
        a.fill(seg[:, 0], seg[:, 1], color=col, alpha=alpha, lw=0); a.fill(-seg[:, 0], seg[:, 1], color=col, alpha=alpha, lw=0)
    if Psi.max() > 0:
        a.contour(rr, z[nz], PP.T, levels=np.linspace(0.05, 0.98, 14) * Psi.max(), colors="k", linewidths=0.35)
    if have_flow:
        VR = np.concatenate([-Vr[m][::-1], Vr[m]])[:, nz]; VZ = np.concatenate([Vz[m][::-1], Vz[m]])[:, nz]
        sp = np.hypot(VR, VZ); lw = 0.3 + 0.9 * np.sqrt(sp / max(sp.max(), 1e-9))
        st = a.streamplot(rr, z[nz], VR.T, VZ.T, density=(1.0, 1.6), color=FLUID, linewidth=lw.T, arrowsize=0.55, arrowstyle="-|>",
                          broken_streamlines=True, minlength=0.15)
        st.lines.set_path_effects([pe.Stroke(linewidth=1.8, foreground="white", alpha=0.9), pe.Normal()]); st.lines.set_zorder(4); st.arrows.set_zorder(4)
    for (ra, za) in axes:
        a.plot([ra, -ra], [za, za], "o", color="gold", mec="k", ms=6, zorder=5)
    a.set_aspect("equal"); a.set_xlim(-rwin, rwin); a.set_ylim(-zwin, zwin); a.set_xlabel("r (mirrored)"); a.set_ylabel("z")
    a.set_title(f"t = {t:.2f}" + ("   (collapse, flow imposed)" if t < 1.0 - 1e-9 else "   (released)"), fontsize=11, loc="left")
    fig.savefig(f"{fdir}/_left.png"); bb = a.get_window_extent(); plt.close(fig)
    y_top = int(H - bb.y1); y_bot = int(H - bb.y0); hpx = y_bot - y_top          # pixel rows of the z range on the left
    # ---- right panel: pyvista, parallel projection with the same vertical scale
    p = pv.Plotter(off_screen=True, window_size=(WR, hpx), lighting="three lights"); p.set_background("white")
    for seg, col, al, ang in surfaces:
        rs, zs = seg[:, 0], seg[:, 1]; PH = np.linspace(0, ang * np.pi, 60)
        X = rs[:, None] * np.cos(PH)[None, :]; Y = rs[:, None] * np.sin(PH)[None, :]; Z = np.repeat(zs[:, None], len(PH), axis=1)
        p.add_mesh(pv.StructuredGrid(X, Y, Z), color=col, opacity=al, smooth_shading=True, specular=0.4, specular_power=20)
    if have_flow and FLOW3D:
        def vel(q):
            """unit tangent of the velocity in (r, z, phi) coordinates, and the speed"""
            idx = np.array([q[:, 0] / dr_ - 0.5, (q[:, 1] - z[0]) / dz_])
            ur = map_coordinates(Vr, idx, order=1, mode="nearest"); uz = map_coordinates(Vz, idx, order=1, mode="nearest"); up = map_coordinates(Vphi, idx, order=1, mode="nearest")
            sp = np.sqrt(ur**2 + uz**2 + up**2) + 1e-12
            return np.c_[ur / sp, uz / sp, up / (sp * np.maximum(q[:, 0], 0.05))], sp
        win = (r <= rwin)[:, None] & (np.abs(z) <= zwin)[None, :]
        vref = float(np.percentile(np.sqrt(Vr**2 + Vz**2 + Vphi**2)[win], 98))
        # seeds around the structure: three radii and four heights relative to its extent, NSEED azimuths each
        zc, zh = 0.5 * (z_lo + z_hi), 0.5 * (z_hi - z_lo)
        S0 = np.array([[rs * r_ext, zc + zs * zh, ph] for rs in (0.35, 0.7, 1.05) for zs in (-0.85, -0.3, 0.3, 0.85)
                       for ph in np.linspace(0.4, 0.4 + 2 * np.pi, NSEED, endpoint=False)])
        ds = 0.03 * zwin / 5.0; nstep = int(LEN3D * zwin / 5.0 / ds)
        lines = []
        for sgn in (1.0, -1.0):
            q = S0.copy(); alive = np.ones(len(q), bool); paths = [q.copy()]
            for _ in range(nstep):
                k1, s1 = vel(q); k2, _ = vel(q + 0.5 * ds * sgn * k1); k3, _ = vel(q + 0.5 * ds * sgn * k2); k4, _ = vel(q + ds * sgn * k3)
                qn = q + ds * sgn * (k1 + 2 * k2 + 2 * k3 + k4) / 6
                alive &= (qn[:, 0] < rwin) & (np.abs(qn[:, 1]) < zwin) & (s1 > 0.015 * vref) & (qn[:, 0] > 0.0)
                q = np.where(alive[:, None], qn, q); paths.append(q.copy())
                if not alive.any():
                    break
            P = np.array(paths)                                                # (steps, seeds, 3)
            for j in range(P.shape[1]):
                L = P[:, j]; keep = np.r_[True, np.any(np.diff(L, axis=0) != 0, axis=1)]; L = L[keep]
                if len(L) < 5:
                    continue
                lines.append(np.c_[L[:, 0] * np.cos(L[:, 2]), L[:, 0] * np.sin(L[:, 2]), L[:, 1]])
        if lines:
            pts = np.vstack(lines); cells = []; off = 0
            for L in lines:
                cells += [len(L)] + list(range(off, off + len(L))); off += len(L)
            poly = pv.PolyData(pts); poly.lines = np.array(cells)
            p.add_mesh(poly.tube(radius=TUBE * zwin / 5.0, n_sides=6), color=FLUID3D, ambient=0.55, diffuse=0.5, specular=0.0, smooth_shading=True)
    p.enable_parallel_projection(); p.camera_position = [(0.3, -4.0, 0.9), (0, 0, 0), (0, 0, 1)]; p.camera.focal_point = (0, 0, 0)
    p.camera.position = (0.3 * 10, -4.0 * 10, 0.9 * 10); p.camera.parallel_scale = zwin       # half-height of the view in world units
    p.enable_anti_aliasing("ssaa"); p.screenshot(f"{fdir}/_right.png"); p.close()
    canvas = Image.new("RGB", (WL + WR, H), "white"); canvas.paste(Image.open(f"{fdir}/_left.png"), (0, 0)); canvas.paste(Image.open(f"{fdir}/_right.png"), (WL, y_top))
    d = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
    except Exception:
        font = ImageFont.load_default()
    d.text((WL + 20, 12), title, fill="black", font=font)
    canvas.save(f"{fdir}/f{n:04d}.png")
    if n % 20 == 0:
        print("frame", n, "of", len(tt), "t =", round(t, 3), flush=True)
os.system(f"ffmpeg -y -loglevel error -framerate 24 -i {fdir}/f%04d.png -c:v libx264 -pix_fmt yuv420p -crf 26 -vf 'scale=trunc(iw/2)*2:trunc(ih/2)*2' {out}")
print("written", out, os.path.getsize(out) // 1024, "kB")
