"""Compare the protocol-test runs (sudden control, ramps) with the original eps_B = 1000, eta = 0.05 run:
energies K, M, H against time, and the pair events on the flux ridge (changes of N_O, N_X of the resolved points)."""
import sys, os, json, glob, csv, numpy as np
from paths import *
from silib import resolve, diag_of, tracks_of

def rd(fn):
    rows = list(csv.DictReader(open(fn))); return {k: np.array([float(r[k]) if r[k] not in ("", None) else np.nan for r in rows]) for k in rows[0]}
def events_of(tr):
    prev = None; ev = []
    for q in tr:
        c = resolve(q["cps"]); nO = sum(1 for x in c if x["kind"] == "O"); nX = len(c) - nO; key = (nO, nX)
        if prev is not None and key != prev: ev.append(dict(t=q["t"], nO=nO, nX=nX, points=[(x["kind"], round(x["z"], 3), round(x["psi"], 3)) for x in c]))
        prev = key
    return ev
def merge(a, b):
    """concatenate two diag dicts (a before b in time)"""
    m = a["t"] < b["t"][0] - 1e-12
    return {k: np.concatenate([a[k][m], b[k]]) for k in a if k in b}

ref = merge(diag_of(1000, 0.05, "before"), diag_of(1000, 0.05, "after"))
ref_ev = [e for e in events_of(tracks_of(1000, 0.05)) if e["t"] > 0.9]
runs = {}
for d in sorted(glob.glob(DATA + "/controls/release/*/")):
    name = os.path.basename(d.rstrip("/"))
    if not os.path.exists(d + "diag.csv"): continue
    tr = json.load(open(d + "tracks.json")) if os.path.exists(d + "tracks.json") else []
    runs[name] = dict(diag=rd(d + "diag.csv"), events=events_of(tr), tmax=float(json.load(open(d + "status.json"))["t_reached"]) if os.path.exists(d + "status.json") else np.nan,
                      params=json.load(open(d + "config.json"))["parameters"])
out = {}
for name, R in runs.items():
    D = R["diag"]; p = R["params"]; t = D["t"]
    print(f"\n=== {name}: mode={p['mode']} t_ramp={p['t_ramp']} reached t={R['tmax']:.4f}")
    rows = []
    for tt in (0.95, 1.0, 1.05, 1.1, 1.2, 1.3, 1.5, 1.8, 2.0, 2.3, 2.5):
        if tt > t.max() + 1e-9: break
        i = np.argmin(np.abs(t - tt)); j = np.argmin(np.abs(ref["t"] - tt))
        if abs(t[i] - tt) > 0.01 or abs(ref["t"][j] - tt) > 0.01: continue
        r = dict(t=tt, Ktot=D["Ktot"][i], Ktot_ref=ref["Ktot"][j], M=D["M"][i], M_ref=ref["M"][j], H=D["H"][i], H_ref=ref["H"][j])
        r["dK"] = r["Ktot"] / r["Ktot_ref"] - 1; r["dM"] = r["M"] / r["M_ref"] - 1; r["dH"] = r["H"] / r["H_ref"] - 1
        rows.append(r); print(f"  t={tt:4.2f}  Ktot {r['Ktot']:9.2f} (ref {r['Ktot_ref']:9.2f}, {100*r['dK']:+7.3f}%)  M {r['M']:8.3f} (ref {r['M_ref']:8.3f}, {100*r['dM']:+7.3f}%)  H {r['H']:.5f} (ref {r['H_ref']:.5f}, {100*r['dH']:+6.3f}%)")
    print("  events (t, N_O, N_X):", [(round(e["t"], 4), e["nO"], e["nX"]) for e in R["events"] if e["t"] > 0.9])
    out[name] = dict(mode=p["mode"], t_ramp=p["t_ramp"], tmax=R["tmax"], table=rows, events=[(e["t"], e["nO"], e["nX"], e["points"]) for e in R["events"] if e["t"] > 0.9])
print("\nreference events:", [(round(e["t"], 4), e["nO"], e["nX"]) for e in ref_ev])
out["reference"] = dict(events=[(e["t"], e["nO"], e["nX"], e["points"]) for e in ref_ev])
json.dump(out, open(HERE + "/compare.json", "w"), indent=1, default=float)
