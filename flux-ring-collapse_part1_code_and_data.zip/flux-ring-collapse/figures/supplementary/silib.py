"""Shared helpers for the Supplementary Information: run lookup, critical-point filters, birth statistics."""
import os, sys, glob, json, csv, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
SCR = os.path.normpath(os.path.join(HERE, "..", ".."))       # repository root
RES = SCR + "/figures/data/results/"
RAW = SCR + "/figures/data/raw/"
sys.path.insert(0, SCR + "/analysis")
import cuspfit as Cf

DZ = 16.0 / 1024
SCAN = [(1, 0.05), (3, 0.05), (10, 0.05), (20, 0.05), (50, 0.05), (100, 0.05), (200, 0.05), (300, 0.05), (500, 0.05), (1000, 0.05),
        (1, 0.01), (10, 0.01), (50, 0.01), (100, 0.01), (200, 0.01), (300, 0.01), (500, 0.01), (1000, 0.01)]
LATE = {(100, 0.01), (200, 0.01), (300, 0.01), (500, 0.01)}
RIPPLED = {(50, 0.01), (100, 0.01), (200, 0.01), (300, 0.01), (500, 0.01), (1000, 0.05)}

def run_dir(eps, eta, part="after"):
    g = glob.glob(f"{RES}LR_e{eps}_eta{eta}_unconfined_*/")
    if g: return g[0]
    return RES + ("legacy_geometry_unconfined_d87ab6fa32e4/" if part == "after" else "legacy_geometry_unconfined_d5fc336787c6/")

def raw_dir(eps, eta, part="after"):
    g = glob.glob(f"{RAW}LR_e{eps}_eta{eta}_unconfined_*/")
    if g: return g[0]
    return RAW + ("legacy_geometry_unconfined_d87ab6fa32e4/" if part == "after" else "legacy_geometry_unconfined_d5fc336787c6/")

def tracks_of(eps, eta): return json.load(open(run_dir(eps, eta) + "data/tracks.json"))
def summary_of(eps, eta, part="after"): return json.load(open(run_dir(eps, eta, part) + "data/summary.json"))
def params_of(eps, eta): return json.load(open(run_dir(eps, eta) + "data/params.json"))
def diag_of(eps, eta, part="after"):
    rows = list(csv.DictReader(open(run_dir(eps, eta, part) + "data/diag.csv")))
    return {k: np.array([float(r[k]) if r[k] not in ("", None) else np.nan for r in rows]) for k in rows[0]}
def rings_of(eps, eta):
    out = []
    for ln in open(run_dir(eps, eta) + "data/rings.csv").read().splitlines()[1:]:
        p = ln.split(","); t = float(p[0]); n = int(p[1]); dmax = float(p[2]); items = []
        for x in ",".join(p[3:]).split(";"):
            if not x: continue
            d, rz = x.split("@"); r, z = rz.split(","); items.append((float(d), float(r), float(z)))
        out.append((t, n, dmax, items))
    return out
def bphi_of(eps, eta):
    rows = list(csv.DictReader(open(run_dir(eps, eta) + "data/bphi.csv")))
    return {k: np.array([float(r[k]) for r in rows]) for k in rows[0]}

def resolve(cps, dmin=1e-3, cells=3):
    """drop O-X pairs shallower than dmin (of Psi_max) or narrower than `cells` cells, iteratively"""
    c = sorted(cps, key=lambda q: q["z"])
    while True:
        worst = None
        for i, q in enumerate(c):
            if q["kind"] != "X" or i == 0 or i == len(c) - 1: continue
            lo, hi = c[i - 1], c[i + 1]; d = min(lo["psi"], hi["psi"]) - q["psi"]; sh = lo if lo["psi"] < hi["psi"] else hi
            sc = min(d / dmin, abs(sh["z"] - q["z"]) / (cells * DZ))
            if sc < 1 and (worst is None or sc < worst[0]): worst = (sc, i, c.index(sh))
        if worst is None: return c
        i, j = sorted(worst[1:]); del c[j]; del c[i]

def island(tracks, zwin, dmin=2e-5):
    """depth and axis-saddle separation of the deepest island whose saddle lies in zwin, record by record"""
    T, D, Sp = [], [], []
    for q in tracks:
        c = sorted(q["cps"], key=lambda x: x["z"]); best = None
        for i, x in enumerate(c):
            if x["kind"] != "X" or i == 0 or i == len(c) - 1 or not (zwin[0] <= x["z"] <= zwin[1]): continue
            lo, hi = c[i - 1], c[i + 1]; d = min(lo["psi"], hi["psi"]) - x["psi"]; sh = lo if lo["psi"] < hi["psi"] else hi
            if best is None or d > best[0]: best = (d, abs(sh["z"] - x["z"]))
        if best and best[0] > dmin: T.append(q["t"]); D.append(best[0]); Sp.append(best[1])
    return np.array(T), np.array(D), np.array(Sp)

def scaling(T, D, Sp, k=25, cells=3, XMAX=0.05, reverse=False):
    """t_b (or t_a) from a linear fit of the squared separation over the first (last) k resolved records, and the
    log-log slopes of the depth and the separation against the time since the birth (to the annihilation) below XMAX"""
    res = Sp >= cells * DZ; T, D, Sp = T[res], D[res], Sp[res]
    sel = slice(-k, None) if reverse else slice(0, k)
    p = np.polyfit(T[sel], Sp[sel]**2, 1); tb = -p[1] / p[0]; x = (tb - T) if reverse else (T - tb)
    ok = (x > 0) & (x < XMAX); lx = np.log(x[ok])
    return tb, x[ok], D[ok], Sp[ok], np.polyfit(lx, np.log(D[ok]), 1)[0], np.polyfit(lx, np.log(Sp[ok]), 1)[0], int(ok.sum())

def world_lines(tracks, tw, resolved=True):
    TO, ZO, PO, TX, ZX, PX = [], [], [], [], [], []
    for q in tracks:
        if tw[0] <= q["t"] <= tw[1]:
            for x in (resolve(q["cps"]) if resolved else q["cps"]):
                if x["kind"] == "O": TO.append(q["t"]); ZO.append(x["z"]); PO.append(x["psi"])
                else: TX.append(q["t"]); ZX.append(x["z"]); PX.append(x["psi"])
    return np.array(TO), np.array(ZO), np.array(PO), np.array(TX), np.array(ZX), np.array(PX)

def ridge(Psi, r, z, frac=0.25):
    """flux ridge max_r Psi(r, z) and its radius, kept where it exceeds frac of the peak"""
    R = Psi.max(axis=0); i = Psi.argmax(axis=0); rr = r[i]
    m = R >= frac * R.max()
    return z[m], R[m], rr[m]

def load_snap(path):
    d = np.load(path)
    return {k: d[k] for k in d.files if k not in ("config_sha256", "code_sha256")}
