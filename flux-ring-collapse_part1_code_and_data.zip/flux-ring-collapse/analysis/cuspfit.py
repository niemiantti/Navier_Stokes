#!/usr/bin/env python3
"""
cuspfit.py - fits the pinch of the flux ridge to the cusp normal form  f(z) = c - z^4/4 + a z^2/2 + b z.

Two sources of data:
  (1) ridge profiles from snapshots (light_t*.npz / full_t*.npz: arrays r, z, Psi): a quartic least-squares fit of
      max_r Psi(z) around its top gives (a, b) at any time, before or after the pinch;
  (2) critical-point tracks (tracks.json of the runs): after the birth of the second axis the three critical points
      O, X, O are the roots of z^3 - a z - b = 0 (after shifting z by their mean), so that beta = b / a^(3/2), which is
      invariant under the scaling of the normal form, follows from the three positions alone.
The cusp predicts that the island-depth ratio at the birth is a function of beta only, R(beta), with R(0) = 1
(pitchfork) and R -> 0 as beta -> (4/27)^(1/2) (fold).

    python3 cuspfit.py tracks  <tracks.json> [<tracks.json> ...]   # beta and ratio after the birth, per run
    python3 cuspfit.py frames  <snapshot.npz> [...]                 # (a, b, beta) from the ridge of each snapshot
    python3 cuspfit.py test    <results folders ...>                # measured ratio against R(beta): figure cusp_test.png
"""
import sys, os, json, glob, numpy as np

# ----------------------------------------------------------------------------- the normal form
def cusp_critical(a, b):
    """roots of z^3 - a z - b = 0 (real), sorted"""
    r = np.roots([1.0, 0.0, -a, -b]); r = np.sort(r[np.abs(r.imag) < 1e-9].real)
    return r

def cusp_ratio(beta):
    """island-depth ratio at fixed beta = b / a^(3/2) (a = 1, b = beta): (shallow depth) / (deep depth)"""
    z = cusp_critical(1.0, beta)
    if len(z) < 3: return 0.0
    f = -z**4 / 4 + z**2 / 2 + beta * z
    dl, dh = f[0] - f[1], f[2] - f[1]
    return float(min(dl, dh) / max(dl, dh))

BETA_FOLD = np.sqrt(4.0 / 27.0)

# ----------------------------------------------------------------------------- from tracks
def beta_from_points(z1, z2, z3):
    """three critical points O < X < O of a quartic with leading term -z^4/4: shift to zero mean, then
    e2 = z1 z2 + z1 z3 + z2 z3 = -a_pos, e3 = z1 z2 z3 = b_pos (in position units); beta is scale invariant"""
    zc = np.array([z1, z2, z3]); zc = zc - zc.mean()
    a_pos = -(zc[0] * zc[1] + zc[0] * zc[2] + zc[1] * zc[2]); b_pos = zc[0] * zc[1] * zc[2]
    if a_pos <= 0: return None, a_pos, b_pos
    return float(b_pos / a_pos**1.5), float(a_pos), float(b_pos)

def pinch_triplet(cps, zwin=None):
    """the X with the two neighbouring O's that form the deepest island (optionally within a z window)"""
    c = sorted(cps, key=lambda q: q["z"]); best = None
    for i, q in enumerate(c):
        if q["kind"] != "X" or i == 0 or i == len(c) - 1: continue
        if zwin and not (zwin[0] <= q["z"] <= zwin[1]): continue
        lo, hi = c[i - 1], c[i + 1]
        if lo["kind"] != "O" or hi["kind"] != "O": continue
        d = min(lo["psi"], hi["psi"]) - q["psi"]
        if best is None or d > best[0]: best = (d, lo, q, hi)
    return best

def tracks_beta(tracks, t_window=None, zwin=None, dmin=1e-4):
    """for each record with a resolved pinch triplet: t, beta, measured depth ratio, a_pos, b_pos"""
    out = []
    for q in tracks:
        if t_window and not (t_window[0] <= q["t"] <= t_window[1]): continue
        tr = pinch_triplet(q["cps"], zwin)
        if tr is None or tr[0] < dmin: continue
        d, lo, x, hi = tr
        dl, dh = lo["psi"] - x["psi"], hi["psi"] - x["psi"]; ratio = min(dl, dh) / max(dl, dh)
        beta, a_pos, b_pos = beta_from_points(lo["z"], x["z"], hi["z"])
        if beta is None: continue
        out.append(dict(t=q["t"], beta=abs(beta), ratio=ratio, a_pos=a_pos, b_pos=b_pos, depth=d))
    return out

# ----------------------------------------------------------------------------- from frames
def ridge_fit(z, R, half_width=None, drop=0.03):
    """quartic fit of the ridge R(z) around its top; returns (z0, a, b, c, kappa, window) in normal-form units,
    where the fit R = c0 + c1 (z-z0) + c2 (z-z0)^2 + c4 (z-z0)^4 (c3 removed by the choice of z0)"""
    R = np.asarray(R, float) / np.max(R); k0 = int(np.argmax(R))
    if half_width is None:
        above = np.nonzero(R >= 1.0 - drop)[0]; lo, hi = above.min(), above.max()
        half_width = max(z[hi] - z[lo], 6 * (z[1] - z[0]))
    m = np.abs(z - z[k0]) <= half_width
    zz, RR = z[m], R[m]
    # choose z0 to kill the cubic term: fit full quartic, shift to the inflection-free centre iteratively
    z0 = z[k0]
    for _ in range(6):
        p = np.polyfit(zz - z0, RR, 4)          # p[0] z^4 + p[1] z^3 + p[2] z^2 + p[3] z + p[4]
        if p[0] >= 0: break
        z0 = z0 - p[1] / (4 * p[0])             # shift that removes the cubic term of a quartic
    p = np.polyfit(zz - z0, RR, 4)
    c4, c3, c2, c1, c0 = p
    if c4 >= 0: return None
    kappa = -4 * c4; lam = kappa**(-0.25)
    a = 2 * c2 * lam**2; b = c1 * lam
    return dict(z0=float(z0), a=float(a), b=float(b), c=float(c0), kappa=float(kappa), lam=float(lam),
                beta=(float(abs(b) / a**1.5) if a > 0 else None), window=(float(zz.min()), float(zz.max())),
                resid=float(np.sqrt(np.mean((np.polyval(p, zz - z0) - RR)**2))))

def frame_ridge(fn):
    F = np.load(fn); Psi = F["Psi"].astype(float)
    return F["z"], Psi.max(axis=0), float(F["t"]) if "t" in F.files else None

# ----------------------------------------------------------------------------- commands
def cmd_tracks(files):
    for f in files:
        tr = json.load(open(f)); rows = tracks_beta(tr)
        if not rows: print(f"{f}: no resolved pinch"); continue
        first = rows[0]; print(f"{f}\n   first resolved pinch at t = {first['t']:.4f}: beta = {first['beta']:.3f}, measured ratio = {first['ratio']:.3f}, "
                               f"cusp prediction R(beta) = {cusp_ratio(first['beta']):.3f}")
        for r in rows[1:40:8]: print(f"   t = {r['t']:.4f}: beta = {r['beta']:.3f}, ratio = {r['ratio']:.3f}, R(beta) = {cusp_ratio(r['beta']):.3f}, depth = {r['depth']:.2e}")

def cmd_frames(files):
    for f in files:
        z, R, t = frame_ridge(f); fit = ridge_fit(z, R)
        if fit is None: print(f"{f}: no quartic maximum"); continue
        state = ("single maximum" if fit["a"] <= 0 else ("split, " + ("central" if fit["beta"] < 0.1 else "one-sided")))
        print(f"{os.path.basename(f)} (t = {t}): a = {fit['a']:+.4f}, b = {fit['b']:+.5f}, beta = {fit['beta']}, kappa = {fit['kappa']:.3g}, "
              f"z0 = {fit['z0']:+.3f}, window = {fit['window']}, rms = {fit['resid']:.1e}: {state}")

def cmd_test(folders):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    pts = []
    for d in folders:
        tf = os.path.join(d, "data", "tracks.json"); sf = os.path.join(d, "data", "summary.json")
        if not os.path.exists(tf): continue
        s = json.load(open(sf)) if os.path.exists(sf) else {}
        p = json.load(open(os.path.join(d, "data", "params.json"))) if os.path.exists(os.path.join(d, "data", "params.json")) else {}
        tr = json.load(open(tf)); ts = (s.get("split") or {}).get("t_s")
        rows = tracks_beta(tr, t_window=(ts - 0.001, ts + 0.06) if ts else None, dmin=5e-4)
        if not rows: continue
        early = rows[:15]
        pts.append(dict(name=os.path.basename(d), eps=p.get("eps_b"), eta=p.get("eta"), beta=np.median([r["beta"] for r in early]),
                        ratio=np.median([r["ratio"] for r in early]), ratio_summary=(s.get("split") or {}).get("island_ratio")))
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.4), constrained_layout=True)
    bb = np.linspace(0, BETA_FOLD, 200); ax[0].plot(bb, [cusp_ratio(x) for x in bb], "k-", label="cusp normal form $R(\\beta)$")
    for q in pts:
        c = "#c92a2a" if q["eta"] == 0.05 else "#1971c2"
        ax[0].plot(q["beta"], q["ratio"], "o", color=c, mec="k"); ax[0].annotate(f"{q['eps']:g}", (q["beta"], q["ratio"]), xytext=(4, 3), textcoords="offset points", fontsize=7)
    ax[0].plot([], [], "o", color="#c92a2a", mec="k", label="$\\eta$ = 0.05 (labels: $\\epsilon_B$)"); ax[0].plot([], [], "o", color="#1971c2", mec="k", label="$\\eta$ = 0.01")
    ax[0].set_xlabel(r"$\beta = b/a^{3/2}$ from the three critical points"); ax[0].set_ylabel("island-depth ratio (measured)"); ax[0].legend(frameon=False, fontsize=8)
    ax[0].set_title("ratio against the cusp prediction, just after the birth", fontsize=9)
    for q in pts:
        c = "#c92a2a" if q["eta"] == 0.05 else "#1971c2"
        ax[1].plot(q["eps"], q["beta"], "o", color=c, mec="k")
    ax[1].axhline(BETA_FOLD, color="k", ls=":", lw=0.8); ax[1].text(1.1, BETA_FOLD + 0.005, r"$\beta_{fold} = (4/27)^{1/2}$", fontsize=8)
    ax[1].set_xscale("log"); ax[1].set_xlabel(r"$\epsilon_B$"); ax[1].set_ylabel(r"$\beta$ just after the birth"); ax[1].set_title("asymmetry parameter against field strength", fontsize=9)
    fig.savefig("cusp_test.png", dpi=150); fig.savefig("cusp_test.pdf")
    for q in pts: print(f"{q['name'][:22]:22s} eps={q['eps']:>6g} eta={q['eta']:<5g} beta={q['beta']:.3f} ratio={q['ratio']:.3f} R(beta)={cusp_ratio(q['beta']):.3f} (summary ratio {q['ratio_summary']})")
    print("written cusp_test.png")

if __name__ == "__main__":
    if len(sys.argv) < 3: print(__doc__); sys.exit(0)
    cmd, args = sys.argv[1], sys.argv[2:]
    {"tracks": cmd_tracks, "frames": cmd_frames, "test": cmd_test}[cmd](args)
