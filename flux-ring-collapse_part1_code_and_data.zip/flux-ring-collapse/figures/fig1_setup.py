"""Figure 1 at 183 mm: (a) the seed in 3D, (b) the imposed flow at t = 0.75 with the seed, (c) split time, (d) depth ratio."""
import sys, glob, json, os, numpy as np, contourpy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "axisymmetric"))   # openai_mhd_3d
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "seed_render"))          # seed
from style import plt, MM, WIDTH, C_ETA, LAYER, letter, plain_log
from matplotlib.path import Path
from matplotlib.patches import Patch
from PIL import Image
import openai_mhd_3d as mhd
from seed import fields

HERE = os.path.dirname(os.path.abspath(__file__))
runs = []
for d in glob.glob(HERE + "/data/results/*/data/summary.json"):
    if "LRref" in d or "d87ab6" in d: continue
    s = json.load(open(d)); p = json.load(open(d.replace("summary.json", "params.json")))
    runs.append(dict(eps=p["eps_b"], eta=p["eta"], ts=(s.get("split") or {}).get("t_s"), ratio=(s.get("split") or {}).get("island_ratio")))
runs.sort(key=lambda r: (r["eta"], r["eps"]))
LATE = {(100, 0.01), (200, 0.01), (300, 0.01), (500, 0.01)}      # late splits of the compressed sheet: resolution-sensitive

fig = plt.figure(figsize=(WIDTH, 128 * MM))
# ------------------------------------------------------------------ a: the seed in 3D
img = Image.open(HERE + "/seed_render/torus_layers.png").convert("RGB"); A = np.asarray(img)
nz = np.where((A < 250).any(axis=2)); m = 20
A = A[max(nz[0].min() - m, 0):nz[0].max() + m, max(nz[1].min() - m, 0):nz[1].max() + m]
axa = fig.add_axes([0.0, 0.47, 0.50, 0.49]); axa.imshow(A, interpolation="lanczos"); axa.set_axis_off()
letter(axa, "a", "the seed: a Taylor spheromak of unit radius", x=0.0, y=0.985)
# colour key of the flux layers
axk = fig.add_axes([0.50, 0.56, 0.13, 0.32]); axk.set_axis_off()
key = [(LAYER["red"], "innermost 10%"), (LAYER["orange"], "40%"), (LAYER["green"], "70%"), (LAYER["blue"], "outer surface,\n5% of peak flux")]
axk.text(0.0, 1.0, "flux surfaces\nenclosing, of the\nring's own flux:", fontsize=7, va="top", transform=axk.transAxes)
for i, (c, s) in enumerate(key):
    y = 0.62 - i * 0.17
    axk.add_patch(plt.Rectangle((0.0, y - 0.035), 0.13, 0.08, color=c, alpha=(0.55 if i == 3 else 1.0), transform=axk.transAxes, lw=0))
    axk.text(0.18, y, s, fontsize=7, va="center", transform=axk.transAxes)
# ------------------------------------------------------------------ b: the imposed flow at t = 0.75 and the seed
p = mhd.Params(nr=240, nz=640, rbox=6, zbox=8, r_t=4.5, r_o=5.4, z_t=6, z_o=7.2, profile="leiren", tau_f=0.05, lr_S=2.0,
               lr_XR=8.0, lr_Xc=0.5, lr_Rc=16.0, lr_cutoff="column", lr_L0=1.0)
g = mhd.Grid(p); bt = g.background_terms(0.25); st = np.sqrt(1 - 0.75)
axb = fig.add_axes([0.665, 0.475, 0.155, 0.47])
mr = g.r <= 3.0; mz = np.abs(g.z) <= 4.0
sp = np.sqrt(bt["Ur"]**2 + bt["Uz"]**2) * st
pm = axb.pcolormesh(g.r[mr], g.z[mz], sp[mr][:, mz].T, cmap="Blues", vmin=0, vmax=6, shading="auto", rasterized=True)
axb.streamplot(g.r[mr], g.z[mz], bt["Ur"][mr][:, mz].T, bt["Uz"][mr][:, mz].T, color="k", density=0.9, linewidth=0.4, arrowsize=0.45)
uth = g.r[:, None] * bt["OU"]
axb.contour(g.r[mr], g.z[mz], uth[mr][:, mz].T, levels=np.array([0.25, 0.5, 0.75]) * np.abs(uth).max(), colors="#c92a2a", linewidths=0.6)
# the seed in the colour code of a (the exact seed of the runs)
r = np.linspace(0, 1.2, 601); z = np.linspace(-1.2, 1.2, 1201); R, Z = np.meshgrid(r, z, indexing="ij")
Psi = fields(R, Z)[0]; Pm = Psi.max(); im = np.unravel_index(np.argmax(Psi), Psi.shape); axis = (r[im[0]], z[im[1]])
gen = contourpy.contour_generator(r, z, Psi.T)
outer = max(gen.lines(0.05 * Pm), key=len)
axb.fill(outer[:, 0], outer[:, 1], color="white", lw=0, zorder=3)
axb.fill(outer[:, 0], outer[:, 1], color=LAYER["blue"], alpha=0.75, lw=0, zorder=3)
for frac, col in ((0.3, "green"), (0.6, "orange"), (0.9, "red")):
    segs = [sg for sg in gen.lines(Pm - (1 - frac) * 0.95 * Pm) if len(sg) > 8 and Path(sg).contains_point(axis)]
    sg = min(segs, key=len); axb.fill(sg[:, 0], sg[:, 1], color=LAYER[col], lw=0, zorder=3)
axb.contour(r, z, Psi.T, levels=np.linspace(0.05, 0.98, 6) * Pm, colors="k", linewidths=0.25, zorder=4)
axb.plot(outer[:, 0], outer[:, 1], color="white", lw=0.8, zorder=4)
axb.plot(*axis, "o", color="gold", mec="k", mew=0.4, ms=3.2, zorder=5)
axb.set_aspect("equal"); axb.set_xlim(0, 3); axb.set_ylim(-4, 4); axb.set_xlabel("$r$"); axb.set_ylabel("$z$")
axb.set_xticks([0, 1, 2, 3])
letter(axb, "b", "flow at $t$ = 0.75", x=-0.42, y=1.01)
cax = fig.add_axes([0.835, 0.56, 0.012, 0.30]); cb = plt.colorbar(pm, cax=cax); cb.set_label(r"$|u_p|\,\sqrt{1-t}$", labelpad=2)
cb.ax.tick_params(labelsize=7, width=0.5, length=2)
axb.text(1.62, 0.04, "swirl\n25, 50, 75%\nof maximum", transform=axb.transAxes, fontsize=7, color="#c92a2a", va="bottom")
# ------------------------------------------------------------------ c, d: the scan
axc = fig.add_axes([0.07, 0.085, 0.40, 0.31]); axd = fig.add_axes([0.575, 0.085, 0.40, 0.31])
for eta in (0.05, 0.01):
    R_ = [q for q in runs if q["eta"] == eta]
    xs = [q["eps"] for q in R_ if q["ts"] is not None]; ys = [q["ts"] for q in R_ if q["ts"] is not None]
    axc.plot(xs, ys, "-", color=C_ETA[eta], lw=1.0, zorder=2)
    for q in R_:
        if q["ts"] is None:
            axc.plot(q["eps"], 1.0, "v", color=C_ETA[eta], ms=5.5, mfc="white", mew=1.0, zorder=4)
            axc.annotate("no split before\nthe release", (q["eps"], 0.985), xytext=(1150, 0.52), textcoords="data", fontsize=7,
                         color=C_ETA[eta], ha="right", va="center", arrowprops=dict(arrowstyle="-", lw=0.5, color=C_ETA[eta]))
            continue
        late = (q["eps"], eta) in LATE
        axc.plot(q["eps"], q["ts"], "o", color=C_ETA[eta], mfc=("white" if late else C_ETA[eta]), mew=0.9, ms=4, zorder=3)
    R2 = [q for q in R_ if q["ratio"] is not None]
    axd.plot([q["eps"] for q in R2], [q["ratio"] for q in R2], "-", color=C_ETA[eta], lw=1.0, zorder=2)
    for q in R2:
        late = (q["eps"], eta) in LATE
        axd.plot(q["eps"], q["ratio"], "o", color=C_ETA[eta], mfc=("white" if late else C_ETA[eta]), mew=0.9, ms=4, zorder=3)
axc.axhline(1.0, color="#adb5bd", lw=0.7, ls=":"); axc.text(1.05, 1.005, "release", fontsize=7, color="#868e96", va="bottom")
axc.set_xscale("log"); axc.set_ylim(0.25, 1.07); axc.set_xlim(0.7, 1500); plain_log(axc)
axc.set_xlabel(r"magnetic coupling $\epsilon_B$"); axc.set_ylabel(r"split time $t_s$")
h = [plt.Line2D([], [], color=C_ETA[0.05], marker="o", ms=4, lw=1.0, label=r"$\eta$ = 0.05"),
     plt.Line2D([], [], color=C_ETA[0.01], marker="o", ms=4, lw=1.0, label=r"$\eta$ = 0.01"),
     plt.Line2D([], [], color=C_ETA[0.01], marker="o", ms=4, mfc="white", lw=0, label="late split,\nresolution-sensitive")]
axc.legend(handles=h, loc="upper left", bbox_to_anchor=(0.0, 0.93))
letter(axc, "c", "the split is delayed by the field", x=-0.13, y=1.02)
axd.axhspan(0.5, 1.0, color="#e9ecef", zorder=0, lw=0); axd.axhspan(0.0, 0.2, color="#f8f0e3", zorder=0, lw=0)
axd.text(0.95, 0.93, "central (pitchfork-like), ratio > 0.5", fontsize=7, va="top"); axd.text(0.95, 0.03, "one-sided (fold), ratio < 0.2", fontsize=7)
axd.set_xscale("log"); axd.set_ylim(0, 1); axd.set_xlim(0.7, 1500); plain_log(axd)
axd.set_xlabel(r"magnetic coupling $\epsilon_B$"); axd.set_ylabel("island-depth ratio after the birth")
letter(axd, "d", "the field selects the bifurcation", x=-0.13, y=1.02)
out = HERE + "/out/Fig1.pdf"; os.makedirs(HERE + "/out", exist_ok=True)
fig.savefig(out); fig.savefig(out.replace(".pdf", ".png"), dpi=300); print("written", out)
