"""Figure 4 at 183 mm: regimes after the release. (a) kinetic/magnetic energy at the release, (b) ring-count map of all
eighteen runs (main ring + secondary maxima deeper than 5 % of Psi_max, every 0.1), (c) helicity ratios, (d) outcome at
t = 4, with the resolution-sensitive late splits marked."""
import sys, os, glob, json, csv, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); os.makedirs(HERE + "/out", exist_ok=True)
from style import plt, MM, WIDTH, C_ETA, letter, plain_log, pow_ticks
from matplotlib.colors import ListedColormap, BoundaryNorm

R = HERE + "/data/results/"
runs = {}
for d in glob.glob(R + "*/"):
    if "LRref" in d: continue
    s = json.load(open(d + "data/summary.json")); p = json.load(open(d + "data/params.json"))
    key = (int(p["eps_b"]), p["eta"])
    rows = list(csv.DictReader(open(d + "data/rings.csv")))
    ring = {round(float(x["t"]), 1): int(x["separate_rings"]) + 1 for x in rows}
    if key in runs:                                                   # eps_B = 1000, eta = 0.05: collapse run + continuation
        runs[key]["ring"].update(ring)
        if "d87ab6" in d: runs[key]["s_after"] = s
        else: runs[key]["s"] = s
        continue
    runs[key] = dict(s=s, s_after=s, ring=ring)
for k in sorted(runs):
    r = runs[k]; print(k, "K/M %.3g" % r["s"]["kinetic_over_magnetic_after_release"], "H1/H0 %.3f" % r["s"]["helicity_kept_to_release"], "H4/H1 %.3f" % r["s_after"]["helicity_kept_after_release"])
ETAS = (0.05, 0.01)
REG = {(1, 0.05): "D", (3, 0.05): "D", (10, 0.05): "D", (20, 0.05): "Dr", (50, 0.05): "Dr", (100, 0.05): "Dr", (200, 0.05): "Dr", (300, 0.05): "Dr",
       (500, 0.05): "Dc", (1000, 0.05): "T", (1, 0.01): "D", (10, 0.01): "Dch", (50, 0.01): "Dch", (100, 0.01): "Dch", (200, 0.01): "Dch",
       (300, 0.01): "Dch", (500, 0.01): "A", (1000, 0.01): "S"}
MK = {"D": ("o", "#1971c2", "passive doublet"), "Dr": ("s", "#74c0fc", "doublet with internal rolls"),
      "Dch": ("D", "#1864ab", "doublet, island chain on the neck"), "Dc": ("P", "#f08c00", "doublet, central ring forming"),
      "T": ("^", "#e8590c", "triplet"), "A": ("h", "#868e96", "asymmetric, two to three rings"), "S": ("*", "#c92a2a", "single ring (not split in the collapse)")}
LATE = {(100, 0.01), (200, 0.01), (300, 0.01), (500, 0.01)}

fig = plt.figure(figsize=(WIDTH, 128 * MM))
axa = fig.add_axes([0.075, 0.585, 0.33, 0.36]); axb = fig.add_axes([0.545, 0.585, 0.37, 0.36])
axc = fig.add_axes([0.075, 0.08, 0.33, 0.36]); axd = fig.add_axes([0.545, 0.30, 0.42, 0.14])
# a
for eta in ETAS:
    ks = sorted(k for k in runs if k[1] == eta)
    axa.plot([k[0] for k in ks], [runs[k]["s"]["kinetic_over_magnetic_after_release"] for k in ks], "o-", color=C_ETA[eta], ms=3.8, label=rf"$\eta$ = {eta}")
axa.set_xscale("log"); axa.set_yscale("log"); axa.set_xlim(0.7, 1500); plain_log(axa); pow_ticks(axa, "y")
axa.set_xlabel(r"magnetic coupling $\epsilon_B$"); axa.set_ylabel("energy ratio across the release,\n" + r"$K(1.05)\,/\,M(0.99)$"); axa.legend(loc="upper right")
letter(axa, "a", "energy ratio across the release", x=-0.17, y=1.02)
# b: ring-count map
order = [(e, 0.05) for e in (1, 3, 10, 20, 50, 100, 200, 300, 500, 1000)] + [(e, 0.01) for e in (1, 10, 50, 100, 200, 300, 500, 1000)]
tgrid = np.round(np.arange(0.0, 4.001, 0.1), 1)
M = np.full((len(order), len(tgrid)), np.nan)
for i, k in enumerate(order):
    for j, t in enumerate(tgrid):
        if t in runs[k]["ring"]: M[i, j] = min(runs[k]["ring"][t], 5)
cm = ListedColormap(["#f1f3f5", "#74c0fc", "#ffa94d", "#e8590c", "#9c3a12"]); nm = BoundaryNorm([0.5, 1.5, 2.5, 3.5, 4.5, 5.5], cm.N)
im = axb.imshow(M, aspect="auto", cmap=cm, norm=nm, interpolation="nearest", extent=(-0.05, 4.05, len(order) - 0.5, -0.5))
for i in range(len(order) + 1): axb.axhline(i - 0.5, color="white", lw=0.5)
axb.axhline(9.5, color="k", lw=0.8)
axb.axvline(1.0, color="k", lw=0.7, ls="--"); axb.text(1.0, -0.62, "release", fontsize=7.2, va="bottom", ha="center")
axb.set_yticks(range(len(order))); axb.set_yticklabels([f"{k[0]}" + (" †" if k in LATE else "") for k in order]); axb.tick_params(axis="y", length=0)
axb.set_xlim(0, 4); axb.set_xlabel("$t$")
axb.text(-0.20, 4.5, r"$\eta$ = 0.05", rotation=90, transform=axb.get_yaxis_transform(), va="center", ha="center", fontsize=7.2)
axb.text(-0.20, 13.5, r"$\eta$ = 0.01", rotation=90, transform=axb.get_yaxis_transform(), va="center", ha="center", fontsize=7.2)
axb.text(-0.105, -0.62, r"$\epsilon_B$", transform=axb.get_yaxis_transform(), fontsize=7.2, va="bottom", ha="center")
cax = fig.add_axes([0.93, 0.62, 0.012, 0.29]); cb = plt.colorbar(im, cax=cax, ticks=[1, 2, 3, 4, 5])
cb.ax.set_yticklabels(["1", "2", "3", "4", "≥5"]); cb.set_label("number of rings", labelpad=2); cb.ax.tick_params(labelsize=7, length=2, width=0.5)
letter(axb, "b", "rings during the collapse and after the release", x=-0.25, y=1.075)
# c
for eta in ETAS:
    ks = sorted(k for k in runs if k[1] == eta); x = [k[0] for k in ks]
    axc.plot(x, [runs[k]["s"]["helicity_kept_to_release"] for k in ks], "o-", color=C_ETA[eta], ms=3.8, label=rf"$H(1)/H(0)$, $\eta$ = {eta}")
    axc.plot(x, [runs[k]["s_after"]["helicity_kept_after_release"] for k in ks], "s--", color=C_ETA[eta], ms=3.6, mfc="white", label=rf"$H(4)/H(1)$, $\eta$ = {eta}")
axc.set_xscale("log"); axc.set_xlim(0.7, 1500); plain_log(axc); axc.set_ylim(0, 0.7)
axc.set_xlabel(r"magnetic coupling $\epsilon_B$"); axc.set_ylabel("fraction of the helicity kept")
axc.legend(loc="upper left", ncol=1, bbox_to_anchor=(0.0, 1.0))
letter(axc, "c", "helicity through the collapse and after it", x=-0.17, y=1.02)
# d
done = set()
for (eps, eta), k in REG.items():
    mk, col, lab = MK[k]
    axd.scatter(eps, eta, marker=mk, s=(80 if mk == "*" else 46), color=col, edgecolor="k", linewidths=0.5, zorder=3)
    if (eps, eta) in LATE: axd.scatter(eps, eta, marker="o", s=170, facecolor="none", edgecolor="#495057", linewidths=0.6, linestyle=(0, (2, 1.5)), zorder=2)
axd.set_xscale("log"); axd.set_yscale("log"); axd.set_xlim(0.6, 1800); axd.set_ylim(0.0062, 0.085); plain_log(axd)
axd.set_yticks([0.01, 0.05]); axd.set_yticklabels([r"$\eta$ = 0.01", r"$\eta$ = 0.05"]); axd.minorticks_off()
axd.set_xlabel(r"magnetic coupling $\epsilon_B$")
letter(axd, "d", r"outcome at $t$ = 4 (rings deeper than 5% of $\Psi_{\max}$)", x=-0.135, y=1.06)
h = [plt.Line2D([], [], marker=MK[k][0], color=MK[k][1], mec="k", mew=0.5, ms=(7 if MK[k][0] == "*" else 5), lw=0, label=MK[k][2]) for k in ("D", "Dr", "Dch", "Dc", "T", "A", "S")]
h.append(axd.scatter([], [], marker="o", s=110, facecolor="none", edgecolor="#495057", linewidths=0.6, linestyle=(0, (2, 1.5)), label="late split, resolution-sensitive († in b)"))
fig.legend(handles=h, loc="upper left", bbox_to_anchor=(0.485, 0.195), ncol=2, handletextpad=0.3, labelspacing=0.5, columnspacing=1.0)
out = HERE + "/out/Fig4.pdf"; fig.savefig(out); fig.savefig(out.replace(".pdf", ".png"), dpi=300); print("written", out)
