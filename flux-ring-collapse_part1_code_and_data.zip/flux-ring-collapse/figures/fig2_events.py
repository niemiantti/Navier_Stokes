"""Figure 2 at 183 mm, rebuilt as the four-bifurcations figure (a-h). Top row: world lines of the resolved O (gold) and
X (black) points along the flux ridge for the pitchfork-like split, the fold, the inverse fold (with the lobe islands and
the outer-ring folds of the same run) and the island chain on the neck. Bottom row: island depth and axis-saddle
separation against the time since the birth (or until the annihilation) with the normal-form slopes, and the depth
histories of the shallow islands. Everything is read from the critical-point tracks and the ring records of the runs."""
import sys, os, glob, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); os.makedirs(HERE + "/out", exist_ok=True)
from style import plt, MM, WIDTH, GOLD, letter, pow_ticks

def run_dir(eps, eta):
    g = glob.glob(f"{HERE}/data/results/LR_e{eps}_eta{eta}_unconfined_*/")
    return g[0] if g else HERE + "/data/results/legacy_geometry_unconfined_d87ab6fa32e4/"

def tracks_of(eps, eta): return json.load(open(run_dir(eps, eta) + "data/tracks.json"))

DZ = 16.0 / 1024

def resolve(cps, dmin=1e-3, cells=3):
    """drop O-X pairs shallower than dmin (of Psi_max) or narrower than three cells"""
    c = sorted(cps, key=lambda q: q["z"])
    while True:
        worst = None
        for i, q in enumerate(c):
            if q["kind"] != "X" or i == 0 or i == len(c) - 1: continue
            lo, hi = c[i - 1], c[i + 1]; d = min(lo["psi"], hi["psi"]) - q["psi"]; sh = lo if lo["psi"] < hi["psi"] else hi
            sc = min(d / dmin, abs(sh["z"] - q["z"]) / (cells * DZ))
            if sc < 1 and (worst is None or sc < worst[0]): worst = (sc, i, c.index(sh))
        if worst is None: return c
        i, j = sorted(worst[1:]); del c[j]; del c[i]

def island(tracks, zwin, dmin=2e-5):
    """depth and axis-saddle separation of the deepest island whose saddle lies in zwin, record by record"""
    T, D, Sp = [], [], []
    for q in tracks:
        c = sorted(q["cps"], key=lambda x: x["z"]); best = None
        for i, x in enumerate(c):
            if x["kind"] != "X" or i == 0 or i == len(c) - 1 or not (zwin[0] <= x["z"] <= zwin[1]): continue
            lo, hi = c[i - 1], c[i + 1]; d = min(lo["psi"], hi["psi"]) - x["psi"]; sh = lo if lo["psi"] < hi["psi"] else hi
            if best is None or d > best[0]: best = (d, abs(sh["z"] - x["z"]))
        if best and best[0] > dmin: T.append(q["t"]); D.append(best[0]); Sp.append(best[1])
    return np.array(T), np.array(D), np.array(Sp)

def scaling(T, D, Sp, k=25, cells=3, XMAX=0.05, reverse=False):
    """t_b (or t_a) from a linear fit of the squared separation over the first (last) k resolved records"""
    res = Sp >= cells * DZ; T, D, Sp = T[res], D[res], Sp[res]
    sel = slice(-k, None) if reverse else slice(0, k)
    p = np.polyfit(T[sel], Sp[sel]**2, 1); tb = -p[1] / p[0]; x = (tb - T) if reverse else (T - tb)
    ok = (x > 0) & (x < XMAX); lx = np.log(x[ok])
    return tb, x[ok], D[ok], Sp[ok], np.polyfit(lx, np.log(D[ok]), 1)[0], np.polyfit(lx, np.log(Sp[ok]), 1)[0]

def o_islands(tracks, t0, t1, zwin, dmax=0.5):
    """depth of each axis above the higher of its adjacent saddles, for the shallow islands (depth < dmax): t, z, depth"""
    out = []
    for q in tracks:
        if not (t0 <= q["t"] <= t1): continue
        c = sorted(q["cps"], key=lambda x: x["z"])
        for i, x in enumerate(c):
            if x["kind"] != "O" or not (zwin[0] <= x["z"] <= zwin[1]): continue
            adj = [c[j]["psi"] for j in (i - 1, i + 1) if 0 <= j < len(c) and c[j]["kind"] == "X"]
            if adj and x["psi"] - max(adj) <= dmax: out.append((q["t"], x["z"], x["psi"] - max(adj)))
    return np.array(out)

def ring_islands(eps, eta, rmax=0.6, zmax=1.0, dmin=1e-3, t0=0.9):
    """secondary flux maxima on the neck (r < rmax, |z| < zmax) from the ring records, every 0.1 from t0: t, z, depth"""
    out = []
    for ln in open(run_dir(eps, eta) + "data/rings.csv").read().splitlines()[1:]:
        p = ln.split(","); t = float(p[0])
        if t < t0: continue
        for x in ",".join(p[3:]).split(";"):
            if not x: continue
            d, rz = x.split("@"); r, z = rz.split(",")
            if float(r) < rmax and abs(float(z)) < zmax and float(d) >= dmin: out.append((t, float(z), float(d)))
    return np.array(out)

def world_lines(ax, tracks, tw, kinds="OX"):
    TO, ZO, TX, ZX = [], [], [], []
    for q in tracks:
        if tw[0] <= q["t"] <= tw[1]:
            for x in resolve(q["cps"]):
                (TO if x["kind"] == "O" else TX).append(q["t"]); (ZO if x["kind"] == "O" else ZX).append(x["z"])
    if "X" in kinds: ax.plot(TX, ZX, ".", color="k", ms=1.6, mew=0, rasterized=True)
    ax.plot(TO, ZO, ".", color=GOLD, ms=1.9, mew=0, rasterized=True)

VIO, VIO2 = "#5f3dc4", "#b197fc"; TEAL, TEAL2 = "#0c8599", "#66d9e8"; ORA, ORA2 = "#e8590c", "#ffc078"
RED, BLUE, GREY = "#c92a2a", "#1971c2", "#868e96"
fig = plt.figure(figsize=(WIDTH, 122 * MM))
W = 0.185; X0 = [0.06, 0.305, 0.55, 0.795]; YT, HT = 0.605, 0.33; YB, HB = 0.095, 0.35
top = [fig.add_axes([x, YT, W, HT]) for x in X0]; bot = [fig.add_axes([x, YB, W, HB]) for x in X0]
LX = -0.27

# ------------------------------------------------------------------ top row: world lines
world_lines(top[0], tracks_of(1, 0.05), (0.2, 0.7)); world_lines(top[1], tracks_of(50, 0.05), (0.3, 0.8))
world_lines(top[2], tracks_of(1000, 0.05), (1.2, 2.6))
for ax, zl in zip(top[:3], (2.4, 2.4, 4.5)): ax.set_ylim(-zl, zl)
top[0].set_xlim(0.2, 0.7); top[1].set_xlim(0.3, 0.8); top[2].set_xlim(1.2, 2.6)
letter(top[0], "a", r"pitchfork-like: $\epsilon_B$ = 1, $\eta$ = 0.05", x=LX, y=1.04)
letter(top[1], "b", r"fold: $\epsilon_B$ = 50, $\eta$ = 0.05", x=LX, y=1.04)
letter(top[2], "c", r"inverse fold: $\epsilon_B$ = 1000, $\eta$ = 0.05", x=LX, y=1.04)
h = [plt.Line2D([], [], color=GOLD, marker="o", ms=3.2, lw=0, label="magnetic axis (O)"), plt.Line2D([], [], color="k", marker="o", ms=3.2, lw=0, label="saddle (X)")]
top[0].legend(handles=h, loc="upper left", handletextpad=0.2, borderaxespad=0.2)
A = dict(fontsize=6.8, arrowprops=dict(arrowstyle="-", lw=0.5, color="#495057"))
top[2].annotate("cores merge", (2.28, 0.15), xytext=(2.05, 1.55), ha="center", va="bottom", **A)
top[2].annotate("outer rings shed\n(folds)", (1.83, 2.55), xytext=(1.26, 3.3), ha="left", va="center", **A)
top[2].annotate("", (2.05, -2.6), xytext=(1.6, -3.35), arrowprops=dict(arrowstyle="-", lw=0.5, color="#495057"))
top[2].text(1.6, -3.35, "fold", fontsize=6.8, ha="right", va="center")
top[2].annotate("lobe islands", (1.36, -2.1), xytext=(1.5, -1.5), ha="left", va="center", **A)
top[2].annotate("", (1.36, 2.1), xytext=(1.5, -1.5), arrowprops=dict(arrowstyle="-", lw=0.5, color="#495057", shrinkB=0, alpha=0))
# d: the island chain on the neck, eps_B = 50, eta = 0.01: the tracks (25 % window) plus the neck islands of the ring records
ax = top[3]; world_lines(ax, tracks_of(50, 0.01), (0.8, 4.0))
ri = ring_islands(50, 0.01)
ax.scatter(ri[:, 0], ri[:, 1], s=7, color=BLUE, edgecolor="none", zorder=3)
ax.set_xlim(0.8, 4.0); ax.set_ylim(-4.6, 4.6)
letter(ax, "d", r"neck chain: $\epsilon_B$ = 50, $\eta$ = 0.01", x=LX, y=1.04)
ax.text(2.4, 3.7, "daughters", fontsize=6.8, ha="center", color="#8a6d00"); ax.text(3.0, 1.3, "islands on the neck", fontsize=6.8, ha="center", color=BLUE)
for ax in top: ax.set_xlabel("$t$")
top[0].set_ylabel("$z$ of the critical points")
top[3].axvline(1.0, color=GREY, lw=0.5, ls="--", zorder=0)
top[3].text(1.04, -4.4, "release", fontsize=6.3, color=GREY, ha="left", va="bottom", rotation=90)

# ------------------------------------------------------------------ bottom row: scalings and depth histories
def panel_scaling(ax, x, D, Sp, cD, cS, slope_depth, lab, title, xlabel, fits):
    ax.loglog(x, D, "o", ms=2.2, mew=0, color=cD, rasterized=True); ax.loglog(x, Sp, "o", ms=2.2, mew=0, color=cS, rasterized=True)
    xs = np.logspace(-2.9, np.log10(0.06), 10)
    ax.loglog(xs, 0.12 * (xs / xs[-1])**slope_depth, "k:", lw=0.8); ax.loglog(xs, 1.5 * (xs / xs[-1])**0.5, "k--", lw=0.8)
    ax.text(xs[-1] * 1.12, 0.12, {1.5: "3/2", 2.0: "2"}[slope_depth], fontsize=7.2, va="center"); ax.text(xs[-1] * 1.12, 1.5, "1/2", fontsize=7.2, va="center")
    ax.set_xlim(1e-3, 0.1); ax.set_ylim(4e-6, 4); ax.set_xlabel(xlabel); pow_ticks(ax, "both")
    ax.text(0.03, 0.97, fits, transform=ax.transAxes, fontsize=6.8, va="top")
    letter(ax, lab, title, x=LX, y=1.04)
tb0, x0, D0, S0, eD0, eS0 = scaling(*island(tracks_of(1, 0.05), (-0.3, 0.3)))
tb1, x1, D1, S1, eD1, eS1 = scaling(*island([q for q in tracks_of(50, 0.05) if 0.38 <= q["t"] <= 0.55], (-0.6, 0.3)))
ta2, x2, D2, S2, eD2, eS2 = scaling(*island([q for q in tracks_of(1000, 0.05) if 2.0 <= q["t"] <= 2.3], (0.0, 0.6)), reverse=True)
print(f"pitchfork-like: t_b = {tb0:.4f}, slopes {eD0:.2f}, {eS0:.2f} | fold: t_b = {tb1:.4f}, slopes {eD1:.2f}, {eS1:.2f} | inverse fold: t_a = {ta2:.4f}, slopes {eD2:.2f}, {eS2:.2f}")
panel_scaling(bot[0], x0, D0, S0, VIO, VIO2, 2.0, "e", "pitchfork-like scalings", r"time since the birth, $t-t_b$", f"fitted slopes {eD0:.2f} and {eS0:.2f}")
panel_scaling(bot[1], x1, D1, S1, TEAL, TEAL2, 1.5, "f", "fold scalings", r"time since the birth, $t-t_b$", f"fitted slopes {eD1:.2f} and {eS1:.2f}")
panel_scaling(bot[2], x2, D2, S2, ORA, ORA2, 1.5, "g", "inverse-fold scalings", r"time to the annihilation, $t_a-t$", f"fitted slopes {eD2:.2f} and {eS2:.2f}")
bot[0].set_ylabel(r"island depth / $\Psi_{\max}$;  O–X separation")
hb = [plt.Line2D([], [], marker="o", color=c, ms=4.2, lw=0) for c in ("#495057", "#adb5bd")]
bot[0].legend(hb, ["island depth", "O–X separation"], loc="lower right", handletextpad=0.3, borderaxespad=0.3, fontsize=6.8)
# h: depth histories of the shallow islands, transient (eps_B = 1000) and persistent (the chain at eta = 0.01)
ax = bot[3]; tr = tracks_of(1000, 0.05)
def envelope(a, dt=0.004):
    """maximum depth per record, as a line"""
    ts = np.unique(np.round(a[:, 0], 5)); return ts, np.array([a[np.isclose(a[:, 0], t), 2].max() for t in ts])
nk = o_islands(tr, 0.885, 1.1, (-0.3, 0.3)); t, d = envelope(nk); ax.semilogy(t, d, "-", color=ORA, lw=1.0, label="neck at the release (run of c)")
for zwin, lab in (((1.4, 3.0), "lobes (run of c)"), ((-3.0, -1.4), None)):
    t, d = envelope(o_islands(tr, 1.2, 1.5, zwin)); ax.semilogy(t, d, "-", color=RED, lw=1.0, label=lab)
ri = ring_islands(50, 0.01, dmin=2e-4)
ax.semilogy(ri[:, 0], ri[:, 2], "o", color=BLUE, ms=2.4, mew=0, label="neck chain (run of d)")
ax.axhline(1e-3, color=GREY, lw=0.6, ls=":"); ax.axhline(5e-2, color=GREY, lw=0.6, ls=":")
ax.text(3.95, 1.2e-3, "resolved", fontsize=6.3, ha="right", va="bottom", color="#495057"); ax.text(3.95, 6e-2, "separate ring", fontsize=6.3, ha="right", va="bottom", color="#495057")
ax.set_xlim(0.8, 4.0); ax.set_ylim(1e-4, 1); ax.set_xlabel("$t$"); ax.set_ylabel(r"island depth / $\Psi_{\max}$"); pow_ticks(ax, "y")
ax.legend(loc="upper left", handletextpad=0.3, borderaxespad=0.2, fontsize=6.8, handlelength=1.2)
letter(ax, "h", "shallow islands", x=LX, y=1.04)
out = HERE + "/out/Fig2.pdf"; fig.savefig(out); fig.savefig(out.replace(".pdf", ".png"), dpi=300); print("written", out)
