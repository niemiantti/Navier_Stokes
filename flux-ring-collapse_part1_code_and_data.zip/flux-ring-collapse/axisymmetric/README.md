# Axisymmetric code (leiren_bigbox_vs3b, version 3b.2)

This is the code that produced the runs of the paper. The five source files form the manifest whose SHA-256,
`44b2392165415c19ca2a6e41f00167b9803fec204ee2ddbd04e875a3322db793`, the production runs recorded; the command
`python3 -c "import run_safety, os; print(run_safety.source_manifest(os.getcwd())['sha256'])"` recomputes it here.
The files are stored unchanged.

- `openai_mhd_3d.py` is the model kernel: the imposed collapse flow (the leading-order inner profile of the
  reconstruction, with the column cutoff and the swirl), the Taylor-spheromak seed, the regular variables Psi/r^2
  and B_phi/r, the cell-centred grid, third-order upwind advection, second-order diffusion, the exact Poisson solve
  and SSP-RK3 time stepping with the Alfvén speed in the CFL condition, plus the energy and helicity diagnostics.
  Its docstring states the boundary conditions and the numerical choices.
- `leiren_bigbox_vs3b.py` runs one case from a parameter file (`--params`), tracks the critical points of the flux
  ridge every two steps (`track`), counts rings by a union-find sweep over the levels of Psi (`persistence_rings`),
  detects the split and measures the island-depth ratio (`fission_metrics`), applies the sudden release at t = 1
  with its continuity check, writes the data files and the figures of the run, and continues a finished run to a
  later time with `--extend NAME --set t_end=T`. `--check` runs the numerical checks of the implemented flow,
  `--preflight` the resolution report, `--status` lists the runs, `--plot NAME` redoes the outputs of a finished run.
- `configuration.py` holds the defaults, the validation and the fingerprint of a configuration, `checks.py` the
  numerical checks, `run_safety.py` the checkpoints, locks and the source manifest.
- `CHANGELOG.md` records the changes from the earlier versions, in particular from 3b.1 (with which the control
  runs of the Supplement were made) to 3b.2.

Every run of the paper uses `profile = leiren`. The code also contains an alternative background profile
(`profile = surrogate`, with the `surrogate_*` parameters), which no run of the paper uses; the parameters stay in
the files because they enter the configuration fingerprint.

Boundary conditions: at the walls the stream function, the vorticity and the angular velocity of the response vanish
(impenetrable, stress-free for the meridional flow, no-slip for the swirl) and Psi = 0 (perfectly conducting);
B_phi/r satisfies d_z(B_phi/r) = 0 at the axial walls and d_r(r B_phi) = 0 at the radial wall; on the axis Psi/r^2
and B_phi/r are regular (even reflection).

Needs numpy, scipy and matplotlib; `threadpoolctl` is optional.
