import json, glob, numpy as np, os
HERE = os.path.dirname(os.path.abspath(__file__))
def run_dir(eps, eta):
    g = glob.glob(f"{HERE}/data/results/LR_e{eps}_eta{eta}_unconfined_*/")
    return g[0] if g else HERE + "/data/results/legacy_geometry_unconfined_d87ab6fa32e4/"
def tracks_of(eps, eta): return json.load(open(run_dir(eps, eta) + "data/tracks.json"))
def o_islands(tracks, t0, t1, zwin=(-1e9, 1e9), dmax=0.5):
    """O-centric island depths: Psi(O) - max(adjacent X); drops main rings (depth > dmax)"""
    out = []
    for q in tracks:
        if not (t0 <= q["t"] <= t1): continue
        c = sorted(q["cps"], key=lambda x: x["z"])
        for i, x in enumerate(c):
            if x["kind"] != "O" or not (zwin[0] <= x["z"] <= zwin[1]): continue
            adj = [c[j]["psi"] for j in (i - 1, i + 1) if 0 <= j < len(c) and c[j]["kind"] == "X"]
            if not adj: continue
            d = x["psi"] - max(adj)
            if d <= dmax: out.append((q["t"], x["z"], d, x["r"]))
    return np.array(out)
if __name__ == "__main__":
    tr = tracks_of(1000, 0.05)
    print("t range", tr[0]["t"], tr[-1]["t"], len(tr))
    a = o_islands(tr, 0.85, 1.3, (-0.4, 0.4))
    print("neck eps1000: n", len(a), "max depth", a[:, 2].max() if len(a) else None)
    for tt in np.arange(0.86, 1.3, 0.02):
        s = a[(a[:, 0] >= tt) & (a[:, 0] < tt + 0.02)]
        if len(s): print(f"{tt:.2f} max {s[:,2].max():.5f} at z={s[s[:,2].argmax(),1]:+.3f}  n/record~{len(s)/max(1,len(set(np.round(s[:,0],4)))):.1f}")
    b = o_islands(tr, 1.2, 1.5, (1.4, 3.0)); c = o_islands(tr, 1.2, 1.5, (-3.0, -1.4))
    print("upper lobe: t", b[:, 0].min(), b[:, 0].max(), "max", b[:, 2].max(), "lower lobe:", c[:, 0].min(), c[:, 0].max(), c[:, 2].max())
    for tt in np.arange(1.2, 1.5, 0.02):
        s = b[(b[:, 0] >= tt) & (b[:, 0] < tt + 0.02)]; s2 = c[(c[:, 0] >= tt) & (c[:, 0] < tt + 0.02)]
        print(f"{tt:.2f} upper {s[:,2].max() if len(s) else 0:.4f} lower {s2[:,2].max() if len(s2) else 0:.4f}")
