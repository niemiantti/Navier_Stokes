"""Supplementary Table 4, upper block: the birth of the new island in the eps_B = 50, eta = 0.05 run on the production
lattice (384 x 1024) and on the 512 x 1365 repeat, from their critical-point tracks: the first detection of the island
with its depth and the height of the saddle, the times at which the island reaches the depths 1e-4, 1e-3 and 1e-2 of
the peak flux with the height of the saddle, the three critical points at depth 3e-3, the island-depth ratio at depth
1e-3, the medians of beta and of the ratio over the first fifteen records deeper than 5e-4 with the cusp prediction
R(beta), the fitted birth time and the growth exponents (the fits of the Methods). Writes refinement.json."""
from paths import *
import json, numpy as np
from silib import tracks_of, island, scaling, DZ
import cuspfit as Cf
os.chdir(CODE); import leiren_bigbox_vs3b as drv       # fission_metrics: the split time t_s of the driver

CASES = [("384 x 1024", tracks_of(50, 0.05), 1024), ("512 x 1365", json.load(open(DATA + "/controls/refinement/CTRL_fine_e50_eta0.05_512x1365/tracks.json")), 1365)]
ZWIN = (-0.65, 0.25)                      # the saddle of this fold is born below the midplane
out = {}
for name, tr, nz in CASES:
    T, D, Sp = island(tr, ZWIN, dmin=1e-5)
    res = dict(first_detection={})
    # the record of each threshold, with the saddle and the two maxima
    def record(th):
        for q in tr:
            c = sorted(q["cps"], key=lambda x: x["z"]); best = None
            for i, x in enumerate(c):
                if x["kind"] != "X" or i == 0 or i == len(c) - 1 or not (ZWIN[0] <= x["z"] <= ZWIN[1]): continue
                lo, hi = c[i - 1], c[i + 1]; d1, d2 = lo["psi"] - x["psi"], hi["psi"] - x["psi"]
                if min(d1, d2) > th and (best is None or min(d1, d2) > best[0]): best = (min(d1, d2), x, lo, hi, d1, d2)
            if best: return q["t"], best
        return None
    fm = drv.fission_metrics(tr)                 # t_s is interpolated between the last record without and the first with the island
    t0, (d0, x0, *_ ) = record(0.0)
    res["first_detection"] = dict(t_s=float(fm["t_s"]), first_record=float(t0), depth=float(d0), z_saddle=float(fm["z_birth"]))
    for th in (1e-4, 1e-3, 1e-2):
        t, (d, x, lo, hi, d1, d2) = record(th)
        res[f"depth_{th:g}_reached"] = dict(t=float(t), z_saddle=float(x["z"]))
        if th == 1e-3: res["ratio_at_1e-3"] = float(min(d1, d2) / max(d1, d2))
    t, (d, x, lo, hi, d1, d2) = record(3e-3); res["critical_points_at_3e-3"] = [float(lo["z"]), float(x["z"]), float(hi["z"])]
    rows = Cf.tracks_beta(tr, t_window=(t0 - 0.001, t0 + 0.06), dmin=5e-4)[:15]
    beta = float(np.median([r["beta"] for r in rows])); ratio = float(np.median([r["ratio"] for r in rows]))
    res["cusp"] = dict(beta=beta, ratio=ratio, R=float(Cf.cusp_ratio(beta)), records=len(rows))
    tb, x_, D_, Sp_, eD, eS, n = scaling(T, D, Sp, cells=3 * 1024 / nz)
    res["fit"] = dict(t_b=float(tb), depth_exponent=float(eD), separation_exponent=float(eS), records=int(n))
    out[name] = res
    fd = res["first_detection"]
    print(f"{name}: first detection t_s = {fd['t_s']:.4f} (depth {fd['depth']:.0e}, z = {fd['z_saddle']:+.3f}); "
          + "; ".join(f"depth {th:g} at t = {res[f'depth_{th:g}_reached']['t']:.4f} (z = {res[f'depth_{th:g}_reached']['z_saddle']:+.3f})" for th in (1e-4, 1e-3, 1e-2)))
    print(f"   critical points at 3e-3: {res['critical_points_at_3e-3']}; ratio at 1e-3: {res['ratio_at_1e-3']:.3f}; "
          f"median beta {beta:.3f}, ratio {ratio:.3f}, R(beta) {res['cusp']['R']:.3f}; t_b = {tb:.4f}, exponents {eD:.2f}, {eS:.2f} ({n} records)")
json.dump(out, open(HERE + "/refinement.json", "w"), indent=1)
