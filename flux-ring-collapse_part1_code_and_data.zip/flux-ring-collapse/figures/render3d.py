"""Render a 3D snapshot in the colour code of Fig. 1a: flux surfaces of the azimuthally averaged field, four layers per ring
(red, orange, green: surfaces enclosing 10, 40 and 70 % of the ring's own flux about its magnetic axis; blue: the outer
surface at 5 % of the peak flux), revolved about the axis with the staircase cut-away (1.85, 1.6, 1.35, 1.1 pi), and
magnetic field lines integrated in the full three-dimensional field, drawn as thin tubes coloured by |B|.
usage: python3 render3d.py prep.npz snap3d.npz out.png W H half_height zc seeds.json"""
import sys, json, numpy as np, contourpy, pyvista as pv
from matplotlib.path import Path
from scipy import ndimage
from scipy.ndimage import map_coordinates
pv.OFF_SCREEN = True
try: pv.start_xvfb()
except Exception: pass

prep, snap, out = sys.argv[1], sys.argv[2], sys.argv[3]
W, H = int(sys.argv[4]), int(sys.argv[5]); half = float(sys.argv[6]); zc = float(sys.argv[7])
opts = json.loads(open(sys.argv[8]).read()) if len(sys.argv) > 8 else {}
D = np.load(prep); r, z, Psi = D["r"].astype(float), D["z"].astype(float), D["PsiA"].astype(float)
pm = Psi.max()
LAYERS = ((0.9, "#d7301f", 1.0, 1.85), (0.6, "#fc8d59", 1.0, 1.6), (0.3, "#41ab5d", 1.0, 1.35))
BLUE = ("#6baed6", float(opts.get("blue_opacity", 0.55)), 1.1)

def persistence_rings(P, r_lim):
    """flux maxima with their depth below the pass to a higher maximum (union-find over the levels, as in the scan)"""
    nr_, nz_ = P.shape; flat = P.ravel(); order = np.argsort(-flat, kind="stable")
    parent = np.full(flat.size, -1, dtype=np.int64); top = np.zeros(flat.size, dtype=np.int64); death = {}
    def find(i):
        root = i
        while parent[root] != root: root = parent[root]
        while parent[i] != root: parent[i], i = root, parent[i]
        return root
    for idx in order:
        parent[idx] = idx; top[idx] = idx; i, j = divmod(int(idx), nz_); roots = set()
        for ii, jj in ((i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)):
            if 0 <= ii < nr_ and 0 <= jj < nz_:
                n = ii * nz_ + jj
                if parent[n] != -1: roots.add(find(n))
        if roots:
            best = max(roots, key=lambda q: flat[top[q]])
            for q in roots:
                if q != best: death[int(top[q])] = float(flat[idx]); parent[q] = best
            parent[idx] = best
    mx = (P == ndimage.maximum_filter(P, size=5)) & (P > 0.01 * flat.max()); rings = []
    for i, j in zip(*np.nonzero(mx)):
        k = i * nz_ + j
        if k in death and r[i] <= r_lim: rings.append(dict(depth=float((flat[k] - death[k]) / flat.max()), r=float(r[i]), z=float(z[j]), psi=float(flat[k])))
    return sorted(rings, key=lambda x: -x["depth"])

rings = persistence_rings(Psi, 3.0); im = np.unravel_index(np.argmax(Psi), Psi.shape)
sec = [q for q in rings if q["depth"] >= 0.05]
items = [((r[im[0]], z[im[1]]), pm, True)] + [((q["r"], q["z"]), q["psi"], False) for q in sec]
print("magnetic axes (r, z, depth):", [(round(r[im[0]], 3), round(z[im[1]], 3), 1.0)] + [(round(q["r"], 3), round(q["z"], 3), round(q["depth"], 3)) for q in sec])
gen = contourpy.contour_generator(r, z, Psi.T)
surfaces = [(seg, BLUE[0], BLUE[1], BLUE[2]) for seg in gen.lines(0.05 * pm) if len(seg) > 8]
p_pass = max(q["psi"] - q["depth"] * pm for q in sec) if sec else 0.05 * pm
layer_contours = {}
for k, (pt, pO, main) in enumerate(items):
    d_eff = (pO - p_pass) if main else [q for q in sec if (q["r"], q["z"]) == pt][0]["depth"] * pm
    for frac, col, al, ang in LAYERS:
        lev = pO - (1 - frac) * d_eff
        segs = [sg for sg in gen.lines(lev) if len(sg) > 8 and Path(sg).contains_point(pt)]
        if segs:
            sg = min(segs, key=len); surfaces.append((sg, col, al, ang)); layer_contours[(k, col)] = sg

pl = pv.Plotter(off_screen=True, window_size=(W, H), lighting="three lights"); pl.set_background("white")
NPH = 180
for seg, col, al, ang in surfaces:
    rs, zs = seg[:, 0], seg[:, 1]; PH = np.linspace(0, ang * np.pi, NPH)
    X = rs[:, None] * np.cos(PH)[None, :]; Y = rs[:, None] * np.sin(PH)[None, :]; Z = np.repeat(zs[:, None], len(PH), axis=1)
    pl.add_mesh(pv.StructuredGrid(X, Y, Z), color=col, opacity=al, smooth_shading=True, specular=0.35, specular_power=20)

# ---------------------------------------------------------------- field lines in the full 3D field
lines_info = []
if opts.get("seeds"):
    F = np.load(snap); x, y, zz = F["x"].astype(float), F["y"].astype(float), F["z"].astype(float)
    B = F["B"].astype(np.float32); hx, hy, hz = x[1] - x[0], y[1] - y[0], zz[1] - zz[0]
    Bm = np.sqrt((B**2).sum(0))
    def sample(Fld, q):
        idx = np.array([(q[:, 0] - x[0]) / hx, (q[:, 1] - y[0]) / hy, (q[:, 2] - zz[0]) / hz])
        return map_coordinates(Fld, idx, order=1, mode="nearest")
    def tangent(q):
        b = np.stack([sample(B[c], q) for c in range(3)], axis=1); m = np.linalg.norm(b, axis=1) + 1e-12
        return b / m[:, None]
    seeds = []
    for s in opts["seeds"]:
        # {"ring": k, "layer": colour, "phis": [...]}: the outboard point of that layer's contour at the height of the axis
        if "ring" in s:
            sg = layer_contours[(s["ring"], s["layer"])]; ax_z = items[s["ring"]][0][1]
            kk = np.argmax(sg[:, 0] - 10 * np.abs(sg[:, 1] - ax_z)); r0, z0 = sg[kk]
            if s.get("inboard"): kk = np.argmin(sg[:, 0] + 10 * np.abs(sg[:, 1] - ax_z)); r0, z0 = sg[kk]
            for ph in s["phis"]: seeds.append((r0 * np.cos(ph), r0 * np.sin(ph), z0, s.get("length", 30.0), s.get("tag", "ring")))
        else:   # explicit points (r, phi, z)
            for (r0, ph, z0) in s["points"]: seeds.append((r0 * np.cos(ph), r0 * np.sin(ph), z0, s.get("length", 30.0), s.get("tag", "pt")))
    ds = float(opts.get("ds", 0.01)); vmax = float(opts.get("bmax", Bm.max()))
    import matplotlib
    from matplotlib.colors import LinearSegmentedColormap
    cmap = LinearSegmentedColormap.from_list("lines", matplotlib.colormaps[opts.get("cmap", "Purples")](np.linspace(0.5, 1.0, 256)))
    for (sx, sy, sz, L, tg) in seeds:
        for sgn in (1.0, -1.0):
            q = np.array([[sx, sy, sz]]); P = [q[0].copy()]
            for _ in range(int(0.5 * L / ds)):
                k1 = tangent(q); k2 = tangent(q + 0.5 * ds * sgn * k1); k3 = tangent(q + 0.5 * ds * sgn * k2); k4 = tangent(q + ds * sgn * k3)
                q = q + ds * sgn * (k1 + 2 * k2 + 2 * k3 + k4) / 6
                if not (x[0] + 0.3 < q[0, 0] < x[-1] - 0.3 and y[0] + 0.3 < q[0, 1] < y[-1] - 0.3 and zz[0] + 0.3 < q[0, 2] < zz[-1] - 0.3): break
                P.append(q[0].copy())
            P = np.array(P)
            if sgn < 0: Pm = P[::-1]
            else: Pp = P
        Lp = np.vstack([Pm[:-1], Pp])
        # the flux of the average along the line: how far the line wanders across the averaged surfaces
        rr = np.hypot(Lp[:, 0], Lp[:, 1]); psi_line = map_coordinates(Psi, [rr / (r[1] - r[0]), (Lp[:, 2] - z[0]) / (z[1] - z[0])], order=1, mode="nearest")
        lines_info.append(dict(tag=tg, seed=[sx, sy, sz], n=len(Lp), psi_min=float(psi_line.min() / pm), psi_max=float(psi_line.max() / pm),
                               psi_seed=float(psi_line[len(Pm) - 1] / pm), zmin=float(Lp[:, 2].min()), zmax=float(Lp[:, 2].max())))
        poly = pv.lines_from_points(Lp[::2]); poly["B"] = sample(Bm, Lp[::2])
        pl.add_mesh(poly.tube(radius=float(opts.get("tube", 0.016)), n_sides=10), scalars="B", cmap=cmap, clim=(0.0, vmax), smooth_shading=True,
                    specular=0.3, show_scalar_bar=False)
    print("field lines: |B| colour range 0 -", vmax)
    for li in lines_info: print("  ", li["tag"], "seed", np.round(li["seed"], 2), "points", li["n"], "Psi_avg/pm along the line %.3f-%.3f (seed %.3f), z %.2f..%.2f" % (li["psi_min"], li["psi_max"], li["psi_seed"], li["zmin"], li["zmax"]))
pl.enable_parallel_projection()
cam = opts.get("cam", [0.3, -4.0, 0.9])
pl.camera_position = [(cam[0] * 10, cam[1] * 10, cam[2] * 10 + zc), (0, 0, zc), (0, 0, 1)]; pl.camera.parallel_scale = half
pl.enable_anti_aliasing("ssaa"); pl.screenshot(out); pl.close()
json.dump(dict(axes=[[float(items[0][0][0]), float(items[0][0][1]), 1.0]] + [[q["r"], q["z"], q["depth"]] for q in sec], lines=lines_info,
               bmax=float(opts.get("bmax", 0)) or None), open(out.replace(".png", ".json"), "w"), indent=1)
print("written", out)
