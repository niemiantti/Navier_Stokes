"""Atomic files, independent run identities, and non-destructive checkpoints."""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import hashlib
import json
import os
import socket
import tempfile
import time
import uuid
import numpy as np


class RunStopped(RuntimeError):
    """A recoverable controlled stop (last accepted finite state is retained)."""


def atomic_text(path,text):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.'+path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            f.write(text); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    return str(path)


def atomic_json(path,obj):
    return atomic_text(path,json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n')


def read_json(path):
    with Path(path).open(encoding='utf-8') as f:
        return json.load(f)


def load_npz(path):
    try:
        with np.load(path,allow_pickle=False) as c:
            return {k:c[k] for k in c.files}
    except (OSError,ValueError,EOFError,KeyError):
        return None
    except Exception as e:
        # Corrupt ZIP central directory, compression error, etc.
        import zipfile,zlib
        if isinstance(e,(zipfile.BadZipFile,zlib.error)):
            return None
        raise


def atomic_npz(path,compressed=False,overwrite=False,**arrays):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() and not overwrite:
        old=load_npz(path)
        if old is None:
            raise RuntimeError(f"Existing unreadable snapshot {path}. Preserve/rename it before retrying; not silently overwritten.")
        for key in ('t','config_sha256','code_sha256'):
            if key in arrays and (key not in old or not np.array_equal(old[key],np.asarray(arrays[key]))):
                raise RuntimeError(f"Existing snapshot identity differs ({key}): {path}")
        return str(path)
    fd,tmp=tempfile.mkstemp(prefix='.'+path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            (np.savez_compressed if compressed else np.savez)(f,**arrays)
            f.flush(); os.fsync(f.fileno())
        if load_npz(tmp) is None:
            raise RuntimeError(f"Checkpoint/snapshot failed read-back validation: {tmp}")
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    return str(path)


def source_manifest(here):
    here=Path(here)
    names=('openai_mhd_3d.py','leiren_bigbox_vs3b.py','configuration.py','checks.py','run_safety.py')
    hashes={name:hashlib.sha256((here/name).read_bytes()).hexdigest() for name in names}
    digest=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
    return dict(sha256=digest,files=hashes)


def initialize_directory(rdir,d,sources):
    """Reject foreign/mismatched data, including an old finished marker."""
    rdir=Path(rdir); rdir.mkdir(parents=True,exist_ok=True)
    cfg=rdir/'config.json'
    if cfg.exists():
        stored=read_json(cfg)
        if stored.get('config_sha256')!=d['config_sha256']:
            raise RuntimeError(f"Configuration mismatch in {rdir}; refuse to mix two experiments")
        if stored.get('code_sha256')!=sources['sha256']:
            raise RuntimeError(f"Source code changed since this run was prepared: {rdir}. Use a new runs_dir; old data is untouched.")
        if stored.get('parameters')!=d:
            # Operational changes such as thread count are allowed, physics hash
            # has already been checked. Keep original metadata and log resume.
            pass
    else:
        other=[p.name for p in rdir.iterdir() if p.name!='.run.lock']
        if other:
            raise RuntimeError(f"Nonempty output folder has no vs3b config.json: {rdir}. Nothing will be deleted.")
        atomic_json(cfg,dict(config_sha256=d['config_sha256'],code_sha256=sources['sha256'],
                             sources=sources,parameters=d,created=time.time()))
    return rdir


def checkpoint_paths(rdir):
    return sorted(Path(rdir).glob('checkpoint_*.npz'),reverse=True)


def valid_checkpoint(c,d,sources):
    if c is None or any(k not in c for k in ('zeta','a','P','q','t','step','handed','config_sha256','code_sha256')):
        return False
    if str(c['config_sha256'])!=d['config_sha256'] or str(c['code_sha256'])!=sources['sha256']:
        return False
    if not np.isfinite(float(c['t'])) or not d['t_start']-1e-12<=float(c['t'])<=d['t_end']+1e-12:
        return False
    if any(c[k].shape!=(d['nr'],d['nz']) or not np.all(np.isfinite(c[k])) for k in ('zeta','a','P','q')):
        return False
    return True


def load_checkpoint(rdir,d,sources):
    # Newest step first, without holding all checkpoint arrays in memory.
    for path in checkpoint_paths(rdir):
        c=load_npz(path)
        if valid_checkpoint(c,d,sources):
            return c,str(path)
    return None,None


def save_checkpoint(rdir,d,sources,ctx):
    """Retain several verified generations, including after SUCCESS or FAILURE."""
    state=ctx['state']
    if any(not np.all(np.isfinite(a)) for a in state):
        raise RuntimeError("Refuse to checkpoint a nonfinite state")
    path=Path(rdir)/f"checkpoint_{ctx['step']:010d}_{time.time_ns()}_{uuid.uuid4().hex[:6]}.npz"
    arrays=dict(zip(('zeta','a','P','q'),state))
    meta={k:ctx[k] for k in ('t','step','handed','done','release_info')}
    arrays.update(t=ctx['t'],step=ctx['step'],handed=ctx['handed'],
                  metadata=np.array(json.dumps(meta,allow_nan=False)),
                  tracks=np.array(json.dumps(ctx['tracks'],allow_nan=False)),
                  diag=np.array(json.dumps(ctx['diag'],allow_nan=False)),
                  config_sha256=np.array(d['config_sha256']),code_sha256=np.array(sources['sha256']))
    atomic_npz(path,**arrays)
    if not valid_checkpoint(load_npz(path),d,sources):
        raise RuntimeError("New checkpoint failed validation; old generations retained")
    # Only rotate after validation. Other output files are never removed.
    good=[]
    for f in checkpoint_paths(rdir):
        if valid_checkpoint(load_npz(f),d,sources):
            good.append(f)
    for old in good[d['checkpoint_keep']:]:
        old.unlink()
    return str(path)


def context_from_checkpoint(c):
    m=json.loads(str(c['metadata']))
    m['state']=[c[k] for k in ('zeta','a','P','q')]
    m['tracks']=json.loads(str(c['tracks']))
    m['diag']=json.loads(str(c['diag']))
    return m


@contextmanager
def run_lock(rdir):
    rdir=Path(rdir); rdir.mkdir(parents=True,exist_ok=True)
    path=rdir/'.run.lock'
    token=uuid.uuid4().hex
    try:
        fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError:
        try: owner=read_json(path)
        except Exception: owner='unreadable lock'
        raise RuntimeError(f"Run is locked: {path}; owner={owner}. Use --unlock only after confirming the old process has stopped.") from None
    with os.fdopen(fd,'w') as f:
        json.dump(dict(pid=os.getpid(),host=socket.gethostname(),time=time.time(),token=token),f)
    try:
        yield
    finally:
        try:
            if read_json(path).get('token')==token:
                path.unlink()
        except FileNotFoundError:
            pass


def unlock_stale(rdir):
    path=Path(rdir)/'.run.lock'
    if not path.exists(): return 'No lock exists.'
    owner=read_json(path)
    if owner['host']!=socket.gethostname():
        raise RuntimeError('Lock belongs to another host; do not remove it without checking that machine.')
    try:
        os.kill(int(owner['pid']),0)
    except ProcessLookupError:
        path.unlink()
        return 'Removed stale local lock; no simulation files were changed.'
    except PermissionError:
        raise RuntimeError('Cannot check lock owner process; lock retained.') from None
    raise RuntimeError(f"Process {owner['pid']} still exists; lock retained.")


def archive_future_snapshots(rdir,t,handed,t_off):
    """After fallback/resume, preserve snapshots newer than the accepted state.

    Never mix a re-integrated trajectory with snapshots from a discarded future.
    Files are moved (not deleted) to a recovery archive, then regenerated.
    """
    import re
    root=Path(rdir); files=[]
    for f in list(root.glob('light_t*.npz'))+list(root.glob('full_t*.npz')):
        m=re.match(r'^(?:light|full)_t(\d+(?:\.\d+)?)(?:_|\.npz$)',f.name)
        if m is None: continue
        try: stamp=float(m.group(1))
        except ValueError: continue
        uncommitted_handover=(not handed and abs(t-t_off)<1e-12 and abs(stamp-t)<1e-12 and '_after_release' in f.name)
        if stamp>t+1e-12 or uncommitted_handover:
            files.append(f)
    if not files: return None
    archive=root/'recovery_archive'/f"after_t{t:.9f}_{time.time_ns()}"
    archive.mkdir(parents=True)
    for f in files: os.replace(f,archive/f.name)
    atomic_json(archive/'reason.json',dict(restored_time=t,reason='These snapshots were beyond the accepted checkpoint state; retained but not used.'))
    return str(archive)
