"""Energies, helicity and ridge critical points from the light snapshots of a run (used for the continuation of the
switch-off run beyond t = 2.5, data/controls/release/light_to4.json).
usage: python3 lightdiag.py RUN_DIR OUT.json    (RUN_DIR holds config.json and the light_t*.npz snapshots)"""
import sys, os, json, glob, numpy as np
from paths import *
os.chdir(CODE)
import openai_mhd_3d as mhd, configuration as cfg, run_safety as safe
import leiren_bigbox_vs3b as drv
from sifigs import ridge_points
src, out = sys.argv[1], sys.argv[2]
old = json.load(open(src + "/config.json"))["parameters"]
raw = {k: v for k, v in old.items() if k not in cfg.GENERATED and k in cfg.DEFAULTS}
d = cfg.finish_params(raw); p = cfg.make_params(d); g = mhd.Grid(p); r = g.rc
rows = []
for f in sorted(glob.glob(src + "/light_t*.npz")):
    a = np.load(f); t = float(a["t"])
    S_tot = a["chi"].astype(np.float64) / r**2
    state = [-g.L5(g.pad(S_tot)), a["Omega"].astype(np.float64), a["Psi"].astype(np.float64) / r**2, a["Bphi"].astype(np.float64) / r]
    drv.set_background_phase(p, t, d, True)
    dg = mhd.diagnostics(g, state, 1 - t)
    cps, _ = ridge_points(a["Psi"], g.r, g.z)
    rows.append(dict(t=t, K=float(dg["K"]), M=float(dg["M"]), H=float(dg["H"]), cps=cps)); print("t=%.3f K=%.4f M=%.4f H=%.6f  cps=%s" % (t, dg["K"], dg["M"], dg["H"], [(c["kind"], round(c["z"], 2)) for c in cps]), flush=True)
json.dump(rows, open(out, "w"), indent=1)
