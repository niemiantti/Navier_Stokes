import os, json, glob, csv, numpy as np
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
def rd(fn):
    rows = list(csv.DictReader(open(fn)))
    return {k: np.array([float(r[k]) if r[k] not in ("", None) else np.nan for r in rows]) for k in rows[0]}
D3 = rd(B + "/figures/data/three_dimensional/e50_eta0.01_nu0.1_N256_box4x4x5.5/diag.csv")
print("3D e50 diag columns:", list(D3.keys()))
D2a = rd(glob.glob(B + "/figures/data/results/LR_e50_eta0.01_*/data/diag.csv")[0])
D2b = rd(B + "/figures/data/results/legacy_geometry_unconfined_d87ab6fa32e4/data/diag.csv")
S = {k: {kk: np.array(vv) for kk, vv in v.items()} for k, v in json.load(open(B + "/figures/data/three_dimensional/e1000_eta0.05_nu0.1_N256_box5x5x7/e1000_series.json")).items()}
print("e1000 series keys:", list(S.keys()), {k: len(S[k]["t"]) for k in S})
print("3D e50 t range %.3f-%.3f n=%d; H0_3D=%.6g H0_2D=%.6g; M0_3D=%.6g M0_2D=%.6g" % (D3["t"][0], D3["t"][-1], len(D3["t"]), D3["H"][0], D2a["H"][0], D3["M"][0], D2a["M"][0]))
print("e1000 series: H v0=%.6g (2D |H0|=%.6g), M v0=%.6g (2D M0=%.6g); t ranges M %.3f-%.3f H %.3f-%.3f" % (S["H"]["v"][0], abs(D2b["H"][0]), S["M"]["v"][0], D2b["M"][0], S["M"]["t"].min(), S["M"]["t"].max(), S["H"]["t"].min(), S["H"]["t"].max()))
def cmp(name, t3, M3, tH, H3, D2, ts):
    # 2D values: for the release (two rows at t=1) use interpolation on unique times
    t2, i = np.unique(D2["t"], return_index=True)
    M2 = np.interp(t3, t2, D2["M"][i]); dM = 100 * (M3 / M2 - 1)
    H2 = np.interp(tH, t2, np.abs(D2["H"][i])); H20 = abs(D2["H"][0]); dH = 100 * (np.abs(H3) - H2) / H20
    print(f"== {name}: split t_s={ts}")
    for lo, hi, lab in ((0, ts, "before split"), (0, 1.0 + 1e-9, "through release (t<=1)"), (0, 1.2, "t<1.2"), (0, 3.0 + 1e-9, "to t=3"), (3.0, 4.01, "3<t<=4"), (0, 4.01, "all")):
        k = (t3 >= lo) & (t3 < hi)
        if k.any(): print(f"   {lab:24s} max|dM| = {np.max(np.abs(dM[k])):.2f}% (at t={t3[k][np.argmax(np.abs(dM[k]))]:.3f})")
    k4 = np.argmin(np.abs(t3 - 4.0)); print(f"   dM at t={t3[k4]:.3f}: {dM[k4]:+.2f}%")
    print(f"   max|dH|/H0 over all t: {np.max(np.abs(dH)):.3f}% (at t={tH[np.argmax(np.abs(dH))]:.3f}); range of tH {tH.min():.3f}-{tH.max():.3f}")
    return dM, dH
cmp("eps=50 eta=0.01", D3["t"], D3["M"], D3["t"], D3["H"], D2a, 0.7033)
cmp("eps=1000 eta=0.05", S["M"]["t"], S["M"]["v"], S["H"]["t"], S["H"]["v"], D2b, 0.8808)
# modes
def modes(name, t, na, m1, m2, t1=None, t2=None):
    print(f"== modes {name}")
    for lab, tt, v in (("all m>=1", t, na), ("m=1", t1 if t1 is not None else t, m1), ("m=2", t2 if t2 is not None else t, m2)):
        i = np.nanargmax(v); j0 = 0; j1 = np.argmin(np.abs(tt - 1.0))
        print(f"   {lab:9s} max {100*v[i]:.2f}% at t={tt[i]:.3f}; initial (t={tt[0]:.3f}) {v[0]:.2e}; at t={tt[j1]:.3f}: {v[j1]:.2e}")
modes("eps=50", D3["t"], D3["nonaxi"], D3["m1"], D3["m2"])
modes("eps=1000", S["nonaxi"]["t"], S["nonaxi"]["v"], S["m1"]["v"], S["m2"]["v"], S["m1"]["t"], S["m2"]["t"])
# values right before / after release
for nm, t, v in (("e50 nonaxi", D3["t"], D3["nonaxi"]), ("e1000 nonaxi", S["nonaxi"]["t"], S["nonaxi"]["v"])):
    k = (t > 0.95) & (t < 1.05); print(nm, "t in (0.95,1.05):", np.round(t[k], 3)[:6], ["%.2e" % x for x in v[k][:6]])
# first few values
print("e50 first rows nonaxi:", ["%.2e@%.3f" % (a, b) for a, b in zip(D3["nonaxi"][:5], D3["t"][:5])])
print("e1000 first pts nonaxi:", ["%.2e@%.3f" % (a, b) for a, b in zip(S["nonaxi"]["v"][:5], S["nonaxi"]["t"][:5])])
print("e1000 first pts m1:", ["%.2e@%.3f" % (a, b) for a, b in zip(S["m1"]["v"][:3], S["m1"]["t"][:3])], "m2:", ["%.2e@%.3f" % (a, b) for a, b in zip(S["m2"]["v"][:3], S["m2"]["t"][:3])])
print("---- windows")
t2, i = np.unique(D2a["t"], return_index=True)
dM50 = 100 * (D3["M"] / np.interp(D3["t"], t2, D2a["M"][i]) - 1)
for lo, hi in ((0, 0.7033), (0.7033, 1.0), (1.0, 1.2), (1.0, 3.0), (1.2, 3.0), (1.1, 3.0), (1.15, 3.0), (3.0, 4.01)):
    k = (D3["t"] > lo) & (D3["t"] <= hi)
    print(f"  e50 ({lo},{hi}]: max|dM| {np.max(np.abs(dM50[k])):.2f}% at t={D3['t'][k][np.argmax(np.abs(dM50[k]))]:.2f}")
k = (D3["t"] > 0.98) & (D3["t"] < 1.3); print("  e50 dM t=0.98..1.3:", [f"{a:.2f}@{b:.2f}" for a, b in zip(dM50[k], D3["t"][k])])
print("  e50 final values: nonaxi %.2e m1 %.2e m2 %.2e at t=%.2f" % (D3["nonaxi"][-1], D3["m1"][-1], D3["m2"][-1], D3["t"][-1]))
print("  e1000 final values: nonaxi %.2e m1 %.2e m2 %.2e" % (S["nonaxi"]["v"][-1], S["m1"]["v"][-1], S["m2"]["v"][-1]))
print("  e1000 nonaxi series:", [f"{a:.2e}@{b:.2f}" for a, b in zip(S["nonaxi"]["v"], S["nonaxi"]["t"])])
print("  e1000 m1 series:", [f"{a:.2e}@{b:.2f}" for a, b in zip(S["m1"]["v"], S["m1"]["t"])])
