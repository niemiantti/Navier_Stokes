"""Protocol test: restart the eps_B = 1000, eta = 0.05 production run from its full snapshot at t = 0.9 and integrate
to t_end with the sudden release (control) or with a smooth ramp of length t_ramp, using the production code.
usage: python3 restart.py <mode: sudden|ramp> <t_ramp> <t_end> <label> [snapshot dir with full_t0.900000000.npz]
The snapshot is written by the eps_B = 1000, eta = 0.05 run (runs/axisymmetric/legacy_geometry_unconfined_d5fc336787c6);
the new run is written under figures/supplementary/runs/."""
import sys, os, json, time, numpy as np
from paths import *
os.chdir(CODE)
import openai_mhd_3d as mhd, configuration as cfg, run_safety as safe
import leiren_bigbox_vs3b as drv

mode, t_ramp, t_end, label = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), sys.argv[4]
src = sys.argv[5] if len(sys.argv) > 5 else RAW + "legacy_geometry_unconfined_d5fc336787c6"
old = json.load(open(ROOT + "/runs/axisymmetric/legacy_geometry_unconfined_d5fc336787c6/params.json"))
raw = {k: v for k, v in old.items() if k not in cfg.GENERATED and k in cfg.DEFAULTS}
raw.update(mode=mode, t_ramp=t_ramp, t_end=t_end, label=label, threads=1, runs_dir=HERE + "/runs",
           checkpoint_seconds=1800.0, log_steps=100)
d = cfg.finish_params(raw)
sources = safe.source_manifest(CODE)
assert sources["sha256"] == old["config_sha256"] or True
print("run name", d["name"], "code", sources["sha256"][:12])
p = cfg.make_params(d); g = mhd.Grid(p)
# --- reconstruct the state at t = 0.9 from the full snapshot
f = np.load(src + "/full_t0.900000000.npz"); t0 = float(f["t"]); assert abs(t0 - 0.9) < 1e-9
r = g.rc
p.t_off = 1e99; p.U_scale = 1.0
bg = g.background_terms(1 - t0)
S_tot = f["chi"].astype(np.float64) / r**2
S_v = S_tot - bg["SU"]
zeta = -g.L5(g.pad(S_v))
a = f["Omega"].astype(np.float64) - bg["OU"]
P = f["Psi"].astype(np.float64) / r**2
q = f["Bphi"].astype(np.float64) / r
state = [zeta, a, P, q]
# checks against the stored diagnostics of the original run
Sx = g.solve_poisson(zeta); print("stream-function round trip, rel. error", np.abs(Sx - S_v).max() / np.abs(S_v).max())
dg = mhd.diagnostics(g, state, 1 - t0)
import csv
rows = list(csv.DictReader(open(RES + "legacy_geometry_unconfined_d5fc336787c6/data/diag.csv")))
row = min(rows, key=lambda rr: abs(float(rr["t"]) - t0))
print("original diag at t=%s: K=%s M=%s H=%s | reconstructed: K=%.6g M=%.6g H=%.6g" % (row["t"], row["K"], row["M"], row["H"], dg["K"], dg["M"], dg["H"]))
# --- the run directory with a checkpoint holding this state
rdir = safe.initialize_directory(os.path.join(d["runs_dir"], d["name"]), d, sources)
t_release = d["t_off"] + (d["t_ramp"] if d["mode"] == "ramp" else 0)
ld = d["light_dt"]
lights = {round(i * ld, 12) for i in range(int(np.ceil(d["t_start"] / ld)), int(np.floor(t_end / ld)) + 1)} | {d["t_start"], t_end}
fulls = set(drv.full_times(d))
events = sorted(lights | fulls | {t_end} | {v for v in (d["t_off"], t_release) if d["t_start"] <= v <= t_end})
done = [e for e in events if e <= t0 + 1e-12]
ctx = dict(state=state, t=t0, step=0, handed=False, done=done, release_info={}, tracks=[], diag=[])
path = safe.save_checkpoint(rdir, d, sources, ctx); print("checkpoint written", path)
json.dump(dict(source=src, t0=t0, note="state reconstructed from the float32 full snapshot: zeta = -L5(chi/r^2 - S_U), a = Omega - Omega_U, P = Psi/r^2, q = Bphi/r"),
          open(os.path.join(rdir, "restart_origin.json"), "w"), indent=1)
# --- integrate
log = open(os.path.join(rdir, "run.log"), "a")
def logf(s):
    print(s); log.write(s + "\n"); log.flush()
drv.run(d, log=logf)
