"""Supplementary Figure 4: the source of the asymmetry of the fold (controls at eps_B = 50, eta = 0.05).
a, the resolved critical points of the ridge against time for the reference run (j = 0.001, seed twist sigma = -1),
the control without the offset (j = 0) and the control with the twist reversed (sigma = +1); b, ridge profiles of
the two controls at t = 0.40 and 0.45, mirror images of each other; c, the toroidal-field energy in the odd part of
B_phi relative to the even part, and the up-down antisymmetric axial velocity of the response at the magnetic axis,
against time, for the two controls and for the eps_B = 1 run.
Inputs: data/results (the reference run), data/controls/symmetry (tracks of the controls, the ridge profiles at
t = 0.40 and 0.45 and the asymmetry series asym_*.json written by asym.py)."""
from paths import *
import json, csv, numpy as np
from sifigs import *
CTRL = DATA + "/controls/symmetry/"
RED, BLUE = C_ETA[0.05], C_ETA[0.01]
def run(name): return CTRL + name + "_e50_eta0.05/"
ref = tracks_of(50, 0.05); j0 = json.load(open(run("CTRL_j0") + "tracks.json")); tw = json.load(open(run("CTRL_twist") + "tracks.json"))
fig = plt.figure(figsize=(WIDTH, 62 * MM))
axa = fig.add_axes([0.06, 0.16, 0.36, 0.74]); axb = fig.add_axes([0.50, 0.16, 0.20, 0.74]); axc = fig.add_axes([0.78, 0.16, 0.20, 0.74])
def points(ax, tr, tw_, colO, colX, ms, label=None):
    TO, ZO, TX, ZX = [], [], [], []
    for q in tr:
        if tw_[0] <= q["t"] <= tw_[1]:
            for x in resolve(q["cps"]):
                (TO if x["kind"] == "O" else TX).append(q["t"]); (ZO if x["kind"] == "O" else ZX).append(x["z"])
    ax.plot(TX, ZX, ".", color=colX, ms=ms, mew=0, rasterized=True); ax.plot(TO, ZO, ".", color=colO, ms=ms + 0.4, mew=0, rasterized=True, label=label)
TW = (0.36, 0.62)
points(axa, ref, TW, GOLD, "k", 2.6)
points(axa, j0, TW, BLUE, BLUE, 1.3)
points(axa, tw, TW, RED, RED, 1.3)
axa.set_xlim(*TW); axa.set_ylim(-1.1, 1.1); axa.set_xlabel("$t$"); axa.set_ylabel("$z$ of the critical points")
axa.axhline(0, color=GREY, lw=0.4, ls=":")
h = [plt.Line2D([], [], color=GOLD, marker="o", ms=3.4, lw=0, label="reference, axes (O)"), plt.Line2D([], [], color="k", marker="o", ms=3.4, lw=0, label="reference, saddles (X)"),
     plt.Line2D([], [], color=BLUE, marker="o", ms=2.2, lw=0, label="$j = 0$ (no offset)"), plt.Line2D([], [], color=RED, marker="o", ms=2.2, lw=0, label="twist of the seed reversed")]
axa.legend(handles=h, loc="lower left", fontsize=6.0, handletextpad=0.2, borderaxespad=0.3)
A = dict(fontsize=6.2, arrowprops=dict(arrowstyle="-", lw=0.5, color="#495057"))
axa.annotate("saddle of the reference and of $j = 0$,\nborn at $t = 0.416$, $z = -0.18$", (0.46, -0.08), xytext=(0.50, -0.50), ha="left", **A)
axa.annotate("saddle with the twist reversed,\nborn at $t = 0.414$, $z = +0.17$", (0.46, 0.07), xytext=(0.50, 0.40), ha="left", **A)
letter(axa, "a", "critical points of the ridge, reference and controls", x=-0.13, y=1.03)
# b: ridge profiles of the two controls at 0.40 and 0.45 (data/controls/symmetry/ridge_profiles_t0.40_0.45.csv)
PROF = {}
for row in csv.DictReader(open(CTRL + "ridge_profiles_t0.40_0.45.csv")):
    PROF.setdefault((row["control"], float(row["t"])), []).append((float(row["z"]), float(row["ridge_over_Psi_max"])))
for name, col in (("CTRL_j0", BLUE), ("CTRL_twist", RED)):
    for t, ls in ((0.40, "-"), (0.45, "--")):
        zr = np.array(PROF[(name + "_e50_eta0.05", t)])
        axb.plot(zr[:, 0], zr[:, 1], ls, color=col, lw=0.9, label=("no offset" if name == "CTRL_j0" else "twist reversed") + f", $t$ = {t:.2f}")
axb.set_xlim(-1.2, 1.2); axb.set_ylim(0.6, 1.02); axb.set_xlabel("height $z$"); axb.set_ylabel(r"$\max_r\Psi(r,z)\,/\,\Psi_{\max}$")
axb.legend(fontsize=5.8, loc="lower center", handlelength=1.6, borderaxespad=0.3)
letter(axb, "b", "ridge profiles of the controls", x=-0.30, y=1.03)
# c: diagnostics against time
for fn, col, lab in (("asym_j0.json", BLUE, "$\\epsilon_B = 50$, no offset"), ("asym_twist.json", RED, "$\\epsilon_B = 50$, twist reversed"), ("asym_e1.json", GREY, "$\\epsilon_B = 1$, reference")):
    A = json.load(open(CTRL + fn)); t = np.array([q["t"] for q in A]); m = (t > 0.02) & (t <= 0.45)
    axc.plot(t[m], np.array([q["Eodd_over_Eeven"] for q in A])[m], "-", color=col, lw=0.9, label=lab)
    axc.plot(t[m], np.abs(np.array([q["vz_anti_axis"] for q in A])[m]), "--", color=col, lw=0.9)
axc.set_yscale("log"); axc.set_xlim(0, 0.45); axc.set_ylim(1e-5, 1); axc.set_xlabel("$t$")
axc.set_ylabel("odd / even energy of $B_\\phi$ (solid)\n$|v_z|$ of the antisymmetric response at the axis (dashed)", fontsize=6.2)
axc.legend(fontsize=5.8, loc="upper left", handlelength=1.6, borderaxespad=0.3)
letter(axc, "c", "development of the asymmetry", x=-0.30, y=1.03)
out = OUT + "/si_fig4_asymmetry.pdf"; fig.savefig(out); fig.savefig(out.replace(".pdf", ".png"), dpi=200); print("written", out)
