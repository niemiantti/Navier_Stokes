#!/usr/bin/env python3
"""
leiren_bigbox_vs3b: compact prescribed-flow, axisymmetric resistive MHD.

Run python3 leiren_bigbox_vs3b.py for the parameter questions.
Use --preflight to inspect actual flow size and resolution before integration.
The new ellipsoidal window confines BOTH meridional flow and swirl relative
to a fixed radius-one tapered spheromak. This remains a reference-inspired
model, not the completed Lei-Ren background, and is not full 3-D MHD.
"""
import argparse, glob, json, os, shutil, subprocess, sys, time, signal, hashlib
from pathlib import Path
from dataclasses import replace
from contextlib import nullcontext
try:
    from threadpoolctl import threadpool_limits
except ModuleNotFoundError:                      # optional: limits the BLAS/FFT threads; without it the libraries choose
    import contextlib
    def threadpool_limits(limits=None):
        return contextlib.nullcontext()
import configuration as cfg
import run_safety as safe
import numpy as np
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import openai_mhd_3d as mhd
import checks

RES_ROOT = os.path.join(HERE, "results")
LIGHT_DT = 0.05
D_SPLIT = 0.003
RING_TH = 0.05

# =============================================================================
# parameters: questions, defaults, checks
# =============================================================================
DEFAULTS = cfg.DEFAULTS


def ask(prompt, default, kind=float, check=None, choices=None):
    while True:
        try:
            s = input(f"  {prompt} [{default}]: ").strip()
        except EOFError:
            s = ""
        if s == "":
            v = default
        else:
            try:
                v = kind(s)
            except ValueError:
                print("    not a valid value, try again"); continue
        if choices and v not in choices:
            print(f"    choose one of: {', '.join(str(c) for c in choices)}"); continue
        if check:
            msg = check(v)
            if msg:
                print("    " + msg); continue
        return v


def interactive():
    d=dict(DEFAULTS)
    pos=lambda x:None if x>0 else "must be positive"
    nonneg=lambda x:None if x>=0 else "must be nonnegative"
    print("\nVS3B: axisymmetric MHD; radius-one seed; compact reference-inspired background.\n")
    d['profile']=ask('background: leiren or surrogate',d['profile'],str,choices=('leiren','surrogate'))
    for key,text in (('eps_b','magnetic coefficient eps_B'),('eta','magnetic diffusivity eta'),('nu','viscosity nu')):
        d[key]=ask(text,d[key],float,nonneg)
    for key,text in (('r_box','box radius'),('z_box','box half-height')):
        d[key]=ask(text,d[key],float,lambda x:None if x>1.05 else 'must exceed 1.05 for the radius-one seed')
    d['nr']=ask('radial cells (new compact pilot default; NOT a convergence guarantee)',d['nr'],int,
                lambda x:None if 16<=x<=4096 else 'use 16..4096')
    for key,text in (('t_start','start time; the seed is placed at this time'),('t_end','end time'),('t_off','release time')):
        d[key]=ask(text,d[key],float)
    d['mode']=ask('release: sudden, ramp, kept',d['mode'],str,choices=('sudden','ramp','kept'))
    if d['mode']=='ramp':
        d['t_ramp']=ask('smooth ramp duration',d['t_ramp'],float,pos)
    d['tau_f']=ask('regularization tau_f',d['tau_f'],float,pos)
    if d['profile']=='leiren':
        for key,text in (('lr_L0','INTERNAL fixed-strain length L0 (not outer radius)'),('lr_Rc','internal meridional cutoff Rc'),
                         ('lr_XR','swirl transition coordinate XR (not exact peak)'),('lr_Xc','swirl core coordinate Xc')):
            d[key]=ask(text,d[key],float,pos)
        d['lr_j']=ask('axial offset j',d['lr_j'],float)
        d['lr_delta']=ask('similarity exponent delta (not a theorem-certified parameter choice)',d['lr_delta'],float)
        d['lr_S']=ask('model swirl amplitude',d['lr_S'],float,nonneg)
        d['lr_cutoff']=ask('internal meridional cutoff: cone or column',d['lr_cutoff'],str,choices=('cone','column'))
    else:
        for key in ('surrogate_lr0','surrogate_lz0','surrogate_cp','surrogate_cs'):
            d[key]=ask(key,d[key],float,pos)
    d['flow_window']=ask('OUTER confinement of BOTH SU and Omega: ellipsoid or none',d['flow_window'],str,
                         choices=('ellipsoid','none'))
    if d['flow_window']=='ellipsoid':
        d['flow_r0']=ask('initial outer radial semi-axis / seed radius',d['flow_r0'],float,pos)
        d['flow_z0']=ask('initial outer axial semi-axis / seed radius',d['flow_z0'],float,pos)
        d['flow_inner']=ask('flat inner fraction of ellipsoid',d['flow_inner'],float,
                            lambda x:None if 0<x<1 else 'must lie in (0,1)')
        d['flow_window_evolution']=ask('outer axes: similarity (contract with core) or fixed',d['flow_window_evolution'],str,
                                      choices=('similarity','fixed'))
    print('  Small-flow guard tests actual initial energy, not just a nominal radius.')
    d['require_small_flow']=ask('require the small-flow energy test? y/n','y',str,choices=('y','n'))=='y'
    if d['require_small_flow']:
        d['small_flow_radius']=ask('energy-test spherical radius / seed radius',d['small_flow_radius'],float,pos)
        d['small_flow_fraction']=ask('required fraction of flow kinetic energy inside it',d['small_flow_fraction'],float,
                                     lambda x:None if 0<x<=1 else 'must lie in (0,1]')
    d['swirl_sign']=ask('swirl sign (+1 or -1)',d['swirl_sign'],int,choices=(1,-1))
    d['seed']=ask('seed: spheromak or pair (opposite toroidal twist, not certified Hopf charges)',d['seed'],str,
                  choices=('spheromak','pair'))
    if d['seed']=='pair': d['seed_w']=ask('pair twist-reversal width',d['seed_w'],float,pos)
    d['orientation']=ask('fixed seed twist sign 1/-1; auto is NOT recommended for matched-background comparisons',
                         d['orientation'],str,choices=('1','-1','auto'))
    d['threads']=ask('BLAS thread limit',d['threads'],int,lambda x:None if x>=1 else 'positive integer')
    d['runs_dir']=ask('directory for new vs3b raw run files',d['runs_dir'],str)
    d['label']=ask('optional short label',d['label'],str)
    return d


box_fields = cfg.box_fields



make_params = cfg.make_params



orientation_check = cfg.orientation_check



finish_params = cfg.finish_params



def orientation_text(d):
    ori=d.get('orientation_report',{})
    return (f"Seed twist sign fixed to {int(d['seed_sign']):+d}; choice={d['orientation']}. "
            f"Local d_z Omega signs above/below: {ori.get('induced_sign_above')}/{ori.get('induced_sign_below')}. "
            "This is a local diagnostic, not a global alignment or Hopf-charge assertion.")


# =============================================================================
# Atomic files; raw snapshots are not overwritten and checkpoint generations are retained
# =============================================================================



save_new = safe.atomic_npz



write_any = safe.atomic_text



load_ok = safe.load_npz



checkpoints = safe.checkpoint_paths


def keep_awake():
    if sys.platform == "darwin" and shutil.which("caffeinate"):
        try:
            subprocess.Popen(["caffeinate", "-i", "-w", str(os.getpid())]); return True
        except OSError:
            pass
    return False


# =============================================================================
# diagnostics during the run
# =============================================================================
def ridge(g, Psi):
    im = np.clip(np.argmax(Psi[1:, :], axis=0) + 1, 1, g.nr - 2)
    j = np.arange(g.nz)
    f0, fm, fp = Psi[im, j], Psi[im - 1, j], Psi[im + 1, j]
    den = fm - 2.0 * f0 + fp
    dx = np.where(den < 0, 0.5 * (fm - fp) / np.where(den < 0, den, -1.0), 0.0)
    return f0 - 0.25 * (fm - fp) * dx, g.r[im] + dx * g.dr


def track(g, state, t, rel=0.25, tol=2e-5):
    """O- and X-points of the ridge of Psi (radial maximum at each height) and the deepest island"""
    Psi = g.rc**2 * state[2]
    R, rr = ridge(g, Psi)
    Rm = R.max(); k0 = int(np.argmax(R))
    if not np.isfinite(Rm) or Rm <= 0:
        return dict(t=float(t),tau=float(1-t),Psi_max=float(Rm),z_O=None,dmax=0.,z_dmax=None,sep=None,nO=0,nX=0,cps=[])
    Rn = R / Rm
    ok = Rn > rel
    cps = []
    for k in range(1, g.nz - 1):
        if not (ok[k - 1] and ok[k] and ok[k + 1]):
            continue
        a, b, c = Rn[k - 1], Rn[k], Rn[k + 1]
        kind = "O" if (b > a and b >= c) else ("X" if (b < a and b <= c) else None)
        if kind:
            d2 = a - 2 * b + c; dzk = 0.5 * (a - c) / d2 if d2 != 0 else 0.0
            cps.append(dict(kind=kind, z=float(g.z[k] + dzk * g.dz), r=float(rr[k]), psi=float(b - 0.25 * (a - c) * dzk), k=k))
    changed = True
    while changed:
        changed = False
        for n in range(len(cps) - 1):
            if cps[n]["kind"] != cps[n + 1]["kind"] and abs(cps[n]["psi"] - cps[n + 1]["psi"]) < tol:
                del cps[n:n + 2]; changed = True; break
    ks = [c["k"] for c in cps if c["kind"] == "O"]
    cps = [c for c in cps if c["kind"] == "O" or (ks and min(ks) < c["k"] < max(ks))]
    srt = sorted(cps, key=lambda c: c["z"])
    dmax, zd, sep = 0.0, None, None
    for i, c in enumerate(srt):
        if c["kind"] == "X" and 0 < i < len(srt) - 1:
            lo, hi = srt[i - 1], srt[i + 1]
            dd = min(lo["psi"], hi["psi"]) - c["psi"]
            if dd > dmax:
                sh = lo if lo["psi"] < hi["psi"] else hi
                dmax, zd, sep = dd, c["z"], abs(sh["z"] - c["z"])
    return dict(t=float(t), tau=float(1 - t), Psi_max=float(Rm), z_O=float(g.z[k0]), dmax=float(dmax), z_dmax=zd, sep=sep,
                nO=sum(c["kind"] == "O" for c in cps), nX=sum(c["kind"] == "X" for c in cps),
                cps=[{k: v for k, v in c.items() if k != "k"} for c in cps])


def save_light(directory,g,state,t):
    fd=mhd.derived(g,state,1-t)
    s=lambda a:np.asarray(a,dtype=np.float32)
    f=os.path.join(directory,f'light_t{t:.9f}.npz')
    save_new(f,compressed=True,r=g.r,z=g.z,t=t,
             Psi=s(fd['Psi']),Bphi=s(fd['Bphi']),Jphi=s(fd['Jphi']),
             chi=s(g.rc**2*(fd['SU']+fd['S'])),Omega=s(fd['OU']+fd['a']),
             config_sha256=np.array(g.config_sha256),code_sha256=np.array(g.code_sha256))


def save_full(directory,g,state,t,tag=''):
    fd=mhd.derived(g,state,1-t)
    names=('Psi','Bphi','Br','Bz','Jphi','Jr','Jz','Ur','Uz','Uphi','vr','vz','vphi')
    arrays={k:np.asarray(fd[k],dtype=np.float32) for k in names}
    arrays.update(v=np.sqrt(fd['vr']**2+fd['vz']**2+fd['vphi']**2).astype(np.float32),
                  Vr=(fd['Ur']+fd['vr']).astype(np.float32),Vz=(fd['Uz']+fd['vz']).astype(np.float32),
                  Vphi=(fd['Uphi']+fd['vphi']).astype(np.float32),
                  chi=(g.rc**2*(fd['SU']+fd['S'])).astype(np.float32),Omega=(fd['OU']+fd['a']).astype(np.float32))
    save_new(os.path.join(directory,f'full_t{t:.9f}{tag}.npz'),compressed=True,r=g.r,z=g.z,t=t,
             config_sha256=np.array(g.config_sha256),code_sha256=np.array(g.code_sha256),**arrays)


def extra_diag(g,p,state,tau):
    b=checks.background_power(g,p,tau,state)
    out={k:float(b[k]) for k in ('Ktot','Pext','KU','Kpol_U','Kswirl_U','dKU_dt','dissipation','pure_power_balance_residual')}
    fd=mhd.derived(g,state,tau)
    b2=fd['Br']**2+fd['Bz']**2+fd['Bphi']**2
    j2=fd['Jr']**2+fd['Jz']**2+fd['Jphi']**2
    jb=float(np.sum(j2*g.dV)); eb=float(np.sum(b2*g.dV))
    ell=float(np.sqrt(eb/jb)) if jb>0 else 0.
    out.update(J2_integral=jb,ohmic_dissipation=p.eps_b*p.eta*jb,
               ell_B_rms=ell,ell_B_rms_cells=ell/max(g.dr,g.dz),
               Vmax_total=float(np.sqrt((fd['Ur']+fd['vr'])**2+(fd['Uz']+fd['vz'])**2+(fd['Uphi']+fd['vphi'])**2).max()))
    return out


def release_snapshot(g,p,state,t):
    fd=mhd.derived(g,state,1-t)
    V=(fd['Ur']+fd['vr'],fd['Uz']+fd['vz'],fd['Uphi']+fd['vphi'])
    k,_=mhd.rhs(g,state,t)
    kz,ka=k[0],k[1]
    # Compare total physical tendencies, not just the response variable.
    if t<p.t_off-1e-12 and p.U_scale!=0:
        dt=1e-5
        with checks.grid_params(g,replace(p,t_off=1e99)):
            later=g.background_terms(1-t-dt); earlier=g.background_terms(1-t+dt)
        dS=(later['SU']-earlier['SU'])/(2*dt)
        kz=kz-g.L5(g.pad(dS)); ka=ka+(later['OU']-earlier['OU'])/(2*dt)
    accS=g.solve_poisson(kz); ag=g.pad(accS)
    acceleration=(-g.rc*g.ddz(ag),2*accS+g.rc*g.ddr(ag),g.rc*ka)
    return dict(V=V,acceleration=acceleration,dzeta=kz,da=ka,P=state[2].copy(),q=state[3].copy(),
                Ktot=.5*float(np.sum(sum(x*x for x in V)*g.dV)),
                Pext=float(checks.background_power(g,p,1-t,state)['Pext']))


def release_check(g,p,state,t,before):
    after=release_snapshot(g,p,state,t)
    u2=sum(v*v for v in before['V']); delta2=sum((a-b)**2 for a,b in zip(after['V'],before['V']))
    accdelta=np.sqrt(sum((a-b)**2 for a,b in zip(after['acceleration'],before['acceleration'])))
    norm=float(np.sqrt(sum(v*v for v in before['acceleration'])).max())
    return dict(t=float(t),velocity_jump_rel=float(np.sqrt(delta2.max()/max(u2.max(),1e-300))),
                velocity_jump_l2=float(np.sqrt(np.sum(delta2*g.dV)/max(np.sum(u2*g.dV),1e-300))),
                magnetic_P_changed=float(np.max(np.abs(after['P']-before['P']))),
                magnetic_q_changed=float(np.max(np.abs(after['q']-before['q']))),
                Ktot_before=before['Ktot'],Ktot_after=after['Ktot'],
                kinetic_jump_rel=(after['Ktot']-before['Ktot'])/max(abs(before['Ktot']),1e-300),
                acceleration_jump_max=float(accdelta.max()),
                acceleration_jump_rel=float(accdelta.max()/max(norm,1e-300)),
                vorticity_tendency_jump_rel=float(np.max(np.abs(after['dzeta']-before['dzeta']))/max(np.max(np.abs(before['dzeta'])),1e-300)),
                force_power_before=before['Pext'])


def release_text(ri):
    if ri.get('kind')=='ramp':
        return 'smooth ramp completed; no endpoint state reset (continuous transfer source integrated in RK stages)'
    return (f"velocity jump rel={ri['velocity_jump_rel']:.3e}; magnetic changes={max(ri['magnetic_P_changed'],ri['magnetic_q_changed']):.3e}; "
            f"Ktot {ri['Ktot_before']:.7g} -> {ri['Ktot_after']:.7g}; physical acceleration jump={ri['acceleration_jump_max']:.4g}; "
            f"force power before={ri['force_power_before']:.5g}")


# =============================================================================
# the run
# =============================================================================
def full_times(d):
    times=d['full_snap_times'] if d['full_snap_times'] is not None else np.linspace(d['t_start'],d['t_end'],6).tolist()
    times=list(times)+[d['t_start'],d['t_end']]
    for t in (d['t_off'],d['t_off']+d['t_ramp']):
        if d['t_start']<=t<=d['t_end']: times.append(t)
    return sorted(set(round(float(t),12) for t in times))


def run(d,log=print,*,allow_underresolved=False,allow_noncompact=False,max_steps=None,max_wall=None,resume_only=False):
    """Safe start/resume. No success marker after failure or a controlled stop."""
    d=finish_params(d)
    sources=safe.source_manifest(HERE)
    rdir=Path(os.path.expanduser(d['runs_dir']))/d['name']
    with safe.run_lock(rdir):
        if resume_only and not (rdir/'config.json').exists():
            raise RuntimeError('No vs3b run to resume. Omit --resume for the first start.')
        safe.initialize_directory(rdir,d,sources)
        done_path=rdir/'finished.json'
        if done_path.exists():
            fin=safe.read_json(done_path)
            if (fin.get('config_sha256')!=d['config_sha256'] or fin.get('code_sha256')!=sources['sha256']
                    or fin.get('t_reached',-1)<d['t_end']-1e-12):
                raise RuntimeError('Invalid or foreign success marker: data retained, start refused')
            log('Already finished with matching configuration and sources; no integration repeated.')
            return str(rdir)
        audit=write_preflight(d,log)
        unmet=[]
        for issue in audit['blocking_issues']:
            if issue.startswith('At t=') and allow_underresolved: continue
            if issue.startswith('Only ') and allow_noncompact: continue
            unmet.append(issue)
        if unmet:
            safe.atomic_json(rdir/'status.json',dict(status='preflight_blocked',issues=unmet,config_sha256=d['config_sha256']))
            raise RuntimeError('Preflight blocked this run. '+ '; '.join(unmet)+
                               '. Change parameters, or explicitly use --allow-underresolved / --allow-noncompact for exploratory tests.')
        safe.atomic_json(rdir/'preflight.json',audit)
        c,ckpath=safe.load_checkpoint(rdir,d,sources)
        if c is None and (safe.checkpoint_paths(rdir) or list(rdir.glob('*_t*.npz'))):
            raise RuntimeError('Existing simulation output has no compatible readable checkpoint. Nothing is restarted or overwritten.')
        parent_ctx=None
        if c is None and d.get('parent_run'):
            parent_ctx=load_parent_state(d,rdir,log)
        p=make_params(d); g=mhd.Grid(p)
        g.config_sha256=d['config_sha256']; g.code_sha256=sources['sha256']
        if c is not None:
            ctx=safe.context_from_checkpoint(c)
            archive=safe.archive_future_snapshots(rdir,ctx['t'],ctx['handed'],d['t_off'])
            if archive: log('Archived uncommitted later snapshots: '+archive)
            log(f"Resuming finite accepted state t={ctx['t']:.9f}, step={ctx['step']} from {ckpath}")
        elif parent_ctx is not None:
            ctx=parent_ctx
            log(f"Continuing run {d['parent_run']} from its final state t={ctx['t']:.9f}, step={ctx['step']} (new experiment {d['name']})")
        else:
            P0,q0=mhd.spheromak_seed(p,g)
            state=[np.zeros_like(P0),np.zeros_like(P0),P0,q0]
            ctx=dict(state=state,t=d['t_start'],step=0,handed=False,done=[],release_info={},tracks=[],diag=[])
            h=hashlib.sha256(P0.tobytes()+q0.tobytes()).hexdigest()
            safe.atomic_json(rdir/'initial_seed.json',dict(sha256_P_q=h,seed_sign=d['seed_sign'],seed=d['seed'],grid=[p.nr,p.nz]))
        set_background_phase(p,ctx['t'],d,ctx['handed'])
        t_end=d['t_end']; t_release=d['t_off']+(d['t_ramp'] if d['mode']=='ramp' else 0)
        ld=d['light_dt']
        lights={round(i*ld,12) for i in range(int(np.ceil(d['t_start']/ld)),int(np.floor(t_end/ld))+1)}
        lights|={d['t_start'],t_end}
        fulls=set(full_times(d))
        events=sorted(lights|fulls|{t_end}|{v for v in (d['t_off'],t_release) if d['t_start']<=v<=t_end})
        ctx['done']=list(ctx.get('done',[]))
        if parent_ctx is not None:
            ctx['done']=sorted({e for e in events if e<ctx['t']-1e-12}|set(ctx['done']))
        wall=time.monotonic(); last_ck=wall; start_step=ctx['step']; status='running'; error=None
        log(f"{d['name']}: AXISYMMETRIC {p.nr}x{p.nz}; seed radius=1; eps_B={p.eps_b}, eta={p.eta}, nu={p.nu}")
        log(f"Internal L0={p.lr_L0}; outer {p.flow_window}: a0={p.flow_r0}, b0={p.flow_z0}, {p.flow_window_evolution}; "+orientation_text(d))
        log(f"Run files: {rdir}; dt_max={d['dt_max']}; release={d['mode']} at {d['t_off']}")
        if allow_underresolved or allow_noncompact:
            log('EXPLICIT exploratory override active; no resolution/confinement certification.')

        def diagnostics_now(phase=0):
            set_background_phase(p,ctx['t'],d,ctx['handed'])
            dg=mhd.diagnostics(g,ctx['state'],1-ctx['t'])
            dg.update(extra_diag(g,p,ctx['state'],1-ctx['t']))
            row={k:float(v) for k,v in dg.items()}
            row['phase']=phase
            if not all(np.isfinite(v) for v in row.values()):
                raise FloatingPointError('Nonfinite physical diagnostic')
            if ctx['diag'] and abs(ctx['diag'][-1]['t']-ctx['t'])<1e-13 and ctx['diag'][-1].get('phase',0)==phase:
                ctx['diag'][-1]=row
            else: ctx['diag'].append(row)
            return row

        def process_events():
            nonlocal ctx
            t=ctx['t']
            for event in events:
                if event in ctx['done'] or event>t+1e-12: continue
                if abs(event-t)>1e-9:
                    raise RuntimeError('A scheduled event was skipped; refusing an off-time handover')
                set_background_phase(p,t,d,ctx['handed'])
                if d['mode']=='sudden' and abs(event-d['t_off'])<1e-12 and not ctx['handed']:
                    diagnostics_now(-1)
                    save_full(str(rdir),g,ctx['state'],t,tag='_before_release')
                    before=release_snapshot(g,p,ctx['state'],t)
                    bt=g.background_terms(1-t)
                    old=ctx['state']
                    # No in-place mutation: interrupted transactions keep the accepted old state.
                    new=[old[0]-g.L5(g.pad(bt['SU'])),old[1]+bt['OU'],old[2],old[3]]
                    set_background_phase(p,t,d,True)
                    info=release_check(g,p,new,t,before)
                    if info['velocity_jump_rel']>1e-9 or info['magnetic_P_changed']!=0 or info['magnetic_q_changed']!=0:
                        raise RuntimeError('Handover continuity guard failed; pre-release state retained')
                    ctx=dict(ctx,state=new,handed=True,release_info=info)
                    save_full(str(rdir),g,new,t,tag='_after_release')
                    log('SUDDEN RELEASE: '+release_text(info))
                if d['mode']=='ramp' and abs(event-t_release)<1e-12 and not ctx['handed']:
                    ctx=dict(ctx,handed=True,release_info=dict(kind='ramp',t=t,endpoint_reset=False,
                        note="-A_prime*U0 integrated in all RK stages; effective force is not exactly A*f(U0)."))
                    set_background_phase(p,t,d,True)
                    log('RAMP completed without endpoint state reset.')
                if event in fulls: save_full(str(rdir),g,ctx['state'],t)
                if event in lights: save_light(str(rdir),g,ctx['state'],t)
                ctx['done'].append(event)
                diagnostics_now(1 if ctx['handed'] else 0)

        def store_checkpoint():
            path=safe.save_checkpoint(rdir,d,sources,ctx)
            safe.atomic_json(rdir/'tracks.json',ctx['tracks']); safe.atomic_json(rdir/'diag.json',ctx['diag'])
            if ctx['diag']:
                keys=list(ctx['diag'][0])
                safe.atomic_text(rdir/'diag.csv',','.join(keys)+'\n'+
                    '\n'.join(','.join(f"{row.get(k,0.):.16g}" for k in keys) for row in ctx['diag'])+'\n')
            safe.atomic_json(rdir/'status.json',dict(status=status,t_reached=ctx['t'],steps=ctx['step'],checkpoint=Path(path).name,
                config_sha256=d['config_sha256'],code_sha256=sources['sha256'],pid=os.getpid(),
                allow_underresolved=allow_underresolved,allow_noncompact=allow_noncompact,error=error))
            return path

        old_sigterm=None
        if __import__('threading').current_thread() is __import__('threading').main_thread():
            old_sigterm=signal.getsignal(signal.SIGTERM)
            signal.signal(signal.SIGTERM,lambda signum,frame: (_ for _ in ()).throw(KeyboardInterrupt()))
        try:
            diagnostics_now(1 if ctx['handed'] else 0)
            process_events()
            store_checkpoint()   # a recoverable initial / resumed accepted state
            D=max(p.nu,p.eta)
            dt_diff=p.diff_frac*2.51/(D*g.lam_max) if D>0 else float('inf')
            while ctx['t']<t_end-1e-12:
                if ((max_steps is not None and ctx['step']-start_step>=max_steps) or
                    (max_wall is not None and time.monotonic()-wall>=max_wall)):
                    raise safe.RunStopped('Requested step/wall-time limit reached')
                t=ctx['t']; state=ctx['state']
                set_background_phase(p,t,d,ctx['handed'])
                with np.errstate(over='raise',invalid='raise',divide='raise'):
                    k1,aux=rhs_at(g,state,t,d)
                    adv=float(np.max(np.abs(aux['Vr'])/g.dr+np.abs(aux['Vz'])/g.dz+
                                     np.sqrt(p.eps_b)*aux['Babs']*(1/g.dr+1/g.dz)))
                    nxt=min((e for e in events if e>t+1e-12),default=t_end)
                    rate=adv/p.cfl+(1/dt_diff if np.isfinite(dt_diff) else 0.)
                    dt=min(1/rate if rate>0 else d['dt_max'],d['dt_max'],nxt-t)
                    if not np.isfinite(dt) or dt<=0 or t+dt==t:
                        raise FloatingPointError('Invalid or vanishing time step')
                    u1=[s+dt*k for s,k in zip(state,k1)]
                    k2,_=rhs_at(g,u1,t+dt,d)
                    u2=[.75*s+.25*(s1+dt*k) for s,s1,k in zip(state,u1,k2)]
                    k3,_=rhs_at(g,u2,t+.5*dt,d)
                    new=[s/3.+2./3.*(s2+dt*k) for s,s2,k in zip(state,u2,k3)]
                if any(not np.all(np.isfinite(a)) for a in new):
                    raise FloatingPointError('Nonfinite candidate state; last accepted finite state retained')
                newt=t+dt
                if abs(newt-nxt)<1e-11: newt=nxt
                ctx=dict(ctx,state=new,t=newt,step=ctx['step']+1)
                set_background_phase(p,newt,d,ctx['handed'])
                if ctx['step']%d['track_steps']==0:
                    ctx['tracks'].append(track(g,new,newt))
                process_events()
                if ctx['step']%d['diagnostic_steps']==0:
                    diagnostics_now(1 if ctx['handed'] else 0)
                if ctx['step']%d['log_steps']==0:
                    dg=ctx['diag'][-1]
                    log(f"t={ctx['t']:.6f} step={ctx['step']} dt={dt:.3e} Ktot={dg['Ktot']:.6g} M={dg['M']:.6g} "
                        f"Bmax={dg['Bmax']:.5g} [elapsed {time.monotonic()-wall:.0f}s; diagnostics t={dg['t']:.6f}]")
                if time.monotonic()-last_ck>=d['checkpoint_seconds']:
                    store_checkpoint(); last_ck=time.monotonic()
            diagnostics_now(1 if ctx['handed'] else 0)
            save_full(str(rdir),g,ctx['state'],ctx['t'])
            if ctx['t']<t_end-1e-12: raise RuntimeError('End-time invariant failed')
            status='finished'
            final_ck=store_checkpoint()
            safe.atomic_json(done_path,dict(t_reached=ctx['t'],steps=ctx['step'],hours_this_session=(time.monotonic()-wall)/3600,
                             config_sha256=d['config_sha256'],code_sha256=sources['sha256'],
                             final_checkpoint=Path(final_ck).name,release=ctx['release_info']))
            log(f"DONE at t={ctx['t']:.9f}; finite state and checkpoint retained. {rdir}")
            return str(rdir)
        except (KeyboardInterrupt,safe.RunStopped) as e:
            status='interrupted'; error=str(e) or 'Interrupt/termination requested'
            set_background_phase(p,ctx['t'],d,ctx['handed'])
            store_checkpoint()
            log(f"STOPPED SAFELY at t={ctx['t']:.9f}: {error}. No finished.json written.")
            return None
        except Exception as e:
            status='failed'; error=f'{type(e).__name__}: {e}'
            set_background_phase(p,ctx['t'],d,ctx['handed'])
            try:
                store_checkpoint()
                safe.atomic_json(rdir/'failure.json',dict(error=error,t_last_finite=ctx['t'],step=ctx['step']))
            except Exception as storage_error:
                log(f'Could not write failure checkpoint: {storage_error}; older checkpoints were NOT deleted.')
            log(f"FAILED: {error}. No success marker; checkpoints retained.")
            raise
        finally:
            if old_sigterm is not None: signal.signal(signal.SIGTERM,old_sigterm)


def load_parent_state(d,rdir,log):
    """Initial state of a continuation: the final checkpoint of the finished run d['parent_run'] (same lattice and
    physical parameters, longer t_end). The parent's success marker, configuration and lattice are verified; its code
    hash may differ from the current one (an extension across code versions), which is recorded in the provenance."""
    proot=Path(os.path.expanduser(d['runs_dir']))/d['parent_run']
    fin_path=proot/'finished.json'
    if not fin_path.exists():
        raise RuntimeError(f"Parent run {d['parent_run']} has no success marker (finished.json); only finished runs can be continued.")
    fin=safe.read_json(fin_path)
    pconf=safe.read_json(proot/'config.json') if (proot/'config.json').exists() else {}
    ck=proot/fin.get('final_checkpoint','')
    if not ck.exists():
        cands=safe.checkpoint_paths(proot)
        if not cands: raise RuntimeError('Parent run has no checkpoint file.')
        ck=Path(cands[0])
    c=safe.load_npz(ck)
    if str(c.get('config_sha256',''))!=fin.get('config_sha256',pconf.get('config_sha256','')):
        raise RuntimeError('Parent checkpoint does not belong to the parent configuration.')
    if abs(float(c['t'])-float(d['parent_t']))>1e-9:
        raise RuntimeError(f"Parent state is at t={float(c['t']):.9f}, but parent_t={d['parent_t']}; use --extend to set it.")
    for key in ('nr','nz','r_box','z_box','eps_b','eta','nu','tau_f','profile','lr_L0','lr_cutoff','lr_Rc','lr_S','seed','seed_sign',
                'flow_window','flow_r0','flow_z0','flow_inner','flow_window_evolution','t_start','t_off','mode','t_ramp'):
        if key in pconf and pconf[key]!=d[key]:
            raise RuntimeError(f'A continuation must keep the physical parameters and the lattice: {key} differs from the parent.')
    ctx=safe.context_from_checkpoint(c)
    if ctx['state'][0].shape!=(d['nr'],d['nz']):
        raise RuntimeError('Parent lattice differs from this configuration.')
    safe.atomic_json(rdir/'continuation_provenance.json',dict(parent_run=d['parent_run'],parent_checkpoint=ck.name,
        parent_t=float(c['t']),parent_config_sha256=str(c.get('config_sha256','')),parent_code_sha256=str(c.get('code_sha256','')),
        this_code_sha256=safe.source_manifest(HERE)['sha256']))
    log(f"Parent state loaded from {ck} (parent code sha256 {str(c.get('code_sha256',''))[:12]})")
    return ctx


# =============================================================================
# analysis
# =============================================================================
def persistence_rings(P, r, z, r_lim):
    """Every flux maximum (5x5 local maximum above 1 % of the peak) with its depth: peak minus the highest pass
    (saddle) that connects it to a higher maximum, from a union-find sweep over the levels of Psi (4-connectivity)."""
    nr_, nz_ = P.shape; flat = P.ravel(); N = flat.size
    order = np.argsort(-flat, kind="stable")
    parent = np.full(N, -1, dtype=np.int64); top = np.zeros(N, dtype=np.int64)
    death = {}

    def find(i):
        root = i
        while parent[root] != root:
            root = parent[root]
        while parent[i] != root:
            parent[i], i = root, parent[i]
        return root
    for idx in order:
        parent[idx] = idx; top[idx] = idx
        i, j = divmod(int(idx), nz_)
        roots = set()
        for ii, jj in ((i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)):
            if 0 <= ii < nr_ and 0 <= jj < nz_:
                n = ii * nz_ + jj
                if parent[n] != -1:
                    roots.add(find(n))
        if roots:
            best = max(roots, key=lambda q: flat[top[q]])
            for q in roots:
                if q != best:
                    death[int(top[q])] = float(flat[idx]); parent[q] = best
            parent[idx] = best
    pmax = flat.max()
    mx = (P == ndimage.maximum_filter(P, size=5)) & (P > 0.01 * pmax)
    rings = []
    for i, j in zip(*np.nonzero(mx)):
        k = i * nz_ + j
        if k in death and r[i] <= r_lim:
            rings.append(dict(depth=float((flat[k] - death[k]) / pmax), r=float(r[i]), z=float(z[j])))
    return sorted(rings, key=lambda x: -x["depth"])


def fission_metrics(tracks):
    out = dict(t_s=None, tau_s=None, z_birth=None, type=None, island_ratio=None, depth_exp=None, sep_exp=None, tau_fit=None)
    if not tracks:
        return out
    dm = np.array([q["dmax"] for q in tracks]); tau = np.array([q["tau"] for q in tracks])
    deep = np.where(dm >= D_SPLIT)[0]
    if not len(deep):
        return out
    i1 = int(deep[0]); zd = tracks[i1]["z_dmax"]; i0 = i1
    while i0 > 0 and tracks[i0 - 1].get("z_dmax") is not None and abs(tracks[i0 - 1]["z_dmax"] - zd) < 0.2 and dm[i0 - 1] > 0:
        i0 -= 1; zd = tracks[i0]["z_dmax"]
    if i0 == 0:
        out.update(t_s=float(1 - tau[0]), tau_s=float(tau[0]), z_birth=zd, type="already split when tracking began"); return out
    tb = float(0.5 * (tau[i0] + tau[i0 - 1])); out.update(tau_s=tb, t_s=1.0 - tb, z_birth=zd)
    ratio = None
    for q in tracks[i0:]:
        if q["dmax"] >= 1e-3:
            cps = sorted(q["cps"], key=lambda c: c["z"]); best = None
            for i, c in enumerate(cps):
                if c["kind"] == "X" and 0 < i < len(cps) - 1:
                    dl, dh = cps[i - 1]["psi"] - c["psi"], cps[i + 1]["psi"] - c["psi"]
                    if best is None or min(dl, dh) > best[0]:
                        best = (min(dl, dh), min(dl, dh) / max(dl, dh) if max(dl, dh) > 0 else 0.0)
            ratio = best[1] if best else None
            break
    out["island_ratio"] = ratio
    out["type"] = ("central split (pitchfork-like)" if ratio is not None and ratio > 0.5 else
                   "one-sided split (fold)" if ratio is not None and ratio < 0.2 else "intermediate")
    k = i0
    while k + 1 < len(tracks) and 0 < dm[k + 1] <= 0.03:
        k += 1
    win = [i for i in range(i0, k + 1) if dm[i] > 0 and tracks[i].get("sep")]
    if len(win) >= 8:
        x0, Dd, S = tau[win], dm[win], np.array([tracks[i]["sep"] for i in win])
        best = None
        for tbc in np.linspace(tau[i0] + 1e-6, tau[i0] + 0.01, 400):
            x = tbc - x0
            A = np.vstack([np.ones_like(x), np.log(x)]).T
            cf, *_ = np.linalg.lstsq(A, np.log(Dd), rcond=None)
            rss = float(np.sum((np.log(Dd) - A @ cf)**2))
            if best is None or rss < best[0]:
                best = (rss, tbc, cf[1])
        _, tbc, pw = best
        out.update(depth_exp=float(pw), sep_exp=float(np.polyfit(np.log(tbc - x0), np.log(S), 1)[0]), tau_fit=float(tbc))
    return out


def analyse(d, rdir, log):
    tracks = json.load(open(os.path.join(rdir, "tracks.json")))
    diag = json.load(open(os.path.join(rdir, "diag.json")))
    t_off = (d["t_off"] + d["t_ramp"] if d["mode"] == "ramp" else (float("inf") if d["mode"] == "kept" else d["t_off"]))
    fis = fission_metrics([q for q in tracks if q["t"] <= t_off + 1e-9])
    lights = sorted(glob.glob(os.path.join(rdir, "light_t*.npz")), key=lambda f: float(f.split("light_t")[1][:-4]))
    rings, bphi = [], []
    sgn_seed = d.get("seed_sign", 1.0)
    for f in lights:
        t = float(f.split("light_t")[1][:-4])
        if abs(t / 0.1 - round(t / 0.1)) > 1e-6 and f != lights[-1]:
            continue                                                    # every 0.1 in t (plus the last snapshot)
        F = np.load(f); P = F["Psi"].astype(float); Bp = F["Bphi"].astype(float); r = F["r"]; z = F["z"]
        rr = persistence_rings(P, r, z, d["r_t"] - 0.1)
        rings.append(dict(t=t, n=sum(x["depth"] >= RING_TH for x in rr), deepest=(rr[0]["depth"] if rr else 0.0), rings=rr[:10]))
        expect = sgn_seed * (np.sign(z)[None, :] if d["seed"] == "pair" else 1.0)
        region = P > 0.05 * P.max()
        w = np.abs(Bp) * r[:, None] * region
        tot = w.sum(); opp = (w * (Bp * expect < 0)).sum()
        cell_area=float((r[1]-r[0])*(z[1]-z[0]))
        up = (Bp * region * (z[None, :] > 0)).sum()*cell_area
        lo = (Bp * region * (z[None, :] < 0)).sum()*cell_area
        bphi.append(dict(t=t, reversal=float(opp / tot) if tot > 0 else 0.0, flux_above=float(up), flux_below=float(lo),
                         Bphi_max=float(Bp.max()), Bphi_min=float(Bp.min())))
    free = [x for x in rings if x["t"] >= t_off - 1e-9]
    n = [x["n"] for x in free]
    regime = None
    if n and d["t_end"] > t_off:
        final, mx = n[-1], max(n)
        regime = "single ring" if final == 0 else ("fragmented" if final >= 2 else ("doublet" if mx <= 1 else "transitional"))
    at = lambda tq: min(diag, key=lambda x: abs(x["t"] - tq))
    H0 = diag[0]["H"]
    rep = dict(name=d["name"], split=fis, regime_after_release=regime,
               rings_after_release=[(x["t"], x["n"]) for x in free],
               helicity_kept_to_release=(at(t_off)["H"] / H0 if H0 else None),
               helicity_kept_after_release=(at(d["t_end"])["H"] / at(t_off)["H"] if d["t_end"] > t_off and at(t_off)["H"] else None),
               magnetic_energy_kept_after_release=(at(d["t_end"])["M"] / at(t_off)["M"] if d["t_end"] > t_off and at(t_off)["M"] else None),
               kinetic_over_magnetic_after_release=(at(min(t_off + 0.05, d["t_end"]))["K"] / at(t_off - 0.01)["M"]
                                                    if d["t_end"] > t_off and at(t_off - 0.01)["M"] else None),
               lundquist_at_release=(float(np.sqrt(d["eps_b"]) * at(t_off)["Bmax"] / d["eta"]) if d["eta"] > 0 else None),
               lundquist_note="Characteristic length=1; eta=0 is flagged separately, not a finite physical Lundquist number",
               orientation=d.get("orientation_report", {}), seed=d["seed"], seed_sign=sgn_seed,
               reversal_max_before_release=(max([x["reversal"] for x in bphi if x["t"] <= t_off + 1e-9], default=None)),
               reversal_at_end=(bphi[-1]["reversal"] if bphi else None),
               release=(json.load(open(os.path.join(rdir, "finished.json"))).get("release", {}) if os.path.exists(os.path.join(rdir, "finished.json")) else {}))
    if d["mode"] == "kept":
        for key in ("helicity_kept_to_release", "helicity_kept_after_release", "magnetic_energy_kept_after_release",
                    "kinetic_over_magnetic_after_release", "lundquist_at_release"):
            rep[key]=None
        rep["release_note"]="No release in kept mode."
    if d["seed"]=="pair" and abs(H0)<1e-10:
        rep["helicity_kept_to_release"]=None
        rep["helicity_kept_after_release"]=None
        rep["helicity_ratio_note"]="Initial net helicity is near zero; ratios to that number are not meaningful. Inspect H(t) itself."
    return rep, rings, diag, tracks, bphi


# =============================================================================
# figures and data files
# =============================================================================
def frame_for(rdir,t):
    for stem in ('full','light'):
        for fmt in ('.9f','.3f'):
            f=os.path.join(rdir,f'{stem}_t{format(t,fmt)}.npz')
            if os.path.exists(f): return f
    return None


def panel(a, fn, t, window):
    from matplotlib.colors import TwoSlopeNorm
    F = np.load(fn); r, z = F["r"], F["z"]
    P, Bp = F["Psi"].astype(float), F["Bphi"].astype(float)
    rmax, zmax = min(window[0], float(r.max())), min(window[1], float(np.abs(z).max()))
    m = r <= rmax; n = np.abs(z) <= zmax
    rr = np.concatenate([-r[m][::-1], r[m]])
    PP = np.concatenate([P[m][::-1], P[m]])[:, n]; BB = np.concatenate([-Bp[m][::-1], Bp[m]])[:, n]
    vmax = max(np.abs(BB).max(), 1e-12)
    a.pcolormesh(rr, z[n], BB.T, cmap="RdBu_r", norm=TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax), shading="auto", rasterized=True)
    if P.max() > 0:
        a.contour(rr, z[n], PP.T, levels=np.linspace(0.02, 0.98, 20) * P.max(), colors="k", linewidths=0.5)
    if "Ur" in F.files:
        a.streamplot(r[m], z[n], (F["Ur"] + F["vr"]).astype(float)[m][:, n].T, (F["Uz"] + F["vz"]).astype(float)[m][:, n].T,
                     color="#2b8a3e", density=0.55, linewidth=0.45, arrowsize=0.5)
    elif "chi" in F.files:
        C = F["chi"].astype(float)[m][:, n]
        if np.ptp(C) > 0:
            a.contour(r[m], z[n], C.T, levels=np.linspace(C.min(), C.max(), 24)[1:-1], colors="#2b8a3e", linewidths=0.45, linestyles="solid")
    mx = (P == ndimage.maximum_filter(P, size=9)) & (P > 0.03 * P.max())
    for i, j in zip(*np.nonzero(mx)):
        if r[i] < rmax and abs(z[j]) < zmax:
            for s in (-1, 1):
                a.plot(s * r[i], z[j], "o", mfc="#f2b92b", mec="k", ms=4.5)
    a.set_aspect("equal"); a.set_xlim(-rmax, rmax); a.set_ylim(-zmax, zmax)
    a.set_title(f"t = {t:.2f}", fontsize=10); a.set_xlabel("r (mirrored)")


def panels_figure(d, rdir, times, window, title, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    files = [(t, frame_for(rdir, t)) for t in times]
    files = [(t, f) for t, f in files if f]
    if not files:
        return
    w = (min(window[0], d["r_box"]), min(window[1], d["z_box"]))
    pw = 2.8; ph = pw * w[1] / w[0] + 0.9
    fig, axes = plt.subplots(1, len(files), figsize=(pw * len(files) + 0.6, ph + 0.6), constrained_layout=True, sharey=True, squeeze=False)
    for a, (t, f) in zip(axes[0], files):
        panel(a, f, t, w)
    axes[0][0].set_ylabel("z")
    fig.suptitle(title, fontsize=10.5)
    fig.savefig(path + ".png", dpi=160); fig.savefig(path + ".pdf"); plt.close(fig)


def flow_panels_figure(d, fdir, times=(0.0, 0.4, 0.8, 0.95)):
    """Panels (a) and (b) of the surrogate/Lei-Ren comparison for this configuration at several times: the imposed
    meridional flow (speed and streamlines) with the initial spheromak overlaid, in the whole box. Kinematic: no run data."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fdir=Path(fdir); fdir.mkdir(parents=True,exist_ok=True)
    ps=make_params(dict(d,profile='surrogate')); pl=make_params(dict(d,profile='leiren'))
    gs,gl=mhd.Grid(ps),mhd.Grid(pl)
    P0,q0=mhd.spheromak_seed(pl,gl); Psi0=gl.rc**2*P0
    fig,ax=plt.subplots(2,len(times),figsize=(3.1*len(times)*max(d['r_box']/d['z_box'],0.45)+1.5,9.5),constrained_layout=True,squeeze=False)
    vmax=None
    for row,(lab,g,p) in enumerate((('(a) surrogate',gs,ps),('(b) Lei-Ren-inspired flow of this configuration',gl,pl))):
        for col,t in enumerate(times):
            tau=1.0-t; p.t_off=1.0e9; p.U_scale=1.0
            bt=g.background_terms(tau); te=float(np.hypot(tau,p.tau_f)); st=np.sqrt(te)
            sp=np.sqrt(bt['Ur']**2+bt['Uz']**2)*st
            if vmax is None: vmax=max(float(np.percentile(sp,99.5)),1e-6)
            a=ax[row,col]
            pm=a.pcolormesh(g.r,g.z,sp.T,cmap='Blues',vmin=0,vmax=vmax,shading='auto',rasterized=True)
            a.streamplot(g.r,g.z,bt['Ur'].T,bt['Uz'].T,color='k',density=1.0,linewidth=0.5,arrowsize=0.6)
            uth=g.r[:,None]*bt['OU']
            if np.abs(uth).max()>0:
                a.contour(g.r,g.z,uth.T,levels=np.array([0.25,0.5,0.75])*np.abs(uth).max(),colors='#c92a2a',linewidths=0.7)
            a.contour(g.r,g.z,Psi0.T,levels=np.array([0.05,0.2,0.4,0.6,0.8,0.95])*Psi0.max(),colors='#e8590c',linewidths=0.8)
            a.set_aspect('equal'); a.set_xlim(0,d['r_box']); a.set_ylim(-d['z_box'],d['z_box']); a.set_xlabel('r')
            if col==0: a.set_ylabel('z')
            a.set_title(f"{lab}\nt = {t:g} (tau_eff = {te:.3f}); max |u_p| = {np.sqrt(bt['Ur']**2+bt['Uz']**2).max():.3g}",fontsize=8)
    plt.colorbar(pm,ax=ax[:,-1],shrink=0.6,label=r'$|u_p|\sqrt{\tau_{eff}}$')
    fig.suptitle(f"Imposed flows for {d['name']}\nspeed (blue), streamlines (black), swirl at 25/50/75 % of its maximum (red), initial spheromak (orange); "
                 f"L0 = {d['lr_L0']}, cutoff {d['lr_cutoff']} R_c = {d['lr_Rc']}, envelope {d['flow_window']} a0 = {d['flow_r0']}, b0 = {d['flow_z0']} ({d['flow_window_evolution']})",fontsize=8.5)
    out=fdir/'flow_panels'
    fig.savefig(str(out)+'.png',dpi=150); fig.savefig(str(out)+'.pdf'); plt.close(fig)
    return str(out)+'.png'


def make_outputs(d, rdir, log):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    out = os.path.join(RES_ROOT, d["name"]); fdir = os.path.join(out, "figures"); ddir = os.path.join(out, "data")
    os.makedirs(fdir, exist_ok=True); os.makedirs(ddir, exist_ok=True)
    try:
        flow_panels_figure(d, fdir)
    except Exception as e:
        log(f'flow panels not drawn: {e}')
    log("analysing the snapshots ...")
    rep, rings, diag, tracks, bphi = analyse(d, rdir, log)
    flow = "Lei-Ren-inspired compact model" if d["profile"] == "leiren" else "surrogate flow"
    head = (f"{flow}" + (f", swirl S={d['lr_S']:g}" if d["profile"] == "leiren" and d["lr_S"] > 0 else "")
            + (", pair seed" if d["seed"] == "pair" else "") + f": $\\epsilon_B={d['eps_b']:g}$, $\\eta={d['eta']:g}$, $\\nu={d['nu']:g}$, "
            f"box $r<{d['r_box']:g}$, $|z|<{d['z_box']:g}$, {d['nr']}$\\times${d['nz']}")
    t_c0 = max(d["t_start"], round((d["t_off"] - 0.5) / LIGHT_DT) * LIGHT_DT)
    tc = sorted({round(round(x / LIGHT_DT) * LIGHT_DT, 6) for x in np.linspace(t_c0, min(d["t_off"], d["t_end"]), 6)})
    tf = sorted({round(round(x / LIGHT_DT) * LIGHT_DT, 6) for x in np.linspace(d["t_off"], d["t_end"], 5)}) if d["t_end"] > d["t_off"] else []
    for tag, times, what in (("collapse", tc, f"before the release (t < {d['t_off']:g})"),
                             ("after_release", tf, f"after the release at t = {d['t_off']:g} ({d['mode']})")):
        if not times:
            continue
        for wname, w in (("whole_box", (d["r_box"], d["z_box"])), ("central", (2.8, 2.0))):
            panels_figure(d, rdir, times, w, f"{head} - {what}: $B_\\phi$, $\\Psi$, axes (gold), flow (green)",
                          os.path.join(fdir, f"{tag}_{wname}"))
    # time series
    t = np.array([x["t"] for x in diag])
    fig, ax = plt.subplots(2, 3, figsize=(16, 7.5), constrained_layout=True)
    ax[0, 0].semilogy(t, [max(x["K"], 1e-12) for x in diag], label="kinetic (response)"); ax[0, 0].semilogy(t, [max(x["M"], 1e-12) for x in diag], label="magnetic")
    if "Ktot" in diag[-1]:
        ax[0, 0].semilogy(t, [max(x.get("Ktot", 0.0), 1e-12) for x in diag], "k--", lw=0.8, label="kinetic (imposed + response)")
    ax[0, 0].set_title("energies"); ax[0, 0].legend(frameon=False)
    ax[0, 1].plot(t, [x["H"] for x in diag], color="k"); ax[0, 1].set_title("magnetic helicity")
    ax[1, 0].semilogy(t, [max(x["Bmax"], 1e-12) for x in diag], label="max |B|"); ax[1, 0].semilogy(t, [max(x["vmax"], 1e-12) for x in diag], label="max |v| (response)")
    ax[1, 0].semilogy(t, [max(x["Umax"], 1e-12) for x in diag], label="max |U| (imposed)"); ax[1, 0].legend(frameon=False); ax[1, 0].set_title("maxima")
    if rings:
        tr = [x["t"] for x in rings]
        ax[1, 1].step(tr, [x["n"] for x in rings], where="post", color="#c92a2a", label="separate rings (deeper than 5 %)")
        a2 = ax[1, 1].twinx(); a2.plot(tr, [x["deepest"] for x in rings], "k--", lw=0.8, label="deepest secondary ring"); a2.set_ylabel("depth / Psi_max")
        ax[1, 1].legend(frameon=False, loc="upper left"); ax[1, 1].set_title("rings")
    if bphi:
        tb = [x["t"] for x in bphi]
        ax[0, 2].plot(tb, [x["reversal"] for x in bphi], color="#c92a2a")
        ax[0, 2].set_ylim(0, 1); ax[0, 2].set_title("fraction of |B_phi| opposite to the seed's twist (field region)", fontsize=9)
        ax[1, 2].plot(tb, [x["flux_above"] for x in bphi], label="toroidal flux above the midplane")
        ax[1, 2].plot(tb, [x["flux_below"] for x in bphi], label="toroidal flux below the midplane")
        ax[1, 2].axhline(0, color="k", lw=0.6); ax[1, 2].legend(frameon=False); ax[1, 2].set_title("toroidal flux by half", fontsize=9)
    for a in ax.ravel():
        a.axvline(d["t_off"], color="#adb5bd", lw=0.8, ls=":"); a.set_xlabel("t")
    fig.suptitle(head, fontsize=11)
    fig.savefig(os.path.join(fdir, "time_series.png"), dpi=150); fig.savefig(os.path.join(fdir, "time_series.pdf")); plt.close(fig)
    # the split: island depth growth
    fs = rep["split"]
    if fs.get("tau_fit"):
        tr_ = [q for q in tracks if q["t"] <= d["t_off"] and q["dmax"] > 0 and fs["tau_fit"] - q["tau"] > 0]
        x = np.array([fs["tau_fit"] - q["tau"] for q in tr_]); y = np.array([q["dmax"] for q in tr_])
        if len(x) > 3:
            fig, a = plt.subplots(figsize=(6, 4.4), constrained_layout=True)
            a.loglog(x, y, ".", ms=3, label=f"island depth (exponent {fs['depth_exp']:.2f})")
            xs = np.logspace(np.log10(max(x.min(), 1e-5)), np.log10(x.max()), 10)
            a.loglog(xs, y.max() * (xs / xs[-1])**1.5, "k:", label="slope 3/2 (fold)"); a.loglog(xs, y.max() * (xs / xs[-1])**2, "k--", label="slope 2 (pitchfork)")
            a.set_xlabel("tau_b - tau"); a.set_ylabel("depth / Psi_max"); a.legend(frameon=False)
            a.set_title(f"split at t = {fs['t_s']:.3f}: {fs['type']}", fontsize=10)
            fig.savefig(os.path.join(fdir, "split.png"), dpi=150); fig.savefig(os.path.join(fdir, "split.pdf")); plt.close(fig)
    # data files
    write_any(os.path.join(ddir, "params.json"), json.dumps(d, indent=1))
    rep["implementation"]="vs3b axisymmetric reference-inspired model; not completed Lei-Ren, not full 3-D"
    rep["window"]={k:d[k] for k in ("flow_window","flow_r0","flow_z0","flow_inner","flow_window_evolution","lr_L0")}
    rep["config_sha256"]=d["config_sha256"]
    # Composite trapezoidal work estimate on recorded times; duplicate one-sided
    # release samples have dt=0, so a step in Pext is not spuriously averaged away.
    tt=np.array([x["t"] for x in diag]); pp=np.array([x.get("Pext",0.) for x in diag])
    rep["external_work_trapezoid"]=float(np.sum(np.diff(tt)*.5*(pp[:-1]+pp[1:])))
    rep["external_work_note"]="Approximate diagnostic quadrature, not an exact discrete energy conservation test."
    write_any(os.path.join(ddir, "summary.json"), json.dumps(rep, indent=1, default=float))
    keys = ["t", "tau", "phase", "H", "M", "K", "Ktot", "KU", "Kpol_U", "Kswirl_U", "Pext", "dKU_dt", "dissipation", "pure_power_balance_residual", "Bmax", "Jmax", "vmax", "Umax", "Psi_max", "J2_integral", "ohmic_dissipation", "ell_B_rms", "ell_B_rms_cells", "Vmax_total"]
    write_any(os.path.join(ddir, "diag.csv"), ",".join(keys) + "\n" + "\n".join(",".join(f"{x.get(k, float('nan')):.8g}" for k in keys) for x in diag))
    write_any(os.path.join(ddir, "rings.csv"), "t,separate_rings,deepest_secondary,rings(depth@r,z)\n" + "\n".join(
        f"{x['t']:.3f},{x['n']},{x['deepest']:.5f}," + ";".join(f"{q['depth']:.4f}@{q['r']:.3f},{q['z']:.3f}" for q in x["rings"]) for x in rings))
    write_any(os.path.join(ddir, "bphi.csv"), "t,reversal_fraction,toroidal_flux_above,toroidal_flux_below,Bphi_max,Bphi_min\n" + "\n".join(
        f"{x['t']:.3f},{x['reversal']:.4f},{x['flux_above']:.6g},{x['flux_below']:.6g},{x['Bphi_max']:.6g},{x['Bphi_min']:.6g}" for x in bphi))
    with open(os.path.join(ddir, "tracks.json"), "w") as fh:
        json.dump(tracks, fh)
    lines = [f"run: {d['name']}", f"flow: {flow}; eps_B = {d['eps_b']}, eta = {d['eta']}, nu = {d['nu']}, tau_f = {d['tau_f']}",
             f"box: 0 < r < {d['r_box']}, |z| < {d['z_box']} (flow taper r {d['r_t']:g}-{d['r_o']:g}, |z| {d['z_t']:g}-{d['z_o']:g}); lattice {d['nr']} x {d['nz']}",
             f"time: t = {d['t_start']} -> {d['t_end']}, release at t = {d['t_off']} ({d['mode']}" + (f", ramp {d['t_ramp']:g}" if d["mode"] == "ramp" else "") + ")",
             ("release check: " + release_text(rep["release"]) if rep.get("release") else "release check: none (flow kept or t_end before the release)"),
             (f"cutoff: {d['lr_cutoff']} at R_c = {d['lr_Rc']}; swirl: S = {d['lr_S']}, ring X_R = {d['lr_XR']}, core X_c = {d['lr_Xc']}, direction {d['swirl_sign']:+d}" if d["profile"] == "leiren"
              else f"swirl: the surrogate's own, direction {d['swirl_sign']:+d}"),
             f"seed: {d['seed']}, B_phi sign above the midplane {int(d['seed_sign']):+d}", "orientation: " + orientation_text(d), "",
             f"split: t = {fs['t_s']}, type {fs['type']}, island-depth ratio {fs['island_ratio']}, depth exponent {fs['depth_exp']}, separation exponent {fs['sep_exp']}",
             f"Lundquist proxy (length=1) at release: {rep['lundquist_at_release']}",
             f"helicity kept up to the release: {rep['helicity_kept_to_release']}",
             f"after the release: regime {rep['regime_after_release']}; helicity kept {rep['helicity_kept_after_release']}; "
             f"magnetic energy kept {rep['magnetic_energy_kept_after_release']}; kinetic/magnetic energy just after the release {rep['kinetic_over_magnetic_after_release']}",
             "separate rings (t, number): " + ", ".join(f"{a:.1f}:{b}" for a, b in rep["rings_after_release"]),
             f"toroidal field opposite to the seed's twist: at most {rep['reversal_max_before_release']} of |B_phi| before the release, "
             f"{rep['reversal_at_end']} at the end"]
    write_any(os.path.join(ddir, "summary.txt"), "\n".join(lines) + "\n")
    log("figures: " + fdir); log("data:    " + ddir)
    print("\n" + "\n".join(lines))


# =============================================================================
# main
# =============================================================================
def main():
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--params',help='new parameter file or an existing vs3b params.json; compatible runs resume safely')
    ap.add_argument('--preset',choices=('compact_pilot','compact_refined','legacy_geometry'))
    ap.add_argument('--import-vs3',metavar='FILE',help='copy old inputs to a NEW vs3b experiment, never resume old checkpoints')
    ap.add_argument('--set',action='append',default=[],metavar='KEY=VALUE',help='override an input and create a NEW fingerprint')
    ap.add_argument('--write-params',metavar='FILE',help='write validated config then exit (no integration)')
    ap.add_argument('--preflight',action='store_true',help='static size/resolution audit of these parameters; no integration')
    ap.add_argument('--check',action='store_true',help='parameter-aware velocity/force/handover checks; no integration')
    ap.add_argument('--status',action='store_true')
    ap.add_argument('--plot',metavar='NAME',help='render existing snapshot results')
    ap.add_argument('--no-plots',action='store_true',help='finish integration without expensive ring inventory/figures')
    ap.add_argument('--resume',action='store_true',help='require an existing compatible run (not needed on first launch)')
    ap.add_argument('--unlock',action='store_true',help='remove only a provably stale LOCAL run lock')
    ap.add_argument('--allow-underresolved',action='store_true',help='EXPLORATORY override of geometric cell-count guard')
    ap.add_argument('--allow-noncompact',action='store_true',help='EXPLORATORY override of the small-flow energy guard')
    ap.add_argument('--max-steps',type=int,help='controlled stop after this many accepted steps in this invocation')
    ap.add_argument('--max-wall-seconds',type=float,help='controlled stop with checkpoint')
    ap.add_argument('--extend',metavar='NAME',help='continue a FINISHED run to a later time as a new experiment: --extend NAME --set t_end=T')
    ap.add_argument('--flow-panels',action='store_true',help="figure of the imposed flows (surrogate and this run's Lei-Ren flow) at t = 0, 0.4, 0.8, 0.95 with the initial seed; no integration")
    args=ap.parse_args()
    Path(RES_ROOT).mkdir(parents=True,exist_ok=True)
    if args.status:
        for f in sorted(Path(RES_ROOT).glob('*/data/params.json')):
            d=safe.read_json(f); root=Path(d['runs_dir']).expanduser()/d['name']
            st=safe.read_json(root/'status.json') if (root/'status.json').exists() else {'status':'planned'}
            print(f"{d['name']}: {st.get('status')}, t={st.get('t_reached','-')}, pid={st.get('pid','-')}")
        return
    if args.plot:
        d=finish_params(safe.read_json(Path(RES_ROOT)/args.plot/'data/params.json'))
        root=Path(d['runs_dir']).expanduser()/d['name']
        make_outputs(d,str(root),print); return
    sources=sum(bool(x) for x in (args.params,args.preset,args.import_vs3,args.extend))
    if sources>1: ap.error('choose only one of --params, --preset, --import-vs3, --extend')
    interactive_mode=not any((args.params,args.preset,args.import_vs3,args.preflight,args.check,args.write_params,args.set,args.extend,args.flow_panels))
    if args.extend:
        parent=finish_params(safe.read_json(Path(RES_ROOT)/args.extend/'data/params.json'))
        pfin=Path(parent['runs_dir']).expanduser()/parent['name']/'finished.json'
        if not pfin.exists(): raise RuntimeError(f'{args.extend} has not finished; only finished runs can be extended.')
        raw={k:v for k,v in parent.items() if k not in cfg.GENERATED}
        raw['parent_run']=parent['name']; raw['parent_t']=float(safe.read_json(pfin)['t_reached'])
        if not any(s.startswith('t_end=') for s in args.set):
            ap.error('--extend needs the new end time: --set t_end=T')
    elif args.params: raw=safe.read_json(args.params)
    elif args.import_vs3: raw=cfg.import_vs3(safe.read_json(args.import_vs3))
    elif args.preset: raw=safe.read_json(Path(HERE)/'presets'/(args.preset+'.json'))
    elif interactive_mode: raw=interactive()
    else: raw={}
    d=finish_params(cfg.apply_overrides(raw,args.set))
    pfile=Path(RES_ROOT)/d['name']/'data/params.json'
    with threadpool_limits(limits=d['threads']):
        if args.unlock:
            print(safe.unlock_stale(Path(d['runs_dir']).expanduser()/d['name'])); return
        if args.write_params:
            target=Path(args.write_params)
            if target.exists() and safe.read_json(target)!=d:
                raise RuntimeError('Refuse to overwrite a different parameter file. Choose a new --write-params path.')
            safe.atomic_json(target,d)
            print(f'Wrote {args.write_params}; NO simulation started.'); return
        if args.check:
            text=checks.run_all(make_params(d),d)
            safe.atomic_text(pfile.parent/'checks.txt',text); return
        if args.flow_panels:
            out=flow_panels_figure(d,pfile.parent.parent/'figures')
            print(f'Written {out}; NO simulation started.'); return
        if args.preflight:
            a=write_preflight(d)
            print(f'Written to {pfile.parent}; NO simulation started.')
            if a['blocking_issues']: raise SystemExit(2)
            return
        if interactive_mode:
            a=write_preflight(d)
            print(f"\nName: {d['name']}\nResults: {pfile.parent.parent}\nRaw data: {Path(d['runs_dir']).expanduser()/d['name']}")
            if a['blocking_issues']:
                print('This configuration is blocked. Change parameters; no simulation started.'); return
            if ask('start now? y/n','y',str,choices=('y','n'))!='y': return
            safe.atomic_json(pfile,d)
            if ask('detach into background? y/n','n',str,choices=('y','n'))=='y':
                logf=pfile.parent.parent/'progress.log'
                cmd=[sys.executable,str(Path(__file__).resolve()),'--params',str(pfile)]
                if args.no_plots: cmd.append('--no-plots')
                with logf.open('a') as f:
                    proc=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,cwd=HERE)
                print(f'Started PID {proc.pid}. Follow: tail -f "{logf}"')
                return
        safe.atomic_json(pfile,d)
        def log(message): print(time.strftime('%Y-%m-%d %H:%M:%S ')+message,flush=True)
        keep_awake()
        result=run(d,log,allow_underresolved=args.allow_underresolved,allow_noncompact=args.allow_noncompact,
                   max_steps=args.max_steps,max_wall=args.max_wall_seconds,resume_only=args.resume)
        if result is not None and not args.no_plots:
            try: make_outputs(d,result,log)
            except Exception as e:
                # Integration status remains successful; rendering failure is separate.
                safe.atomic_json(Path(result)/'analysis_error.json',dict(error=f'{type(e).__name__}: {e}'))
                raise RuntimeError('Integration saved successfully, but post-processing failed; see analysis_error.json') from e


def ramp_scale(t,d):
    if d['mode']!='ramp' or t<=d['t_off']: return 1.,0.
    if t>=d['t_off']+d['t_ramp']: return 0.,0.
    x=(t-d['t_off'])/d['t_ramp']
    value=float(mhd.taper(x))
    # Stable logistic derivative: avoid multiplying an infinity by zero.
    exponent=-1/x+1/(1-x)
    if abs(exponent)>700: return value,0.
    derivative=-value*(1-value)*(1/x**2+1/(1-x)**2)/d['t_ramp']
    return value,derivative


def set_background_phase(p,t,d,handed=False):
    if d['mode']=='kept':
        p.t_off=1e99; p.U_scale=1.
    elif d['mode']=='sudden':
        p.t_off=d['t_off'] if handed else 1e99
        p.U_scale=1.
    else:
        p.U_scale=ramp_scale(t,d)[0]
        p.t_off=d['t_off']+d['t_ramp'] if handed else 1e99


def rhs_at(g,state,t,d):
    """RK-stage-consistent ramp; never retime the shrinking profile itself.

    During a ramp, -A'(t) U0 is added to the response, canceling the change
    of decomposition in V=A U0+v. The remaining force is
    A*d_t U0 + A^2(U0.grad)U0 - nu*A*Delta U0 (up to pressure).
    """
    p=g.p
    if d['mode']=='ramp': p.U_scale=ramp_scale(t,d)[0]
    k,aux=mhd.rhs(g,state,t)
    if d['mode']=='ramp':
        _,adot=ramp_scale(t,d)
        if adot!=0:
            with checks.grid_params(g,replace(p,U_scale=1.,t_off=1e99)):
                base=g.background_terms(1-t)
            ku=-g.L5(g.pad(base['SU']))
            k=(k[0]-adot*ku,k[1]-adot*base['OU'],k[2],k[3])
    return k,aux


def write_preflight(d,log=print):
    audit,curves=checks.preflight(make_params(d),d)
    root=Path(RES_ROOT)/d['name']/'data'
    root.mkdir(parents=True,exist_ok=True)
    safe.atomic_json(root/'preflight.json',audit)
    safe.atomic_json(root/'params.json',d)
    safe.atomic_text(root/'preflight.txt',checks.audit_text(audit))
    keys=list(curves)
    safe.atomic_text(root/'initial_energy_enclosure.csv',','.join(keys)+'\n'+
                     '\n'.join(','.join(f'{curves[k][i]:.12g}' for k in keys) for i in range(len(curves['radius'])))+'\n')
    log(checks.audit_text(audit))
    return audit



if __name__ == "__main__":
    main()
