"""Time histories of the imposed flow on the production lattice: poloidal and swirl energies, peak speed, strain and the
L2 norm of the Eulerian acceleration d_t U, with and without the regularization law tau_e^{1/2}."""
import sys, os, json, numpy as np
from paths import *
import openai_mhd_3d as mhd, configuration as cfg
from silib import params_of
d = params_of(50, 0.05); p = cfg.make_params(d); p.t_off = 1.0e9
g = mhd.Grid(p, build_poisson=False); r = g.rc; dV = g.dV
def K(bg): return 0.5 * np.sum((bg["Ur"]**2 + bg["Uz"]**2) * dV), 0.5 * np.sum((r * bg["OU"])**2 * dV)
rows = []
for t in np.concatenate([np.linspace(0, 0.9, 19), np.linspace(0.905, 1.0, 20)]):
    tau = 1 - t; h = 1e-3 * max(tau, 0.01)
    b0 = g.background_terms(tau); b1 = g.background_terms(tau + h); b2 = g.background_terms(tau - h)
    Kp, Ks = K(b0)
    dUr = -(b1["Ur"] - b2["Ur"]) / (2 * h); dUz = -(b1["Uz"] - b2["Uz"]) / (2 * h); dUp = -r * (b1["OU"] - b2["OU"]) / (2 * h)
    nA = np.sqrt(np.sum((dUr**2 + dUz**2 + dUp**2) * dV)); nU = np.sqrt(2 * (Kp + Ks))
    rows.append(dict(t=float(t), tau_e=float(np.sqrt(tau**2 + p.tau_f**2)), Kpol=float(Kp), Kswirl=float(Ks), Umax=float(np.sqrt((b0["Ur"]**2 + b0["Uz"]**2 + (r * b0["OU"])**2).max())),
                     dtU=float(nA), normU=float(nU)))
    print(f"t={t:.3f} tau_e={rows[-1]['tau_e']:.4f} Kpol={Kp:8.1f} Kswirl={Ks:6.1f} Umax={rows[-1]['Umax']:6.2f} |d_t U|={nA:8.1f}")
json.dump(rows, open(HERE + "/curves.json", "w"), indent=1)
