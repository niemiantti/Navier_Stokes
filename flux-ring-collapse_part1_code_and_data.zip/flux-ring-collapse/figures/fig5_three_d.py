"""Figure 5 at 183 mm: three dimensions. (a, b) the two 3D runs, flux surfaces of the azimuthal average in the colour code of
Fig. 1a and field lines integrated in the full 3D field (render3d.py), on a common scale; (c) flux surfaces at t = 2, axisymmetric
run against the azimuthal average of the 3D run; (d) energy in the azimuthal modes inside r < 2; (e) magnetic energy, 3D
against axisymmetric; (f) their relative differences, and the helicity difference."""
import sys, os, glob, json, csv, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); os.makedirs(HERE + "/out", exist_ok=True)
from style import plt, MM, WIDTH, C_ETA, GOLD, LAYER, letter
from PIL import Image
import matplotlib
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.cm import ScalarMappable

def rd(fn):
    rows = list(csv.DictReader(open(fn))); return {k: np.array([float(r[k]) if r[k] not in ("", None) else np.nan for r in rows]) for k in rows[0]}
D3 = rd(HERE + "/data/three_dimensional/e50_eta0.01_nu0.1_N256_box4x4x5.5/diag.csv")
D2a = rd(glob.glob(HERE + "/data/results/LR_e50_eta0.01_*/data/diag.csv")[0])
D2b = rd(HERE + "/data/results/legacy_geometry_unconfined_d87ab6fa32e4/data/diag.csv")
S = {k: {kk: np.array(vv) for kk, vv in v.items()} for k, v in json.load(open(HERE + "/data/three_dimensional/e1000_eta0.05_nu0.1_N256_box5x5x7/e1000_series.json")).items()}
B50, B1000 = C_ETA[0.01], C_ETA[0.05]                     # the colours of the two runs (their diffusivities)
TS50, TS1000, TMERGE = 0.703, 0.881, 2.28

HFIG = 163
fig = plt.figure(figsize=(WIDTH, HFIG * MM))
def ax_mm(x, y, w, h, **kw):       # axes from millimetres, y measured from the top of the figure
    return fig.add_axes([x / 183, 1 - (y + h) / HFIG, w / 183, h / HFIG], **kw)

# ------------------------------------------------------------------ a, b: the renders on a common scale
PXU = 2000 / 10.6                  # render pixels per length unit (parallel scale 5.3)
MMPX = 88.0 / 1960                 # millimetres per render pixel in the figure
def place(fn, crop, x, y):
    A = np.asarray(Image.open(fn).convert("RGB"))[crop[0]:crop[1], crop[2]:crop[3]]
    h, w = A.shape[:2]; ax = ax_mm(x, y, w * MMPX, h * MMPX); ax.imshow(A, interpolation="lanczos"); ax.set_axis_off(); return ax, w * MMPX, h * MMPX
TOP = 6.0
axa, wa, ha = place(HERE + "/data/renders/e50_final.png", (280, 1730, 255, 985), 1.0, TOP)
axb, wb, hb = place(HERE + "/data/renders/e1000_final.png", (0, 1960, 30, 1220), 1.0 + wa + 2.0, TOP)
letter(axa, "a", r"$\epsilon_B$ = 50, $\eta$ = 0.01, $t$ = 2", x=0.0, y=1.0 + 2.0 / ha)
letter(axb, "b", r"$\epsilon_B$ = 1000, $\eta$ = 0.05, $t$ = 3", x=0.0, y=1.0 + 2.0 / hb)
# scale bars of two seed radii
axs = ax_mm(1.0, TOP + ha + 2.0, wa, 88.0 - ha - 2.0); axs.set_axis_off(); axs.set_xlim(0, 1); axs.set_ylim(0, 88.0 - ha - 2.0)
Lmm = 2 * PXU * MMPX
axs.plot([0.12, 0.12], [1.0, 1.0 + Lmm], color="k", lw=1.0, solid_capstyle="butt")
axs.text(0.17, 1.0 + Lmm / 2, "2 seed radii\n(a and b)", fontsize=7, va="center", ha="left")
# key: flux layers and the field-line colours
xk = 1.0 + wa + 2.0 + wb + 2.0; axk = ax_mm(xk, TOP + 2, 27, 40); axk.set_axis_off()
axk.text(0, 1.0, "flux surfaces of the\nazimuthal average\nenclosing, of each\nring's own flux:", fontsize=7, va="top", transform=axk.transAxes)
key = [(LAYER["red"], "innermost 10%"), (LAYER["orange"], "40%"), (LAYER["green"], "70%"), (LAYER["blue"], "outer surface,\n5% of peak flux")]
for i, (c, s) in enumerate(key):
    yy = 0.50 - i * 0.135
    axk.add_patch(plt.Rectangle((0.0, yy - 0.035), 0.16, 0.07, color=c, alpha=(0.55 if i == 3 else 1.0), transform=axk.transAxes, lw=0))
    axk.text(0.22, yy, s, fontsize=7, va="center", transform=axk.transAxes)
cmap = LinearSegmentedColormap.from_list("lines", matplotlib.colormaps["Purples"](np.linspace(0.5, 1.0, 256)))
cax = ax_mm(xk, TOP + 50, 3.0, 26)
cb = plt.colorbar(ScalarMappable(norm=Normalize(0, 1), cmap=cmap), cax=cax, ticks=[0, 0.5, 1]); cb.ax.tick_params(labelsize=7, length=2, width=0.5)
cax.text(-0.3, 1.06, "field lines:\n|B| / max|B|", transform=cax.transAxes, fontsize=7, va="bottom", ha="left")
cax.text(4.2, 0.5, "max|B| =\n0.22 (a),\n0.035 (b)", transform=cax.transAxes, fontsize=7, va="center", ha="left")

# ------------------------------------------------------------------ c: flux surfaces at t = 2, axisymmetric against 3D average
G = np.load(HERE + "/data/raw/LR_e50_eta0.01_unconfined_a8e1bde7faf6/light_t2.000000000.npz")
A = np.load(HERE + "/data/three_dimensional/e50_eta0.01_nu0.1_N256_box4x4x5.5/avg2d_t2.000.npz")
axc = ax_mm(134.0, TOP, 46.0, 86.0)
LEV = np.array([0.03, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9])
m = G["r"] <= 2.6
axc.contour(-G["r"][m], G["z"], G["Psi"][m].T, levels=LEV * G["Psi"].max(), colors="k", linewidths=0.5)
m = A["r"] <= 2.6
axc.contour(A["r"][m], A["z"], A["Psi"][m].T, levels=LEV * A["Psi"].max(), colors=B50, linewidths=0.5)
axc.axvline(0, color="#adb5bd", lw=0.5)
axc.set_aspect("equal"); axc.set_xlim(-2.4, 2.4); axc.set_ylim(-4.4, 4.4); axc.set_xticks([-2, -1, 0, 1, 2]); axc.set_xticklabels(["2", "1", "0", "1", "2"])
axc.set_xlabel("$r$"); axc.set_ylabel("$z$")
axc.text(0.03, 0.985, "axisymmetric", transform=axc.transAxes, fontsize=7, va="top", ha="left")
axc.text(0.97, 0.985, "3D, average", transform=axc.transAxes, fontsize=7, va="top", ha="right", color=B50)
letter(axc, "c", r"flux surfaces, $\epsilon_B$ = 50, $t$ = 2", x=-0.30, y=1.0 + 2.0 / 86)

# ------------------------------------------------------------------ d: modes
Y2 = TOP + 88.0 + 13.0; H2 = 45.0
axd = ax_mm(14.0, Y2, 46.0, H2); axe = ax_mm(74.5, Y2, 46.0, H2); axf = ax_mm(134.0, Y2, 46.0, H2)
for (t, v, col, ls) in ((D3["t"], D3["nonaxi"], B50, "-"), (D3["t"], D3["m2"], B50, "--"), (D3["t"], D3["m1"], B50, ":"),
                        (S["nonaxi"]["t"], S["nonaxi"]["v"], B1000, "-"), (S["m1"]["t"], S["m1"]["v"], B1000, ":"), (S["m2"]["t"], S["m2"]["v"], B1000, "--")):
    axd.semilogy(t, v, ls, color=col, lw=1.0)
for tt, col, ls in ((TS50, B50, ":"), (TS1000, B1000, ":"), (1.0, "#868e96", "-"), (TMERGE, B1000, "-.")):
    axd.axvline(tt, color=col, lw=0.6, ls=ls, zorder=0)
axd.text(0.66, 0.3, "splits", fontsize=7, ha="right", va="center"); axd.text(1.05, 0.3, "release", fontsize=7, ha="left", va="center", color="#495057")
axd.text(2.22, 2e-6, "merger", fontsize=7, ha="right", va="center", color=B1000)
# maxima of the summed and of the dominant-mode fractions
axd.plot([1.96, 1.86, 2.6, 2.4], [0.0131, 0.0101, 0.042, 0.041], "o", ms=2.2, mew=0, color="k", zorder=5)
axd.text(1.62, 0.019, "1.3%", fontsize=7, color=B50, ha="right", va="bottom"); axd.text(1.93, 0.0047, "1.0%", fontsize=7, color=B50, ha="left", va="center")
axd.text(2.36, 0.065, "4.2%, 4.1%", fontsize=7, color=B1000, ha="left", va="bottom")
axd.set_xlim(0, 4); axd.set_ylim(1e-8, 1); axd.set_xlabel("$t$"); axd.set_ylabel(r"energy fraction in $m\geq1$, $r<2$")
axd.set_yticks([1e-8, 1e-6, 1e-4, 1e-2, 1]); axd.tick_params(axis="y", which="both", labelsize=7.5); axd.minorticks_off()
l1 = axd.legend(handles=[plt.Line2D([], [], color=B50, lw=1.0, label=r"$\epsilon_B$ = 50"), plt.Line2D([], [], color=B1000, lw=1.0, label=r"$\epsilon_B$ = 1000")],
                loc="center right", bbox_to_anchor=(1.0, 0.47), handlelength=1.4, borderaxespad=0.2, labelspacing=0.2)
axd.add_artist(l1)
axd.legend(handles=[plt.Line2D([], [], color="#495057", lw=1.0, ls="-", label=r"all $m\geq1$"), plt.Line2D([], [], color="#495057", lw=1.0, ls=":", label="$m$ = 1"),
                    plt.Line2D([], [], color="#495057", lw=1.0, ls="--", label="$m$ = 2")], loc="lower right", handlelength=1.6, borderaxespad=0.2, labelspacing=0.2)
letter(axd, "d", "departure from axisymmetry", x=-0.29, y=1.03)

# ------------------------------------------------------------------ e: magnetic energy
for D2, t3, M3, col, lab, ytxt in ((D2a, D3["t"], D3["M"], B50, r"$\epsilon_B$ = 50", 13), (D2b, S["M"]["t"], S["M"]["v"], B1000, r"$\epsilon_B$ = 1000", 150)):
    axe.semilogy(D2["t"], D2["M"], "-", color="k", lw=1.0); axe.semilogy(t3, M3, "--", color=col, lw=1.1)
axe.text(1.9, 55, r"$\epsilon_B$ = 1000, $\eta$ = 0.05", fontsize=7.2, color=B1000); axe.text(0.12, 9.0, r"$\epsilon_B$ = 50, $\eta$ = 0.01", fontsize=7.2, color=B50, va="top")
axe.axvline(1.0, color="#868e96", lw=0.6, zorder=0)
axe.set_xlim(0, 4); axe.set_ylim(2, 700); axe.set_xlabel("$t$"); axe.set_ylabel("magnetic energy"); axe.tick_params(axis="y", which="both", labelsize=7.5)
h = [plt.Line2D([], [], color="k", lw=1.0, label=r"axisymmetric, 384$\times$1024"), plt.Line2D([], [], color="#495057", lw=1.1, ls="--", label=r"3D, 256$^3$")]
axe.legend(handles=h, loc="upper right", borderaxespad=0.2)
letter(axe, "e", "3D against axisymmetric", x=-0.27, y=1.03)

# ------------------------------------------------------------------ f: relative differences
out = {}
for D2, t3, M3, H3, col, nm in ((D2a, D3["t"], D3["M"], np.abs(D3["H"]), B50, "50"), (D2b, S["M"]["t"], S["M"]["v"], S["H"]["v"], B1000, "1000")):
    M2 = np.interp(t3, D2["t"], D2["M"]); H2 = np.interp(t3, D2["t"], np.abs(D2["H"]))
    dM = 100 * (M3 / M2 - 1); dH = 100 * (H3 - H2) / H2[0]
    axf.plot(t3, dM, "-", color=col, lw=1.0); axf.plot(t3, dH, ":", color=col, lw=1.2)
    out[nm] = (t3, dM, dH)
axf.axhline(0, color="k", lw=0.5); axf.axvline(1.0, color="#868e96", lw=0.6, zorder=0)
axf.set_xlim(0, 4); axf.set_ylim(-4, 15); axf.set_xlabel("$t$"); axf.set_ylabel("difference (%)")
h = [plt.Line2D([], [], color="#495057", lw=1.0, label="magnetic energy, relative"), plt.Line2D([], [], color="#495057", lw=1.2, ls=":", label=r"helicity, relative to $H(0)$")]
axf.legend(handles=h, loc="upper left", borderaxespad=0.2)
axf.text(3.3, 9.0, r"$\epsilon_B$ = 50", fontsize=7.2, color=B50, ha="right", va="center"); axf.text(2.75, -3.0, r"$\epsilon_B$ = 1000", fontsize=7.2, color=B1000, ha="right", va="center")
letter(axf, "f", "3D minus axisymmetric", x=-0.22, y=1.03)
for nm, (t3, dM, dH) in out.items():
    for lo, hi in ((0, 0.7), (0.7, 1.2), (1.2, 3.0), (3.0, 4.01)):
        k = (t3 >= lo) & (t3 < hi)
        print(f"eps_B = {nm}: t in [{lo}, {hi}): max |dM| {np.max(np.abs(dM[k])):.2f}%, max |dH|/H0 {np.max(np.abs(dH[k])):.3f}%")
o = HERE + "/out/Fig5.pdf"; fig.savefig(o); fig.savefig(o.replace(".pdf", ".png"), dpi=300); print("written", o)
