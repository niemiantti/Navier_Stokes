import os, json, glob, csv
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
R = B + "/figures/data/results/"
REG = {(1, 0.05): "passive", (3, 0.05): "passive", (10, 0.05): "passive", (20, 0.05): "rolls", (50, 0.05): "rolls", (100, 0.05): "rolls", (200, 0.05): "rolls", (300, 0.05): "rolls",
       (500, 0.05): "central ring forming", (1000, 0.05): "triplet", (1, 0.01): "passive", (10, 0.01): "chain", (50, 0.01): "chain", (100, 0.01): "chain", (200, 0.01): "chain",
       (300, 0.01): "chain", (500, 0.01): "asym 2-3", (1000, 0.01): "single"}
runs = {}
for d in sorted(glob.glob(R + "*/")):
    if "LRref" in d: continue
    p = json.load(open(d + "data/params.json")); key = (int(p["eps_b"]), p["eta"])
    rows = list(csv.reader(open(d + "data/rings.csv")))[1:]
    ring = {round(float(x[0]), 1): (int(x[1]) + 1, float(x[2]), ",".join(x[3:])[:90]) for x in rows}
    runs.setdefault(key, {}).update(ring)
for k in sorted(runs, key=lambda k: (-k[1], k[0])):
    r = runs[k]; t4 = r.get(4.0)
    hist = "".join(str(min(r[t][0], 9)) if t in r else "." for t in [round(0.1 * i, 1) for i in range(41)])
    print(f"eta={k[1]:<5g} eps={k[0]:>5g} outcome(fig4d)={REG[k]:22s} rings@t=4: {t4[0]} (deepest secondary {t4[1]:.3f})  history(0..4 by 0.1): {hist}")
print()
r = runs[(100, 0.01)]; print("eps=100 eta=0.01 total rings at t=1.7,1.8,1.9,2.4,2.5,2.6:", [r[t][0] for t in (1.7, 1.8, 1.9, 2.4, 2.5, 2.6)])
r = runs[(50, 0.01)]; print("eps=50 eta=0.01 at t=4:", r[4.0])
