"""Parameter-aware static audits and diagnostic checks for vs3b.

All integrals use the physical cylindrical measure 2*pi*r*dr*dz. Audits
sample the actual discrete background, including derivative terms from
EVERY taper. They are not evidence of MHD grid convergence.
"""
from __future__ import annotations
from contextlib import contextmanager
from dataclasses import replace
import math
import numpy as np
from scipy.optimize import brentq
import openai_mhd_3d as mhd


@contextmanager
def grid_params(g, p):
    old=g.p
    g.p=p
    try:
        yield
    finally:
        g.p=old


def component_pad(g, f, component):
    """Physical vector parity at r=0, with zero imposed velocity at walls.

    Grid.pad implements even regular-variable parity; U_r and U_phi are
    odd physical components, so their axis ghosts MUST be changed.
    """
    a=g.pad(f,"odd","odd")
    if component in ("r","phi"):
        a[1,2:-2]=-f[0]
        a[0,2:-2]=-f[1]
    return a


def continuum_velocity(p,r,z,tau):
    """Untapered LEIREN velocity, including INTERNAL L0 scaling and offset.
    Only compare points whose whole differencing stencil has all cutoffs=1.
    """
    te=float(np.hypot(tau,p.tau_f)); d=p.lr_delta
    lam=mhd.lambda_leiren(te,np.asarray(z)/p.lr_L0,d)
    Z=(np.asarray(z)/p.lr_L0)/lam**(1-d); L=1-d*Z**2
    uz=p.lr_L0*(p.lr_a*Z+p.lr_j)/lam**(1+d)
    ur=np.asarray(r)/(2*lam**2*L)*(p.lr_a*((2+d)*Z**2-1)+(1+d)*p.lr_j*Z)
    return ur,uz


def kappa_profile(Xc=.5,XR=8.):
    R=np.array([.05,.5,2.,4.4258,8.,32.,500.])
    kap=.8*R/(R+Xc)+1.2*R**2/(XR**2+R**2)
    # Monotone kappa: dlog(g)/dlog(R)=(1-kappa)/2. Unique maximum.
    fun=lambda x:.8*x/(x+Xc)+1.2*x*x/(XR*XR+x*x)-1
    peak=brentq(fun, min(Xc,XR)*1e-10,max(Xc,XR)*100)
    return R,kap,float(peak)


def energy_enclosure(g,p,tau):
    bt=g.background_terms(tau)
    pol=.5*(bt["Ur"]**2+bt["Uz"]**2)*g.dV
    sw=.5*(g.rc*bt["OU"])**2*g.dV
    P,q=mhd.spheromak_seed(p,g)
    Pg=g.pad(P)
    Br=-g.rc*g.ddz(Pg); Bz=2*P+g.rc*g.ddr(Pg)
    mag=.5*(Br**2+Bz**2+(g.rc*q)**2)*g.dV
    ss=np.sqrt(g.rc**2+g.z[None,:]**2)
    total=pol+sw
    radii=np.unique(np.r_[np.linspace(0,max(p.rbox,p.zbox),161),.25,.5,1.])
    order=np.argsort(ss.ravel())
    sorted_r=ss.ravel()[order]
    curves={"radius":radii.tolist()}
    summary={}
    for label,energy in (("flow",total),("poloidal",pol),("swirl",sw),("seed_magnetic_unweighted",mag)):
        E=float(energy.sum())
        cumulative=np.cumsum(energy.ravel()[order])
        ix=np.searchsorted(sorted_r,radii,side="right")
        sums=np.where(ix>0,cumulative[np.maximum(ix-1,0)],0.0)
        fractions=sums/E if E>0 else np.zeros_like(sums)
        curves[label]=fractions.tolist()
        metrics=dict(energy=E)
        for radius in (.25,.5,1.):
            metrics[f"fraction_inside_{radius:g}"]=float(energy[ss<=radius].sum()/E) if E>0 else None
        for fraction in (.5,.95,.99):
            k=int(np.searchsorted(cumulative,fraction*E)) if E>0 else 0
            metrics[f"radius_{int(100*fraction)}"]=float(sorted_r[min(k,len(sorted_r)-1)]) if E>0 else None
        summary[label]=metrics
    summary["seed_outer_radius_continuum"]=1.0
    summary["grid_note"]="Discrete derivatives may extend support by a stencil cell; no renormalization or clipping of velocities."
    return summary,curves,ss,total


def resolved_scale_rows(p,times):
    dr=p.rbox/p.nr; dz=2*p.zbox/p.nz; cell=max(dr,dz)
    rows=[]
    for t in times:
        tau=1-t; te=float(np.hypot(tau,p.tau_f))
        if p.profile=="leiren":
            lr=p.lr_L0*np.sqrt(te)
            lz=p.lr_L0*te**((1-p.lr_delta)/2)
            lc=lr*np.sqrt(2*p.lr_Xc)
        else:
            lr=p.lr0*np.sqrt(te); lz=p.lz0*te**(.5-p.h); lc=lr
        sizes={"internal_radial":lr,"internal_axial":lz,"swirl_core":lc}
        if p.flow_window=="ellipsoid":
            ar,az=mhd.envelope_axes(p,tau)
            sizes.update(window_radial=ar,window_axial=az,
                         window_radial_shell=(1-p.flow_inner)*ar,
                         window_axial_shell=(1-p.flow_inner)*az)
        row={"t":float(t),"tau_eff":te,"dr":dr,"dz":dz}
        for key,val in sizes.items():
            row[key]=float(val)
            spacing=dz if "axial" in key else dr
            row[key+"_cells"]=float(val/spacing)
        row["minimum_feature_cells"]=min(row[k] for k in row if k.endswith("_cells"))
        rows.append(row)
    return rows


def strain_metrics(g,bt):
    r=g.rc; ur=bt["Ur"]; uz=bt["Uz"]; ut=r*bt["OU"]
    rg=component_pad(g,ur,"r"); zg=component_pad(g,uz,"z"); tg=component_pad(g,ut,"phi")
    err=g.ddr(rg); ett=ur/r; ezz=g.ddz(zg)
    erz=.5*(g.ddz(rg)+g.ddr(zg)); ert=.5*(g.ddr(tg)-ut/r); ezt=.5*g.ddz(tg)
    gamma=np.sqrt(err**2+ett**2+ezz**2+2*(erz**2+ert**2+ezt**2))
    return float(gamma.max())


def preflight(p,d):
    """No Poisson matrix needed; samples the requested production grid."""
    forced_end=min(d["t_end"],d["t_off"]+(d["t_ramp"] if d["mode"]=="ramp" else 0))
    if d["mode"]=="kept":
        forced_end=d["t_end"]
    times=sorted(set([d["t_start"],forced_end,.5*(d["t_start"]+forced_end)]
                     +([1.] if d["t_start"]<=1.<=forced_end else [])))
    pp=replace(p,t_off=1e99,U_scale=1.)
    g=mhd.Grid(pp,build_poisson=False)
    summary,curves,ss,e=energy_enclosure(g,pp,1-d["t_start"])
    E=float(e.sum()); target=d["small_flow_radius"]
    frac=float(e[ss<=target].sum()/E) if E>0 else None
    rows=resolved_scale_rows(pp,times)
    problems=[]; warnings=[]
    for row in rows:
        bt=g.background_terms(1-row["t"])
        speed=np.sqrt(bt["Ur"]**2+bt["Uz"]**2+(g.rc*bt["OU"])**2)
        if not np.all(np.isfinite(speed)):
            problems.append("Nonfinite prescribed velocity in preflight")
        gamma=strain_metrics(g,bt)
        row.update(Umax=float(speed.max()),kinetic_energy=float(.5*np.sum(speed**2*g.dV)),gamma_strain_frobenius=gamma)
        ref=velocity_errors(pp,1-row['t'])
        row['velocity_reference_relative_linf']=ref['relative_linf']
        row['velocity_reference_relative_l2']=ref['relative_l2']
        if ref['relative_linf'] > 0.05:
            warnings.append(f"At t={row['t']:g}, discrete meridional velocity differs from the fine-difference continuum reference by {100*ref['relative_linf']:.2f}% in relative L_inf. Refine before quantitative interpretation.")
        row["estimated_resistive_scale"]=float(np.sqrt(p.eta/gamma)) if gamma>0 and p.eta>0 else None
        row["estimated_resistive_scale_cells"]=(row["estimated_resistive_scale"]/max(g.dr,g.dz)
                                               if row["estimated_resistive_scale"] is not None else None)
        if row["minimum_feature_cells"]<d["min_feature_cells"]:
            problems.append(f"At t={row['t']:g}, smallest geometric feature spans {row['minimum_feature_cells']:.2f} cells (< {d['min_feature_cells']:g})")
        elif row["minimum_feature_cells"]<d["preferred_feature_cells"]:
            warnings.append(f"At t={row['t']:g}, smallest geometric feature spans {row['minimum_feature_cells']:.2f} cells; prefer >= {d['preferred_feature_cells']:g} then check convergence")
        if row["estimated_resistive_scale_cells"] is not None and row["estimated_resistive_scale_cells"]<3:
            warnings.append(f"At t={row['t']:g}, strain-diffusion estimate has {row['estimated_resistive_scale_cells']:.2f} cells; this is a heuristic, not a resolved-sheet measurement")
        if p.flow_window=="ellipsoid":
            ar,az=mhd.envelope_axes(pp,1-row["t"])
            if ar+3*g.dr>=p.r_t or az+3*g.dz>=p.z_t:
                warnings.append(f"At t={row['t']:g}, compact window/stencil overlaps the box taper; enclosure no longer isolates the box independently")
    mincells=min(row["minimum_feature_cells"] for row in rows)
    if d["require_small_flow"] and (frac is None or frac<d["small_flow_fraction"]):
        problems.append(f"Only {frac if frac is not None else 'undefined'} of initial flow energy lies inside s={target:g}; target is {d['small_flow_fraction']:g}")
    if p.profile=="leiren" and p.lr_delta>=1/200:
        warnings.append("lr_delta is not in the paper's strict <1/200 range; this is a prescribed reference-inspired model, not theorem-certified.")
    if p.flow_window=="none":
        warnings.append("Compact confinement is OFF. L0 alone does NOT bound the full flow or the swirl tail.")
    warnings.append("Axisymmetric r-z evolution only. Static enclosure/resolution checks do not prove MHD convergence.")
    if d["mode"] in ("sudden","ramp") and forced_end<d["t_end"]:
        warnings.append("Confinement applies to the IMPOSED flow; freely evolving fluid and B may leave it after release.")
    out=dict(config_sha256=d["config_sha256"],times=times,initial=summary,
             target_radius=target,target_fraction=d["small_flow_fraction"],actual_fraction=frac,
             resolution_rows=rows,min_feature_cells=mincells,
             blocking_issues=list(dict.fromkeys(problems)),warnings=list(dict.fromkeys(warnings)),
             is_production_convergence_test=False,
             diffusivity_note="ell_eta=sqrt(eta/max||sym grad U||_F) is indicative only; rotation, local fields, backreaction and later free dynamics matter.")
    return out,curves


def audit_text(a):
    lines=["VS3B PRE-FLIGHT (actual requested grid; no MHD time integration)",
           "Magnetic seed: outer continuum radius = 1; compact window acts on BOTH SU and Omega.",
           f"Configuration: {a['config_sha256']}",""]
    for key in ("flow","poloidal","swirl","seed_magnetic_unweighted"):
        m=a["initial"][key]
        def fmt(x): return "n/a (zero component)" if x is None else f"{x:.6g}"
        lines.append(f"{key}: energy={m['energy']:.7g}; F(0.5)={fmt(m['fraction_inside_0.5'])}; F(1)={fmt(m['fraction_inside_1'])}; r95={fmt(m['radius_95'])}")
    lines += ["",f"Small-flow requirement: F({a['target_radius']:g}) >= {a['target_fraction']:g}; actual={a['actual_fraction']}",
              "t          internal-r cells  internal-z cells  min-feature cells  max speed   velocity error L_inf"]
    for q in a["resolution_rows"]:
        lines.append(f"{q['t']:8.4f}  {q['internal_radial_cells']:16.3f}  {q['internal_axial_cells']:16.3f}  {q['minimum_feature_cells']:17.3f}  {q['Umax']:10.4g}  {q['velocity_reference_relative_linf']:12.4e}")
    lines.extend("BLOCKING: "+x for x in a["blocking_issues"])
    lines.extend("WARNING: "+x for x in a["warnings"])
    return "\n".join(lines)+"\n"


def background_power(g,p,tau,state=None,dtau=1e-4):
    """Continuum-force quadrature with second-order spatial derivatives.

    f = A*d_t U0 + A^2 (U0.grad)U0 - nu*A*Delta U0, up to pressure.
    A is FROZEN in the finite difference. In the ramp driver the -A' U0
    response source cancels the A' U0 change of background, so this is also
    the effective smooth-ramp force; it is NOT generally A times f(U0).
    Force shutoff is not differentiated as a delta impulse.
    Pressure work vanishes for an exactly solenoidal, boundary-compatible
    continuum total velocity; discrete quadrature has truncation errors.
    """
    r=g.rc
    off=1-tau>=p.t_off-1e-12 or p.U_scale==0
    if off:
        fd=mhd.derived(g,state,tau) if state is not None else None
        K=0.5*float(np.sum((fd['vr']**2+fd['vz']**2+fd['vphi']**2)*g.dV)) if fd is not None else 0.
        return dict(Pext=0.,Ktot=K,KU=0.,Kpol_U=0.,Kswirl_U=0.,dKU_dt=0.,dissipation=0.,pure_power_balance_residual=0.)
    frozen=replace(p,t_off=1e99)
    with grid_params(g,frozen):
        bt=g.background_terms(tau)
        # tau-dtau corresponds to LATER physical time: no extra minus sign.
        later=g.background_terms(tau-dtau); earlier=g.background_terms(tau+dtau)
        Ur,Uz,Ut=bt['Ur'],bt['Uz'],r*bt['OU']
        dUr=(later['Ur']-earlier['Ur'])/(2*dtau)
        dUz=(later['Uz']-earlier['Uz'])/(2*dtau)
        dUt=r*(later['OU']-earlier['OU'])/(2*dtau)
        rg=component_pad(g,Ur,'r'); zg=component_pad(g,Uz,'z'); tg=component_pad(g,Ut,'phi')
        adv=lambda a:Ur*g.ddr(a)+Uz*g.ddz(a)
        lap=lambda a:g.L5(a)-2/r*g.ddr(a)
        fr=dUr+adv(rg)-Ut**2/r-p.nu*(lap(rg)-Ur/r**2)
        ft=dUt+adv(tg)+Ur*Ut/r-p.nu*(lap(tg)-Ut/r**2)
        fz=dUz+adv(zg)-p.nu*lap(zg)
        if state is None:
            vr=vz=vt=0.
        else:
            fd=mhd.derived(g,state,tau); vr,vz,vt=fd['vr'],fd['vz'],fd['vphi']
    Ktot=.5*float(np.sum(((Ur+vr)**2+(Uz+vz)**2+(Ut+vt)**2)*g.dV))
    pure=float(np.sum((Ur*fr+Uz*fz+Ut*ft)*g.dV))
    Pext=float(np.sum(((Ur+vr)*fr+(Uz+vz)*fz+(Ut+vt)*ft)*g.dV))
    KU=lambda b:.5*float(np.sum((b['Ur']**2+b['Uz']**2+(r*b['OU'])**2)*g.dV))
    dKdt=(KU(later)-KU(earlier))/(2*dtau)
    diss=p.nu*float(np.sum((g.ddr(rg)**2+g.ddz(rg)**2+g.ddr(zg)**2+g.ddz(zg)**2+
                            g.ddr(tg)**2+g.ddz(tg)**2+(Ur**2+Ut**2)/r**2)*g.dV))
    return dict(Pext=Pext,Ktot=Ktot,KU=KU(bt),Kpol_U=.5*float(np.sum((Ur**2+Uz**2)*g.dV)),
                Kswirl_U=.5*float(np.sum(Ut**2*g.dV)),dKU_dt=dKdt,dissipation=diss,
                pure_power_balance_residual=pure-dKdt-diss)


def handover_jump(p,tau=0.):
    pp=replace(p,t_off=1e99,U_scale=1.)
    g=mhd.Grid(pp); bt=g.background_terms(tau)
    result={}
    for label,zeta in (("central",bt['zetaU']),("conservative",-g.L5(g.pad(bt['SU'])))):
        S=g.solve_poisson(zeta); sg=g.pad(S)
        vr=-g.rc*g.ddz(sg); vz=2*S+g.rc*g.ddr(sg)
        u2=bt['Ur']**2+bt['Uz']**2+(g.rc*bt['OU'])**2
        du2=(vr-bt['Ur'])**2+(vz-bt['Uz'])**2
        K=.5*float(np.sum(u2*g.dV))
        Knew=.5*float(np.sum((vr**2+vz**2+(g.rc*bt['OU'])**2)*g.dV))
        result['velocity_jump_'+label]=float(np.sqrt(du2.max()/max(u2.max(),1e-300)))
        result['energy_jump_'+label]=(Knew-K)/max(K,1e-300)
    return result


def velocity_errors(p,tau=0.):
    """Independent fourth-order small-step differentiation of the entire SU.
    This tests compact cutoffs too; the tiny-step reference is not an analytic
    proof, and must itself be checked when sharpening the cutoff further.
    """
    pp=replace(p,t_off=1e99,U_scale=1.)
    g=mhd.Grid(pp,build_poisson=False)
    bt=g.background_terms(tau)
    h=min(g.dr,g.dz)*1e-3
    r,z=g.rc,g.z[None,:]
    S=lambda rr,zz:mhd.background(pp,rr,zz,tau)[0]
    sr=(S(r-2*h,z)-8*S(r-h,z)+8*S(r+h,z)-S(r+2*h,z))/(12*h)
    sz=(S(r,z-2*h)-8*S(r,z-h)+8*S(r,z+h)-S(r,z+2*h))/(12*h)
    ur=-r*sz; uz=2*S(r,z)+r*sr
    error=(bt['Ur']-ur)**2+(bt['Uz']-uz)**2
    mag=ur**2+uz**2
    return dict(nr=p.nr,nz=p.nz,t=1-tau,lr_L0=p.lr_L0,
                relative_linf=float(np.sqrt(error.max()/max(mag.max(),1e-300))),
                relative_l2=float(np.sqrt(np.sum(error*g.dV)/max(np.sum(mag*g.dV),1e-300))))


def run_all(p,d,print_fn=print):
    a,_=preflight(p,d)
    lines=[audit_text(a),"\nACTUAL-PARAMETER CHECKS (not hard-coded L0=1)"]
    for t in a['times']:
        lines.append(str(velocity_errors(p,1-t)))
    lines.append("Handover: "+str(handover_jump(p,1-d['t_off'])))
    _,kap,peak=kappa_profile(p.lr_Xc,p.lr_XR)
    lines.append(f"Untapered reference model: kappa<2, sample values={kap.tolist()}, swirl maximum R={peak:.8g}")
    g=mhd.Grid(p,build_poisson=False)
    for tau in (1-d['t_start'],.5,.0):
        lines.append("Force quadrature "+str(dict(t=1-tau,**background_power(g,p,tau))))
    text="\n".join(lines)+"\n"; print_fn(text); return text
