"""Supplementary Figure 6: direct fit of the flux ridge to the cusp normal form through the pinch, from the two repeats
with snapshots every 0.005 (eps_B = 100, eta = 0.05, a fold; eps_B = 200, eta = 0.01, a late split of the flat sheet)."""
from sifigs import *
from scipy.ndimage import gaussian_filter1d
D = np.load(SCR + "/data/controls/cusp_dense/cusp_ridges.npz")
keys = sorted({k.rsplit("/", 1)[0] for k in D.files})
def profiles(run):
    out = {}
    for k in keys:
        if k.startswith(run + "/"): out[round(float(D[k + "/t"]), 4)] = (D[k + "/z"], D[k + "/R"] / D[k + "/R"].max())
    return dict(sorted(out.items()))
CASES = (("cusp_e100_eta0.05", 0.545, 0.4, (0.49, 0.566), 100, 0.05), ("cusp_e200_eta0.01", 0.959, 0.3, (0.89, 0.931), 200, 0.01))
fig = plt.figure(figsize=(WIDTH, 125 * MM))
X0 = [0.065, 0.405, 0.73]; W = 0.255; Y = [0.585, 0.085]; H = 0.34
axes = [[fig.add_axes([x, y, W, H]) for x in X0] for y in Y]
RESULT = {}
for row, (run, ts_track, w, trange, eps, eta) in enumerate(CASES):
    P = profiles(run); ts = [t for t in P if 0.3 < t < 1.0]
    ax = axes[row][0]
    show = [t for t in ts if trange[0] <= t <= min(trange[1] + 0.03, 0.999)]
    cm = matplotlib.colormaps["viridis"]
    for t, c in zip(show, cm(np.linspace(0, 0.95, len(show)))):
        z, R = P[t]; ax.plot(z, R, color=c, lw=0.8, label=(f"$t$ = {t:g}" if t in (show[0], show[len(show) // 2], show[-1]) else None))
    ax.set_xlim(-1.0, 1.0); ax.set_ylim(0.93, 1.003); ax.set_xlabel("height $z$"); ax.set_ylabel(r"$\max_r\Psi(r,z)\,/\,\Psi_{\max}$"); ax.legend(loc=("lower center" if row == 0 else "upper left"), fontsize=6.6, handlelength=1.2)
    letter(ax, "ad"[row], rf"$\epsilon_B$ = {eps}, $\eta$ = {eta}: the ridge through the pinch", x=-0.24, y=1.03)
    T, A, Bc = [], [], []
    for t in ts:
        if not (trange[0] <= t <= trange[1]): continue
        z, R = P[t]; f = Cf.ridge_fit(z, gaussian_filter1d(R, 2.0), half_width=w)
        if f is None: continue
        T.append(t); A.append(f["a"]); Bc.append(f["b"])
    T, A, Bc = map(np.array, (T, A, Bc))
    ax = axes[row][1]
    ax.plot(T, A, "o-", color="#1971c2", ms=2.6, lw=0.9, label="$a$, quadratic coefficient")
    ax.plot(T, 10 * Bc, "s-", color="#c92a2a", ms=2.6, lw=0.9, label="$10\\,b$, asymmetry")
    ab = (27 * Bc**2 / 4)**(1 / 3); ax.plot(T, ab, "--", color="#868e96", lw=0.9, label="$a_b = (27b^2/4)^{1/3}$, fold threshold")
    ax.axhline(0, color="k", lw=0.5); ax.axvline(ts_track, color="k", ls=":", lw=0.7)
    ax.text(ts_track - 0.001, (0.0 if row == 0 else -0.25), f"$t_s$ (tracks) = {ts_track}", fontsize=6.4, ha="right", va="bottom", rotation=90)
    g = A**3 - 27 * Bc**2 / 4; birth = zero = None
    for i in range(1, len(T)):
        if g[i - 1] < 0 <= g[i] and birth is None: birth = T[i - 1] + (T[i] - T[i - 1]) * (-g[i - 1]) / (g[i] - g[i - 1])
        if A[i - 1] < 0 <= A[i] and zero is None: zero = T[i - 1] + (T[i] - T[i - 1]) * (-A[i - 1]) / (A[i] - A[i - 1])
    RESULT[run] = dict(a_zero=zero, fold=birth, b_before=Bc[:6].tolist(), b_mean=float(Bc[:6].mean()), b_std=float(Bc[:6].std()))
    ax.set_xlabel("$t$"); ax.set_ylabel("fitted normal-form coefficients"); ax.legend(loc="lower left" if row == 0 else "lower left", fontsize=6.4, handlelength=1.4)
    letter(ax, "be"[row], f"quartic fit, half-width {w}", x=-0.22, y=1.03)
    ax.text(0.03, 0.97, f"$a$ = 0 at $t$ = {zero:.3f}" + (f"\nfold condition at $t$ = {birth:.3f}" if (birth and row == 0) else ""), transform=ax.transAxes, fontsize=6.6, va="top")
    ax = axes[row][2]
    if row == 0:
        tt, dep = [], []
        for t, aa, bb in zip(T, A, Bc):
            if birth is None or t < birth: continue
            zc = Cf.cusp_critical(aa, bb)
            if len(zc) < 3: continue
            f = -zc**4 / 4 + aa * zc**2 / 2 + bb * zc; tt.append(t); dep.append(float(min(f[0] - f[1], f[2] - f[1])))
        ax.plot(tt, dep, "o-", color=GOLD, ms=2.8, lw=0.9, label="predicted by the fitted normal form")
        tr = tracks_of(eps, eta)
        Tm = [q["t"] for q in tr if 0.54 <= q["t"] <= 0.57]; Dm = [q["dmax"] for q in tr if 0.54 <= q["t"] <= 0.57]
        ax.plot(Tm, Dm, "k-", lw=0.9, label="measured on the ridge (tracks)")
        ax.set_xlim(0.535, 0.57); ax.set_ylim(0, 0.0095); ax.set_xlabel("$t$"); ax.set_ylabel(r"island depth / $\Psi_{\max}$"); ax.legend(loc="upper left", fontsize=6.6)
        letter(ax, "c", "predicted and measured island depth", x=-0.24, y=1.03)
    else:
        later = [t for t in ts if 0.93 <= t <= 0.975]; cm2 = matplotlib.colormaps["plasma"]
        for t, c in zip(later, cm2(np.linspace(0, 0.9, len(later)))):
            z, R = P[t]; ax.plot(z, R, color=c, lw=0.8, label=(f"$t$ = {t:g}" if t in (later[0], later[-1]) else None))
        ax.set_xlim(-1.0, 1.0); ax.set_ylim(0.9, 1.003); ax.set_xlabel("height $z$"); ax.set_ylabel(r"$\max_r\Psi(r,z)\,/\,\Psi_{\max}$"); ax.legend(loc="upper left", fontsize=6.6, handlelength=1.2)
        letter(ax, "f", "the flat top breaks into several maxima", x=-0.24, y=1.03)
save(fig, "si_fig6_fit")
import json; print(json.dumps(RESULT, indent=1))
