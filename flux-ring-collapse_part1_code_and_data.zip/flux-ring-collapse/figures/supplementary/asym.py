"""Up-down asymmetry diagnostics from the light snapshots of a run (Supplementary Fig. 4c).
For each snapshot: the odd (in z) part of the toroidal variable q = B_phi/r relative to its even part, the energy of the
up-down antisymmetric part of the response meridional flow relative to the symmetric part, the height of the ridge
maximum, and the tilt of the ridge top (coefficient b of a quartic fit about the maximum).
usage: python3 asym.py RUN_DIR OUT.json    (RUN_DIR holds config.json and the light_t*.npz snapshots of the run)"""
import sys, os, json, glob, numpy as np
from paths import *
os.chdir(CODE)
import openai_mhd_3d as mhd, configuration as cfg
import leiren_bigbox_vs3b as drv
run, out = sys.argv[1], sys.argv[2]
d = json.load(open(run + "/config.json"))["parameters"]; p = cfg.make_params(d); g = mhd.Grid(p); r = g.rc; z = g.z
w = (r * g.dr * g.dz)                                   # volume weight (up to 2 pi) per cell
def parts(F):
    Fe = 0.5 * (F + F[:, ::-1]); Fo = 0.5 * (F - F[:, ::-1]); return Fe, Fo
rows = []
for f in sorted(glob.glob(run + "/light_t*.npz")):
    a = np.load(f); t = float(a["t"])
    if t > 0.75: break
    q = a["Bphi"].astype(float) / r; qe, qo = parts(q)
    # energy of the toroidal field, even and odd parts (odd part relative to even)
    Ee = (w * (r * qe)**2).sum(); Eo = (w * (r * qo)**2).sum()
    # response meridional flow: S = chi/r^2 - S_U ; symmetric flow <-> S odd ; antisymmetric <-> S even
    drv.set_background_phase(p, t, d, False); bt = g.background_terms(1 - t)
    Sv = a["chi"].astype(float) / r**2 - bt["SU"]
    Se, So = parts(Sv)
    def kin(Sx):
        Sg = g.pad(Sx); vr = -r * g.ddz(Sg); vz = 2 * Sx + r * g.ddr(Sg); return (w * (vr**2 + vz**2)).sum()
    Ksym, Kanti = kin(So), kin(Se)
    # sign of the antisymmetric flow at the torus: v_z (even part) at the magnetic axis radius, z = 0
    Psi = a["Psi"].astype(float); im = np.unravel_index(np.argmax(Psi), Psi.shape); ra, za = r[im[0], 0], z[im[1]]
    Sg = g.pad(Se); vz_anti = (2 * Se + r * g.ddr(Sg))[im[0], np.argmin(abs(z))]
    # ridge and its tilt: quartic fit of max_r Psi about its maximum over |z - z_max| < 0.4
    R = Psi.max(axis=0); j = R.argmax(); zm = z[j]; m = abs(z - zm) < 0.4
    c = np.polyfit(z[m] - zm, R[m] / R.max(), 4)      # c0 x^4 + c1 x^3 + c2 x^2 + c3 x + c4
    # normal form after the shift that removes x^3: x = y - c1/(4 c0); b is the linear coefficient there
    s_ = -c[1] / (4 * c[0]); y = np.polyval(c, (z[m] - zm)) ; cc = np.polyfit(z[m] - zm - s_, R[m] / R.max(), 4)
    rows.append(dict(t=t, Eodd_over_Eeven=Eo / Ee, Kanti_over_Ksym=Kanti / Ksym, Kanti=Kanti, Ksym=Ksym, vz_anti_axis=vz_anti, z_axis=za, r_axis=ra, z_ridge_max=zm, b=cc[3], a=-2 * cc[2], c4=cc[0]))
    print("t=%.2f  E_odd/E_even=%.3e  K_anti/K_sym=%.3e  v_z(anti) at axis=%+.3e  z_axis=%+.3f  b=%+.2e a=%+.2e" % (t, Eo / Ee, Kanti / Ksym, vz_anti, za, cc[3], -2 * cc[2]), flush=True)
json.dump(rows, open(os.path.abspath(out) if os.path.isabs(out) else os.path.join(os.path.dirname(os.path.abspath(__file__)), out), "w"), indent=1)
