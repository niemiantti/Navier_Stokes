"""Scaling of the regularized imposed flow at t = 1 with the regularization time tau_f, on the production lattice:
poloidal and swirl energy, peak speed, strain, the acceleration jump at the release and its time scale."""
import sys, os, json, numpy as np
from paths import *
import openai_mhd_3d as mhd, configuration as cfg
from silib import params_of
d0 = params_of(50, 0.05)
out = []
for tf in (0.4, 0.2, 0.1, 0.05, 0.025, 0.0125):
    d = dict(d0); d["tau_f"] = tf
    p = cfg.make_params(d); p.t_off = 1.0e9
    g = mhd.Grid(p, build_poisson=True); r = g.rc; dV = g.dV; nu = p.nu
    bg = g.background_terms(0.0)
    Ur, Uz, OU, zU, aU = bg["Ur"], bg["Uz"], bg["OU"], bg["zetaU"], bg["alphaU"]; Up = r * OU
    Kp = 0.5 * np.sum((Ur**2 + Uz**2) * dV); Ks = 0.5 * np.sum(Up**2 * dV)
    zg = g.pad(zU); OUg = g.pad(OU, "odd", "even")
    dz_dt = -g.advect(zg, Ur, Uz) + g.ddz(g.pad(OU**2, "odd", "even")) + nu * g.L5(zg)
    da_dt = -g.advect(OUg, Ur, Uz) - 2.0 * aU * OU + nu * g.L5(OUg)
    Sx = g.solve_poisson(dz_dt); Sg = g.pad(Sx); dUr, dUz = -r * g.ddz(Sg), 2 * Sx + r * g.ddr(Sg); dUp = r * da_dt
    nU = np.sqrt(np.sum((Ur**2 + Uz**2 + Up**2) * dV)); nA = np.sqrt(np.sum((dUr**2 + dUz**2 + dUp**2) * dV)); mA = np.sqrt((dUr**2 + dUz**2 + dUp**2).max())
    j0 = np.argmin(np.abs(g.z)); Urm = Ur[:, j0]; gam = -(Urm[1] - Urm[0]) / (g.r[1] - g.r[0])
    Dnu = nu * np.sum((g.ddr(g.pad(Ur, "odd", "odd"))**2 + g.ddz(g.pad(Ur, "odd", "odd"))**2 + g.ddr(g.pad(Uz, "even", "even"))**2 + g.ddz(g.pad(Uz, "even", "even"))**2
                       + g.ddr(g.pad(Up, "odd", "even"))**2 + g.ddz(g.pad(Up, "odd", "even"))**2) * dV)
    row = dict(tau_f=tf, Kpol=Kp, Kswirl=Ks, Umax=float(np.sqrt((Ur**2 + Uz**2 + Up**2).max())), strain=float(gam), jump_norm=float(nA), jump_max=float(mA),
               T_jump=float(nU / nA), K_over_D=float((Kp + Ks) / Dnu), core_cells=float(np.sqrt(2 * 0.5 * tf) / g.dr))
    out.append(row); print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in row.items()})
json.dump(out, open(HERE + "/tauf_scan.json", "w"), indent=1)
