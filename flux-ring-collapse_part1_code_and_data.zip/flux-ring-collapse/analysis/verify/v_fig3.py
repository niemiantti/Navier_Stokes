import json, glob, numpy as np, os
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
R = B + "/figures/data/results/"
def resolve(cps, dz=16.0/1024, dmin=1e-3, cells=3):
    c = sorted(cps, key=lambda q: q["z"])
    while True:
        worst = None
        for i, q in enumerate(c):
            if q["kind"] != "X" or i == 0 or i == len(c) - 1: continue
            lo, hi = c[i-1], c[i+1]; d = min(lo["psi"], hi["psi"]) - q["psi"]; sh = lo if lo["psi"] < hi["psi"] else hi
            sc = min(d/dmin, abs(sh["z"]-q["z"])/(cells*dz))
            if sc < 1 and (worst is None or sc < worst[0]): worst = (sc, i, c.index(sh))
        if worst is None: return c
        i, j = sorted(worst[1:]); del c[j]; del c[i]
def show(tr, ts):
    for t in ts:
        q = min(tr, key=lambda x: abs(x["t"] - t)); c = resolve(q["cps"])
        print(f"   t={q['t']:.4f} resolved: " + " ".join(f"{x['kind']}({x['z']:+.3f},{x['psi']:.3f})" for x in c) + f" | raw nO={q['nO']} nX={q['nX']}")
tr = json.load(open(glob.glob(R + "LR_e1_eta0.05_*/data/tracks.json")[0]))
print("eps=1 eta=0.05 (Fig 3a) around the birth")
show(tr, [0.28, 0.29, 0.295, 0.30, 0.305, 0.31, 0.3145, 0.32, 0.35])
# where is the global max relative to the original axis before the birth?
tr100 = json.load(open(glob.glob(R + "LR_e100_eta0.05_*/data/tracks.json")[0]))
print("eps=100 eta=0.05 (Fig 3b) near the end of the saddle line")
show(tr100, [0.85, 0.86, 0.87, 0.875, 0.88, 0.9])
tr1000 = json.load(open(R + "legacy_geometry_unconfined_d87ab6fa32e4/data/tracks.json"))
print("eps=1000 eta=0.05 (Fig 3c)")
show(tr1000, [1.5, 1.6, 1.69, 1.71, 1.80, 1.82, 2.02, 2.04, 2.27, 2.29])
# slopes of Fig 3d pitchfork
def island(tracks, zwin, dmin=2e-5):
    T, D, Sp = [], [], []
    for q in tracks:
        c = sorted(q["cps"], key=lambda x: x["z"]); best = None
        for i, x in enumerate(c):
            if x["kind"] != "X" or i == 0 or i == len(c) - 1 or not (zwin[0] <= x["z"] <= zwin[1]): continue
            lo, hi = c[i-1], c[i+1]; d = min(lo["psi"], hi["psi"]) - x["psi"]; sh = lo if lo["psi"] < hi["psi"] else hi
            if best is None or d > best[0]: best = (d, abs(sh["z"] - x["z"]))
        if best and best[0] > dmin: T.append(q["t"]); D.append(best[0]); Sp.append(best[1])
    return np.array(T), np.array(D), np.array(Sp)
T, D, Sp = island(tr, (-0.3, 0.3)); k = min(25, len(T))
p = np.polyfit(T[:k], Sp[:k]**2, 1); tb = -p[1]/p[0]; x = T - tb; ok = (x > 0) & (x < 0.05)
print(f"Fig3d pitchfork: t_b={tb:.5f}, n={ok.sum()}, slopes depth {np.polyfit(np.log(x[ok]), np.log(D[ok]), 1)[0]:.3f}, sep {np.polyfit(np.log(x[ok]), np.log(Sp[ok]), 1)[0]:.3f}")
