"""Common style for the figures: drawn at the final double-column width (183 mm), Helvetica-like
sans serif (FreeSans), text 6.5-7 pt, panel letters 8 pt bold, TrueType fonts embedded so that text stays editable."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

MM = 1 / 25.4
WIDTH = 183 * MM
C_ETA = {0.05: "#c92a2a", 0.01: "#1971c2"}           # the two magnetic diffusivities
GOLD, BLK = "#e8a317", "k"
LAYER = {"red": "#d7301f", "orange": "#fc8d59", "green": "#41ab5d", "blue": "#6baed6"}

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["FreeSans", "DejaVu Sans"], "font.size": 7.2,
    "mathtext.fontset": "custom", "mathtext.rm": "FreeSans", "mathtext.it": "FreeSans:italic",
    "mathtext.bf": "FreeSans:bold", "mathtext.sf": "FreeSans", "mathtext.fallback": "stixsans",
    "axes.labelsize": 7.2, "axes.titlesize": 7.2, "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7.2,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.minor.width": 0.45,
    "ytick.minor.width": 0.45, "xtick.major.size": 2.6, "ytick.major.size": 2.6, "xtick.minor.size": 1.5,
    "ytick.minor.size": 1.5, "xtick.major.pad": 2.0, "ytick.major.pad": 2.0, "axes.labelpad": 2.0,
    "lines.linewidth": 1.0, "lines.markersize": 3.5, "legend.frameon": False, "legend.handlelength": 1.6,
    "legend.borderaxespad": 0.3, "legend.labelspacing": 0.3, "legend.handletextpad": 0.5,
    "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.dpi": 600, "figure.dpi": 150,
})


def plain_log(ax, which="x", ticks=(1, 10, 100, 1000)):
    """log axis labelled with plain numbers (no superscripts, so no text below 5 pt)"""
    from matplotlib.ticker import FixedLocator, FixedFormatter, NullFormatter
    a = ax.xaxis if which == "x" else ax.yaxis
    a.set_major_locator(FixedLocator(ticks)); a.set_major_formatter(FixedFormatter([f"{t:g}" for t in ticks]))
    a.set_minor_formatter(NullFormatter())


def pow_ticks(ax, which="y", size=7.5):
    """powers-of-ten tick labels: enlarge them so that the 70 % superscripts stay above 5 pt"""
    ax.tick_params(axis=which, which="both", labelsize=size)


def letter(ax, s, title=None, x=-0.02, y=1.02, fig=None):
    """bold panel letter (8 pt) with an optional short title (7 pt) at the top left of an axes"""
    t = ax.text(x, y, s, transform=ax.transAxes, fontsize=8, fontweight="bold", va="bottom", ha="left")
    if title:
        ax.annotate(title, xy=(1, 0), xycoords=t, xytext=(3.5, 0), textcoords="offset points", fontsize=7.2, va="bottom", ha="left")


def min_font_report(pdf, width_mm=183.0):
    """smallest text size in a PDF after scaling it to the given width"""
    import pymupdf
    d = pymupdf.open(pdf); pg = d[0]; s = width_mm / 25.4 * 72 / pg.rect.width
    sizes = [sp["size"] * s for b in pg.get_text("dict")["blocks"] if b["type"] == 0 for l in b["lines"] for sp in l["spans"] if sp["text"].strip()]
    return (min(sizes) if sizes else None), pg.rect.width / 72 * 25.4, pg.rect.height / 72 * 25.4
