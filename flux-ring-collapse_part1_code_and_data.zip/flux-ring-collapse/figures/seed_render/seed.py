"""The seed of the runs (openai_mhd_3d.spheromak_seed): P = Psi/r^2 = C((s - s_c)/(1 - s_c)) 3 j1(k s)/(2 k s), B_phi = -lam Psi/r."""
import numpy as np
LAM = 4.4934094579090641753; S_C = 0.7
def taper(x):
    x = np.asarray(x, dtype=float); out = np.where(x <= 0.0, 1.0, 0.0); m = (x > 0.0) & (x < 1.0); xm = x[m]
    with np.errstate(over="ignore"): out[m] = 1.0 / (1.0 + np.exp(-1.0 / xm + 1.0 / (1.0 - xm)))
    return out
def P_of(r, z):
    s = np.hypot(r, z) + 1e-12; x = LAM * s
    j1 = np.sin(x) / x**2 - np.cos(x) / x
    return taper((s - S_C) / (1.0 - S_C)) * 3.0 * j1 / (2.0 * LAM * s)
def fields(r, z, h=1e-5):
    P = P_of(r, z); Pr = (P_of(r + h, z) - P_of(r - h, z)) / (2 * h); Pz = (P_of(r, z + h) - P_of(r, z - h)) / (2 * h)
    return r**2 * P, -r * Pz, 2 * P + r * Pr, -LAM * r * P        # Psi, Br, Bz, Bphi
