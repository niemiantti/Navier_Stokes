import json, glob, os, csv, numpy as np
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
R = B + "/figures/data/results/"
rows = []
for d in sorted(glob.glob(R + "*/")):
    if "LRref" in d: continue
    s = json.load(open(d + "data/summary.json")); p = json.load(open(d + "data/params.json"))
    sp = s.get("split") or {}
    rows.append(dict(name=os.path.basename(d[:-1]), eps=p["eps_b"], eta=p["eta"], ts=sp.get("t_s"), ratio=sp.get("island_ratio"),
                     typ=sp.get("type"), H1=s.get("helicity_kept_to_release"), H41=s.get("helicity_kept_after_release"),
                     KM=s.get("kinetic_over_magnetic_after_release"), S=s.get("lundquist_at_release"), tend=p.get("t_end"), tstart=p.get("t_start"),
                     parent=p.get("parent_run"), nr=p.get("nr"), nz=p.get("nz")))
rows.sort(key=lambda r: (-r["eta"], r["eps"]))
for r in rows:
    print(f"{r['name'][:40]:40s} eps={r['eps']:>6g} eta={r['eta']:<5g} t={r['tstart']}-{r['tend']} ts={r['ts'] if r['ts'] is None else round(r['ts'],4)} ratio={r['ratio'] if r['ratio'] is None else round(r['ratio'],3)} "
          f"H1/H0={r['H1']:.4f} H4/H1={r['H41'] if r['H41'] is None else round(r['H41'],4)} K/M={r['KM']:.4g} S={r['S']:.4g} type={r['typ']} parent={r['parent']} grid={r['nr']}x{r['nz']}")
json.dump(rows, open(B + "/analysis/verify/summary_table.json", "w"), indent=1)
