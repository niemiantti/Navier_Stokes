"""Free-exponent fits of the growth laws after the births (Supplementary Table 7): depth D and separation Sp of the new island
fitted as C (t - t_b)^p with t_b, p and C free (nonlinear least squares in log space over the first 0.05 after the
birth), compared with the two-step method of the paper (t_b from the squared separation, then the log-log slopes)."""
import sys, os, json, numpy as np
from paths import *
from silib import *
from scipy.optimize import least_squares
T_ = json.load(open(HERE + "/tables.json"))          # written by tables.py
runs = {(r["eps"], r["eta"]): r for r in T_["runs"]}
def freefit(T, D, tb0, XMAX=0.05):
    """fit log D = log C + p log(t - tb) with tb free; returns tb, p and the rms residual"""
    def res(q):
        tb, p, lc = q; x = T - tb
        if np.any(x <= 0): return 1e3 * np.ones_like(T)
        return lc + p * np.log(x) - np.log(D)
    m = (T > tb0) & (T - tb0 < XMAX); T, D = T[m], D[m]
    best = None
    for tb_try in np.linspace(tb0 - 0.01, T[0] - 1e-5, 25):
        r = least_squares(res, [tb_try, 1.5, 0.0], method="lm") if True else None
        if best is None or r.cost < best.cost: best = r
    return best.x[0], best.x[1], np.sqrt(2 * best.cost / len(T)), len(T)
rows = []
for b in T_["births"]:
    eps, eta = b["eps"], b["eta"]; r = runs[(eps, eta)]; ts, zb = r["t_s"], r["z_birth"]
    tr = [q for q in tracks_of(eps, eta) if ts - 0.05 <= q["t"] <= min(ts + 0.2, 1.0)]
    T, D, Sp = island(tr, (zb - 0.45, zb + 0.45)); resd = Sp >= 3 * DZ; T, D, Sp = T[resd], D[resd], Sp[resd]
    tbD, pD, rD, n = freefit(T, D, b["t_b"]); tbS, pS, rS, _ = freefit(T, Sp, b["t_b"])
    rows.append(dict(eps=eps, eta=eta, t_s=ts, t_b_paper=b["t_b"], pD_paper=b["slope_depth"], pS_paper=b["slope_sep"],
                     t_b_free_D=tbD, pD_free=pD, t_b_free_S=tbS, pS_free=pS, n=n))
    print(f"{eps:>5g} {eta:<5g} t_s={ts:.4f} | paper: t_b={b['t_b']:.4f} pD={b['slope_depth']:.2f} pS={b['slope_sep']:.2f} | free: depth t_b={tbD:.4f} p={pD:.2f}  sep t_b={tbS:.4f} p={pS:.2f}  n={n}")
json.dump(rows, open(HERE + "/freefit.json", "w"), indent=1)
