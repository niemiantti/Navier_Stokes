"""Persistence simplification of the ridge's critical points: repeatedly remove the shallowest island (axis plus the
higher of its adjacent saddles) until every island is deeper than thr (relative to the ridge maximum)."""
import json, glob, bisect
import os
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures", "data", "results") + "/"

def load(pat):
    d = glob.glob(R + pat)[0]; return json.load(open(d + "/data/tracks.json"))

def simplify(cps, thr):
    c = sorted([dict(x) for x in cps], key=lambda x: x["z"])
    # merge consecutive same-kind points (keep the more extreme)
    out = []
    top0 = max(x["psi"] for x in c)
    for x in c:
        if out and out[-1]["kind"] == x["kind"]:
            if x["kind"] == "O":       # the saddle between them lies below the tracking window (a quarter of the maximum)
                out.append(dict(kind="X", z=0.5 * (x["z"] + out[-1]["z"]), psi=0.25 * top0 - 1e-9, virtual=True)); out.append(x)
            elif x["psi"] < out[-1]["psi"]: out[-1] = x
        else: out.append(x)
    c = out
    while c and c[0]["kind"] == "X": c.pop(0)
    while c and c[-1]["kind"] == "X": c.pop()
    top = max(x["psi"] for x in c)
    while True:
        best = None
        for i, x in enumerate(c):
            if x["kind"] != "O" or x["psi"] == top: continue
            nb = [j for j in (i - 1, i + 1) if 0 <= j < len(c)]
            j = max(nb, key=lambda j: c[j]["psi"])         # the saddle it merges through
            d = x["psi"] - c[j]["psi"]
            if best is None or d < best[0]: best = (d, i, j)
        if best is None or best[0] >= thr * abs(top): break
        _, i, j = best
        for k in sorted((i, j), reverse=True): del c[k]
    return c, top

def depths(c, top):
    res = []
    for i, x in enumerate(c):
        if x["kind"] != "O": continue
        nb = [j for j in (i - 1, i + 1) if 0 <= j < len(c)]
        if x["psi"] == top or not nb: res.append((x["z"], None, None)); continue
        j = max(nb, key=lambda j: c[j]["psi"])
        res.append((x["z"], (x["psi"] - c[j]["psi"]) / abs(top), abs(x["z"] - c[j]["z"])))
    return res

def show(tr, t0, t1, thr=1e-3, every=1, zmax=3.0):
    ts = [q["t"] for q in tr]; i0 = bisect.bisect_left(ts, t0); i1 = bisect.bisect_right(ts, t1)
    for q in tr[i0:i1:every]:
        c, top = simplify([x for x in q["cps"] if abs(x["z"]) < zmax], thr)
        s = "  ".join(f"O{z:+.3f}" + ("[top]" if d is None else f"[{d:.4f},{sep:.3f}]") for z, d, sep in depths(c, top))
        xs = " ".join(f"X{x['z']:+.3f}" for x in c if x["kind"] == "X")
        print(f"  t={q['t']:.4f}  {s}   | {xs}")
