"""Locations inside the repository, shared by the scripts of the Supplementary Information."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))                 # figures/supplementary
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))           # the repository
CODE = os.path.join(ROOT, "axisymmetric")                         # the production solver (imported, not copied)
DATA = os.path.join(ROOT, "data")                                 # the data behind the figures and tables
RES = DATA + "/results/"                                          # <run>/data/{diag.csv, tracks.json, rings.csv, ...}
RAW = DATA + "/raw/"                                              # <run>/light_t*.npz (snapshots)
OUT = os.path.join(ROOT, "figures", "out")                        # where the figures are written
for p in (HERE, CODE, os.path.join(ROOT, "analysis"), os.path.join(ROOT, "figures")):
    if p not in sys.path: sys.path.insert(0, p)
os.makedirs(OUT, exist_ok=True)
