# Scripts of the Supplementary Information

All scripts run from this directory. `paths.py` locates the repository, the production solver (`../../axisymmetric`,
imported where a script needs it), the data (`../../data`) and the output directory (`../out`). `silib.py` and
`sifigs.py` are the shared helpers (run lookup, the resolved-pair filter, ridge critical points, drawing).

## Supplementary figures

| figure | script | input |
|---|---|---|
| Supplementary Fig. 1, 2 (snapshots of all runs) | `si_galleries.py [snapshot root]` | the snapshots `light_t*.npz` of the runs at t = 1, 1.5, 2, 3, 4, written by the runs under `results/<run>/data/`; not stored, see the top-level README |
| Supplementary Fig. 3 (revolved flux surfaces) | `si_fig3_revolved.py [snapshot root]` | the same snapshots of four runs; the rings are found with `persistence_rings` of the driver |
| Supplementary Fig. 4 (source of the asymmetry) | `si_fig4_asymmetry.py` | `data/results` (reference run), `data/controls/symmetry/` (tracks of the controls, `ridge_profiles_t0.40_0.45.csv`, `asym_*.json`) |
| Supplementary Fig. 5 (closure of the budgets) | `si_fig5_budget.py` | `data/budgets/budget_*.csv` |
| Supplementary Fig. 6 (direct fits of the ridge) | `si_fig6_fit.py` | `data/controls/cusp_dense/cusp_ridges.npz` |

## Supplementary tables

| table | numbers from | script |
|---|---|---|
| Table 1 (parameters common to all runs) | `runs/axisymmetric/*/params.json` | – |
| Table 2 (results of the eighteen runs) | `tables.json` → `runs` (`t_s`, `ratio`, `index_intervals` for t_2, `S`, `H1_H0`, `KM`, `H4_H1`, `M4_M1`, `rings`, `regime`) | `tables.py` |
| Table 3 (symmetry controls) | `ctrl_compare.json` | `ctrl_compare.py` |
| Table 4 (lattice dependence), upper block | `refinement.json` | `refinement.py` (from the tracks of the production run and of the 512 x 1365 repeat in `data/controls/refinement/`) |
| Table 4, lower block | the author's 512 x 1365 repeat of the eps_B = 100, eta = 0.01 run (not stored) | – |
| Table 5 (frozen imposed flow against tau_f) | `tauf_scan.json` | `tauf_scan.py` |
| Table 6 (cusp test and its sensitivity) | `tables.json` → `cusp` | `tables.py` |
| Table 7 (birth times and exponents) | `tables.json` → `births` (two-step fits), `freefit.json` (free fits) | `tables.py`, then `freefit.py` |

`tables.py` writes `tables.json` (the archived copy is `data/derived/si_tables.json`, identical); `freefit.py`,
`ctrl_compare.py`, `refinement.py`, `tauf_scan.py`, `jump.py` and `curves.py` write the JSON files of the same names
next to them (archived copies in `data/derived/` and `data/controls/`). Order: `tables.py` before `freefit.py`.

## The numbers of Supplementary Notes 4 and 5

- `jump.py`: the acceleration jump at the release, its norm, maximum, time scale and its inertial and viscous parts;
  the norm of d_t U before the release (`jump.json`).
- `curves.py`: energies, peak speed and acceleration norm of the imposed flow against time (`curves.json`).
- `budget.py <eps_b> <eta> <t0> <t1> <every> <label>`: re-integrates a production configuration with the production
  code and writes the time-integrated energy and helicity budgets with their residuals (`budget_<label>.csv`; the
  three archived runs are in `data/budgets/`). From t0 = 0 it starts from the seed; from a later t0 it needs the
  snapshot `light_t<t0>.npz` of the run under `data/raw/<run>/`. The runs of the paper took hours each.
- `restart.py <sudden|ramp> <t_ramp> <t_end> <label> [snapshot dir]`: the release-protocol test, restarting the
  eps_B = 1000, eta = 0.05 run from its full snapshot at t = 0.9 with the sudden release or the smooth switch-off
  over `t_ramp`. The snapshot `full_t0.900000000.npz` is written by that run. `compare.py` compares the test runs
  with the original (`compare.json`, archived in `data/controls/release/`), and `lightdiag.py RUN_DIR OUT.json`
  extracts energies, helicity and the ridge critical points from the light snapshots of a run (used for the
  continuation of the switch-off run from t = 2.55 on, `data/controls/release/light_to4.json`).
- `asym.py RUN_DIR OUT.json`: the up–down asymmetry diagnostics of Supplementary Fig. 4c from the light snapshots
  of a run (`data/controls/symmetry/asym_*.json`).
