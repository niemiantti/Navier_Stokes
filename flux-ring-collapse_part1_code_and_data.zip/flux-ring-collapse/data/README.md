# The data behind the figures and tables

Units throughout: the seed radius is the unit of length, the collapse time the unit of time, and the seed has unit
peak field. Energies carry the units of the paper (the magnetic energy includes the factor eps_B/2). Every file here
is written by the code of this repository from the run configurations in `../runs/`; this directory stores the reduced
outputs the figures and tables need and leaves out the snapshots of the fields, which the runs regenerate.

## Layout

| directory | contents |
|---|---|
| `results/<run>/data/` | the eighteen production runs (nineteen directories, the eps_B = 1000, eta = 0.05 run being in two parts, see `../runs/README.md`): `diag.csv`, `tracks.json`, `rings.csv`, `bphi.csv`, `summary.json`, `params.json`, in the layout the driver writes |
| `raw/<run>/` | the one axisymmetric snapshot a figure reads (Fig. 5c, eps_B = 50, eta = 0.01 at t = 2) |
| `three_dimensional/<run>/` | the three-dimensional runs: `config.json`, `diag.csv` (eps_B = 50 and its extension), the azimuthal average at t = 2 of the eps_B = 50 run (Fig. 5c), and for the eps_B = 1000 run `e1000_3d.csv` (its diagnostics every 0.2) and `e1000_series.json` (the series read by the Fig. 5 script) |
| `renders/` | the two renders of Fig. 5a,b (`e50_final.png`, `e1000_final.png`) with the options that produced them |
| `controls/symmetry/` | the three symmetry controls of Supplementary Note 2 (`diag.csv`, `tracks.json`, `config.json` of each), the asymmetry series `asym_*.json` (Supplementary Fig. 4c), the ridge profiles of the two controls at t = 0.40 and 0.45 (Supplementary Fig. 4b) and `ctrl_compare.json` (Supplementary Table 3) |
| `controls/refinement/` | the 512 x 1365 repeat of the fold at eps_B = 50, eta = 0.05 to t = 0.5 (`diag.csv`, `tracks.json`, `status.json` with the code hash) and the comparison files `fine_compare.json`, `ctrl_fine_check.json` (Supplementary Table 4, upper block) |
| `controls/release/` | the release-protocol tests of Supplementary Note 5: the restart at t = 0.9 with the sudden release and the smooth switch-off over 0.05 (each `diag.csv`, `tracks.json`, `config.json`, `restart_origin.json`), `compare.json` (energies and pair events against the original run) and `light_to4.json` (energies, helicity and ridge critical points of the switch-off run from t = 2.55 to 3.25, from its snapshots) |
| `controls/regularization/` | the frozen imposed flow against tau_f (`tauf_scan.json`, Supplementary Table 5), the acceleration jump at the release (`jump.json`), the energies of the imposed flow against time (`curves.json`) and the imposed-flow energies for the column and cone cutoffs (`flow.json`), Supplementary Note 4 |
| `controls/cusp_dense/` | `cusp_ridges.npz`, the ridge profiles of the two reruns with snapshots every 0.005 (Supplementary Fig. 6 and the direct fits of the Methods) |
| `budgets/` | the three re-integrations of the energy and helicity budgets (`budget_*.csv`, Supplementary Fig. 5 and Note 5) |
| `derived/` | `si_tables.json` (the numbers of Supplementary Tables 2, 6 and 7 as computed from the files above), `freefit.json` (the free fits of Table 7), `fig1cd_fig4_points.csv` and `fig3d_points.csv` (the plotted points of Figs. 1c,d, 3d and 4), `fig3_ridge_profiles_t0.9.csv` (the ten ridge profiles of Fig. 3b,c) |

## Which files are behind which figure and table

| item | files |
|---|---|
| Fig. 1a | the seed, drawn from the parameters by `figures/seed_render/` |
| Fig. 1b | the imposed flow at t = 0.75, computed from the kernel by `fig1_setup.py` |
| Fig. 1c, d; Fig. 4a, c, d | `results/*/data/summary.json` (also `derived/fig1cd_fig4_points.csv`) |
| Fig. 2 | `results/*/data/tracks.json` of eps_B = 1 and 50 at eta = 0.05, the eps_B = 1000, eta = 0.05 run (`..._d87ab6fa32e4`) and eps_B = 50 at eta = 0.01; panel d also `rings.csv` of the last |
| Fig. 3a | the normal form, no data |
| Fig. 3b, c | `derived/fig3_ridge_profiles_t0.9.csv` (column `source`: `snapshot`, the ridge of the stored snapshot on the full lattice, for six of the ten runs; `as plotted` for eps_B = 100, 200, 300 at eta = 0.01 and 200 at eta = 0.05, whose snapshots at t = 0.9 are held by the author) |
| Fig. 3d | `results/*/data/tracks.json` (also `derived/fig3d_points.csv`) |
| Fig. 4b | `results/*/data/rings.csv` |
| Fig. 5a, b | `renders/` (from the full 3D snapshots at t = 2 and 3, which the 3D runs write) |
| Fig. 5c | `raw/LR_e50_eta0.01_*/light_t2.000000000.npz` and `three_dimensional/e50_eta0.01_*/avg2d_t2.000.npz` |
| Fig. 5d–f | `three_dimensional/*/diag.csv`, `three_dimensional/e1000_*/e1000_series.json`, `results/` of the two axisymmetric counterparts |
| Methods, release and budgets | `results/*/data/diag.csv` (`Pext`, `dissipation`, `KU`), `controls/regularization/`, `budgets/` |
| Methods, convergence | `controls/refinement/`, `results/LR_e50_eta0.05_*/`, `results/LR_e100_eta0.01_*/` |
| Supplementary Table 1 | `../runs/axisymmetric/*/params.json` |
| Supplementary Table 2 | `derived/si_tables.json` → `runs` (from `results/`) |
| Supplementary Table 3, Fig. 4 | `controls/symmetry/` |
| Supplementary Table 4 | `controls/refinement/` (upper block); the lower block is the author's run, see `../runs/README.md` |
| Supplementary Table 5 | `controls/regularization/tauf_scan.json` |
| Supplementary Tables 6, 7 | `derived/si_tables.json` → `cusp`, `births`; `derived/freefit.json` |
| Supplementary Figs. 1–3 | the snapshots of the runs (regenerated by the runs, not stored) |
| Supplementary Fig. 5, Note 5 | `budgets/`, `controls/release/` |
| Supplementary Fig. 6 | `controls/cusp_dense/cusp_ridges.npz` |
| Supplementary Note 7 | `three_dimensional/e50_eta0.01_*/diag.csv` and `three_dimensional/ext_e50_*/diag.csv` |

## File formats

**`diag.csv`** (axisymmetric runs) — one row per diagnostic record (every twenty time steps): `t`, `tau` = 1 - t;
`phase` (0 during the collapse, -1 for the record at t = 1 just before the release, 1 after it); `H`, the helicity
4 pi int Psi B_phi dr dz; `M`, the magnetic energy; `K`, the kinetic energy of the response v; `Ktot`, of the total
velocity u = U + v; `KU`, `Kpol_U`, `Kswirl_U`, the kinetic energy of the imposed flow and its poloidal and swirl
parts (zero after the release); `Pext`, the power of the sustaining force on the total velocity; `dKU_dt`;
`dissipation`, the viscous dissipation of the imposed flow; `pure_power_balance_residual`, the discrete power balance
of the imposed flow alone; `Bmax`, `Jmax`, `vmax`, `Umax`, `Vmax_total`, `Psi_max`, peak values; `J2_integral`,
`ohmic_dissipation`; `ell_B_rms`, `ell_B_rms_cells`, the rms field scale sqrt(int |B|^2 / int |J|^2) and the same in
cells.

**`tracks.json`** — a list of records, one every two time steps: `t`, `tau`, `Psi_max`, `z_O` (height of the main
maximum of the ridge), `nO`, `nX` (numbers of O and X points found on the ridge above 25 % of `Psi_max`), `dmax`
(depth of the deepest island in units of the peak flux), `z_dmax`, `sep` (axis–saddle separation of that island) and
`cps`, the critical points, each with `kind` (`O` or `X`), `z` (height, interpolated to sub-cell precision), `r`
(radius of the ridge there) and `psi` (ridge value divided by `Psi_max`). The resolved pairs of the paper are the
islands deeper than 1e-3 and wider than three cells (`silib.resolve`).

**`rings.csv`** — every 0.1 time units: `t`, `separate_rings` (secondary flux maxima deeper than 5 % of `Psi_max`,
the main ring not counted), `deepest_secondary` and `rings(depth@r,z)`, a `;`-separated list of every secondary
maximum found by the union-find sweep over the levels of Psi. The ring counts of Fig. 4b are 1 + `separate_rings`.

**`bphi.csv`** — every 0.1 time units: `t`, `reversal_fraction` (fraction of |B_phi| with the sign opposite to the
seed's twist), `toroidal_flux_above`, `toroidal_flux_below`, `Bphi_max`, `Bphi_min`.

**`summary.json`** — the run's headline numbers: `split` (`t_s`, the first-detection split time; `z_birth`;
`type`; `island_ratio`, the island-depth ratio when the new island first exceeds 1e-3 Psi_max), the helicity and
energy fractions, `kinetic_over_magnetic_after_release` (K(1.05)/M(0.99)), `lundquist_at_release`,
`rings_after_release`, `regime_after_release`, the reversal of B_phi, and `config_sha256`. The birth times and
exponents of Fig. 2e–g come from the fits described in the Methods, not from `split`.

**Snapshots** (`raw/<run>/light_t<t>.npz`; the runs write them every 0.05) — NumPy archives on the cell-centred
lattice, arrays of shape (384, 1024): `r`, `z`, `t`, `Psi`, `Bphi`, `Jphi`, `chi` (the Stokes stream function of the
total meridional velocity, r^2 (S_U + S)) and `Omega` (total angular velocity), float32, with `config_sha256` and
`code_sha256`. Full snapshots (`full_t<t>.npz`) add the field, current and velocity components.

**Control runs** — the same `diag.csv` and `tracks.json` as the production runs; `config.json` holds the parameters
under `parameters` with the code and configuration hashes; `restart_origin.json` names the snapshot a release test
started from. `asym_*.json`: per snapshot `t`, `Eodd_over_Eeven` (energy of the odd part of B_phi relative to the
even part), `Kanti_over_Ksym`, `vz_anti_axis` (antisymmetric axial velocity at the magnetic axis), the position of
the axis and the quartic coefficients of the ridge top. `compare.json`: for each release test a table of K, M, H
against the original run and the pair events (t, n_O, n_X, points) after t = 0.9. `light_to4.json`: per snapshot
`t`, `K`, `M`, `H` and the ridge critical points `cps`. `tauf_scan.json`: per tau_f `Kpol`, `Kswirl`, `Umax`,
`strain`, `jump_norm`, `jump_max`, `T_jump`, `K_over_D`, `core_cells`. `jump.json`: `t1` (norms of U and of the jump,
its time scale, its poloidal, swirl, viscous and inertial parts) and `pre` (the norm of d_t U before the release).
`cusp_ridges.npz`: keys `cusp_e100_eta0.05/full_t<t>/{z, R, r_ridge, t}` and `cusp_e200_eta0.01/...`, with `R` the
ridge value divided by the peak flux.

**`budgets/budget_*.csv`** — per evaluation `t`, the energies `K`, `M`, `E` and the helicity `H`, the rates `Pext`
(power of the force), `WL` (power of the Lorentz force), `Dnu`, `Deta` (viscous and resistive dissipation), `JB`
(int J.B), `pure` (the discrete power balance of the imposed flow), `KU`, `dKU`, `DnuU`, `phase`, their time integrals
`IK`, `IM`, `IE`, `IH`, `Ipure`, `IDnu`, `IDeta`, and the residuals `RK`, `RM`, `RE`, `RH` (stored quantity minus the
integral of its rates).

**Three-dimensional runs** — `diag.csv`: `t`, `K_total`, `K_response`, `M`, `H`, `Bmax`, `umax`, `m1` … `m4`
(fraction of the magnetic energy in the azimuthal modes), `nonaxi` (all m >= 1), `dt`; the fractions are measured
inside r < 2 and |z| < 0.8 L_z. `avg2d_t<t>.npz`: the azimuthal average on an (r, z) lattice of 192 x 512 cells
(`Psi`, `Bphi`, `Br`, `Bz`, `Vr`, `Vphi`, `Vz`, `PsiV`). `e1000_3d.csv`: `t`, `M`, `H`, `nonaxi`, `m1`, `m2` every
0.2; `e1000_series.json`: the same quantities as `{t, v}` series.

**`derived/`** — `fig3_ridge_profiles_t0.9.csv`: `eta`, `eps_B`, `z`, `ridge_over_Psi_max`, `source`;
`ridge_profiles_t0.40_0.45.csv` (in `controls/symmetry/`): `control`, `t`, `z`, `ridge_over_Psi_max`;
`fig1cd_fig4_points.csv` and `fig3d_points.csv`: one row per run or split with the plotted values.
