import json, glob, numpy as np, os
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
R = B + "/figures/data/results/"
tot_bad = 0
for d in sorted(glob.glob(R + "*/")):
    if "LRref" in d or "d5fc" in d: continue
    tr = json.load(open(d + "data/tracks.json")); p = json.load(open(d + "data/params.json"))
    bad = [q for q in tr if q["nO"] - q["nX"] != 1]
    tot_bad += len(bad) > 0
    if bad: print(f"eta={p['eta']:<5g} eps={p['eps_b']:>5g}: {len(bad)}/{len(tr)} records with nO-nX != 1 (values {sorted(set(q['nO']-q['nX'] for q in bad))}), first at t={bad[0]['t']:.3f}")
print("runs with nO-nX != 1 somewhere:", tot_bad)
