"""All numbers of the Supplementary Information from the run data -> tables.json (+ a readable printout)."""
import json, numpy as np, csv
from silib import *

OUT = {}
# ------------------------------------------------------------------ 1. the eighteen runs
REG = {(1, 0.05): "passive doublet", (3, 0.05): "passive doublet", (10, 0.05): "passive doublet",
       (20, 0.05): "doublet, internal rolls", (50, 0.05): "doublet, internal rolls", (100, 0.05): "doublet, internal rolls",
       (200, 0.05): "doublet, internal rolls", (300, 0.05): "doublet, internal rolls", (500, 0.05): "doublet, central ring forming",
       (1000, 0.05): "triplet", (1, 0.01): "passive doublet", (10, 0.01): "doublet, island chain", (50, 0.01): "doublet, island chain",
       (100, 0.01): "doublet, island chain", (200, 0.01): "doublet, island chain", (300, 0.01): "doublet, island chain",
       (500, 0.01): "asymmetric, two to three rings", (1000, 0.01): "single ring"}
runs = []
for eps, eta in SCAN:
    s = summary_of(eps, eta, "before"); sa = summary_of(eps, eta, "after"); p = params_of(eps, eta)
    sp = s.get("split") or {}
    d = diag_of(eps, eta, "after"); db = diag_of(eps, eta, "before")
    # energies and helicity at t = 0, 1 (before the release) and 4
    def at(dd, t, key, phase=None):
        m = np.abs(dd["t"] - t) < 1e-6
        if phase is not None: m &= dd["phase"] == phase
        i = np.where(m)[0]
        if len(i) == 0: i = [np.argmin(np.abs(dd["t"] - t))]
        return float(dd[key][i[0]])
    H0 = at(db, 0.0, "H"); M0 = at(db, 0.0, "M")
    H1 = at(db, 1.0, "H", -1) if (db["phase"] == -1).any() else at(db, 1.0, "H"); M1 = at(db, 1.0, "M", -1) if (db["phase"] == -1).any() else at(db, 1.0, "M")
    H4 = at(d, 4.0, "H"); M4 = at(d, 4.0, "M"); K4 = at(d, 4.0, "K")
    KU1 = at(db, 1.0, "KU", -1) if (db["phase"] == -1).any() else at(db, 1.0, "KU")
    Umax1 = at(db, 1.0, "Umax", -1) if (db["phase"] == -1).any() else at(db, 1.0, "Umax")
    Bmax1 = at(db, 1.0, "Bmax", -1) if (db["phase"] == -1).any() else at(db, 1.0, "Bmax")
    rg = rings_of(eps, eta)
    ring_hist = {round(t, 1): n + 1 for t, n, _, _ in rg}
    if (eps, eta) == (1000, 0.05):                       # the collapse part of the run holds the early ring records
        for ln in open(run_dir(eps, eta, "before") + "data/rings.csv").read().splitlines()[1:]:
            q = ln.split(","); ring_hist.setdefault(round(float(q[0]), 1), int(q[1]) + 1)
    hist = "".join(str(min(ring_hist.get(round(t, 1), 0), 9)) for t in np.arange(1.0, 4.01, 0.3))
    bp = bphi_of(eps, eta)
    if (eps, eta) == (1000, 0.05):
        rows = list(csv.DictReader(open(run_dir(eps, eta, "before") + "data/bphi.csv")))
        bpb = {k: np.array([float(r[k]) for r in rows]) for k in rows[0]}
        bp = {k: np.concatenate([bpb[k][bpb["t"] < bp["t"][0]], bp[k]]) for k in bp}
    rev_max_before = float(bp["reversal_fraction"][bp["t"] <= 1.0 + 1e-9].max()); rev_end = float(bp["reversal_fraction"][-1]); rev_max = float(bp["reversal_fraction"].max())
    tr = tracks_of(eps, eta)
    idx = np.array([q["nO"] - q["nX"] for q in tr]); tt = np.array([q["t"] for q in tr])
    bad = idx != 1
    ivals = []
    if bad.any():
        edges = np.where(np.diff(bad.astype(int)) != 0)[0] + 1; starts = [0] + list(edges); ends = list(edges) + [len(bad)]
        for a, b in zip(starts, ends):
            if bad[a]: ivals.append((float(tt[a]), float(tt[b - 1]), sorted(set(int(v) for v in idx[a:b]))))
    runs.append(dict(eps=eps, eta=eta, t_s=sp.get("t_s"), type=sp.get("type"), ratio=sp.get("island_ratio"), z_birth=sp.get("z_birth"),
                     S=sa.get("lundquist_at_release") or s.get("lundquist_at_release"), H0=H0, M0=M0, H1=H1, M1=M1, H4=H4, M4=M4, K4=K4,
                     H1_H0=s["helicity_kept_to_release"], KM=sa["kinetic_over_magnetic_after_release"], H4_H1=sa["helicity_kept_after_release"],
                     M4_M1=sa["magnetic_energy_kept_after_release"], rings=hist, regime=REG[(eps, eta)], rev_max_before=rev_max_before,
                     rev_end=rev_end, rev_max=rev_max, KU1=KU1, Umax1=Umax1, Bmax1=Bmax1, index_values=sorted(set(int(v) for v in idx)),
                     index_bad_records=int(bad.sum()), index_records=len(idx), index_intervals=ivals,
                     release=sa.get("release") or s.get("release")))
OUT["runs"] = runs
for r in runs:
    print(f"{r['eps']:>5g} {r['eta']:<5g} t_s={r['t_s'] if r['t_s'] is None else round(r['t_s'], 3)} ratio={None if r['ratio'] is None else round(r['ratio'], 2)} "
          f"S={r['S']:.0f} H1/H0={r['H1_H0']:.3f} K/M={r['KM']:.3g} H4/H1={r['H4_H1']:.3f} M4/M1={r['M4_M1']:.3f} rings={r['rings']} "
          f"rev={r['rev_max_before']:.3f}/{r['rev_end']:.3f} index={r['index_values']} bad={r['index_bad_records']}/{r['index_records']} {r['index_intervals'][:3]}")

# ------------------------------------------------------------------ 2. birth statistics of the single-island splits
births = []
for eps, eta in SCAN:
    r = next(x for x in runs if (x["eps"], x["eta"]) == (eps, eta))
    if r["t_s"] is None or (eps, eta) in RIPPLED: continue
    ts, zb = r["t_s"], r["z_birth"]
    tr = [q for q in tracks_of(eps, eta) if ts - 0.05 <= q["t"] <= min(ts + 0.2, 1.0)]
    T, D, Sp = island(tr, (zb - 0.45, zb + 0.45))
    tb, x, Dd, Ss, eD, eS, n = scaling(T, D, Sp)
    births.append(dict(eps=eps, eta=eta, t_s=ts, t_b=tb, slope_depth=eD, slope_sep=eS, n=n, ratio=r["ratio"]))
    print(f"birth {eps:>5g} {eta:<5g}: t_s={ts:.4f} t_b={tb:.4f} depth slope {eD:.2f} sep slope {eS:.2f} n={n} ratio {r['ratio']:.2f}")
OUT["births"] = births

# ------------------------------------------------------------------ 3. the cusp test and its sensitivity
cusp = []
for eps, eta in SCAN:
    r = next(x for x in runs if (x["eps"], x["eta"]) == (eps, eta))
    if r["t_s"] is None: continue
    ts = r["t_s"]; tr = tracks_of(eps, eta); row = dict(eps=eps, eta=eta, rippled=(eps, eta) in RIPPLED)
    for dmin in (2e-4, 5e-4, 1e-3):
        rows = Cf.tracks_beta(tr, t_window=(ts - 0.001, ts + 0.06), dmin=dmin)
        for k in (10, 15, 25):
            rr = rows[:k]
            if len(rr) < 5: row[f"d{dmin:g}_k{k}"] = None; continue
            b = np.median([q["beta"] for q in rr]); q_ = np.median([q["ratio"] for q in rr])
            row[f"d{dmin:g}_k{k}"] = dict(beta=float(b), ratio=float(q_), R=float(Cf.cusp_ratio(b)), n=len(rr), t0=rr[0]["t"], t1=rr[-1]["t"])
    cusp.append(row)
    base = row["d0.0005_k15"]
    print(f"cusp {eps:>5g} {eta:<5g} {'rippled' if row['rippled'] else 'single '} beta={base['beta']:.3f} ratio={base['ratio']:.3f} R={base['R']:.3f} dev={base['ratio'] - base['R']:+.3f} | "
          + " ".join(f"{key}:{(v['ratio'] - v['R']):+.2f}" for key, v in row.items() if key.startswith('d') and v))
OUT["cusp"] = cusp

# ------------------------------------------------------------------ 4. the events of the eps_B = 1000, eta = 0.05 run
tr = tracks_of(1000, 0.05)
prev = None; events = []
for q in tr:
    c = resolve(q["cps"]); sig = tuple((x["kind"], round(x["z"], 1)) for x in c)
    nO = sum(1 for x in c if x["kind"] == "O"); nX = len(c) - nO
    key = (nO, nX)
    if prev is not None and key != prev[0]:
        events.append(dict(t=q["t"], nO=nO, nX=nX, points=[(x["kind"], round(x["z"], 3), round(x["psi"], 3)) for x in c]))
    prev = (key, sig)
OUT["events_1000"] = events
for e in events: print(f"event t={e['t']:.4f} N_O={e['nO']} N_X={e['nX']} " + " ".join(f"{k}({z:+.2f},{p:.2f})" for k, z, p in e["points"]))

# ------------------------------------------------------------------ 5. three dimensions against axisymmetry
def rd(fn):
    rows = list(csv.DictReader(open(fn)))
    return {k: np.array([float(r[k]) if r[k] not in ("", None) else np.nan for r in rows]) for k in rows[0]}
D3 = rd(SCR + "/figures/data/three_dimensional/e50_eta0.01_nu0.1_N256_box4x4x5.5/diag.csv")
EXT = rd(SCR + "/figures/data/three_dimensional/ext_e50_eta0.01_nu0.1_N320x384_box5x5x8.25/diag.csv")
E3 = rd(SCR + "/figures/data/three_dimensional/e1000_eta0.05_nu0.1_N256_box5x5x7/e1000_3d.csv")
def val(dd, t, key):
    i = np.argmin(np.abs(dd["t"] - t)); return float(dd[key][i]), float(dd["t"][i])
three = {}
d2 = diag_of(50, 0.01)
three["50"] = dict(M1_2d=at(d2, 1.0, "M", -1), M1_3d=val(D3, 1.0, "M")[0], H1_2d=at(d2, 1.0, "H", -1), H1_3d=val(D3, 1.0, "H")[0],
                   M4_2d=at(d2, 4.0, "M"), M4_3d=val(D3, 4.0, "M")[0], H4_2d=at(d2, 4.0, "H"), H4_3d=val(D3, 4.0, "H")[0],
                   nonaxi_release=val(D3, 1.0, "nonaxi")[0], nonaxi_max=float(np.nanmax(D3["nonaxi"])), nonaxi_max_t=float(D3["t"][np.nanargmax(D3["nonaxi"])]),
                   m1_max=float(np.nanmax(D3["m1"])), m1_max_t=float(D3["t"][np.nanargmax(D3["m1"])]), m2_max=float(np.nanmax(D3["m2"])), m2_max_t=float(D3["t"][np.nanargmax(D3["m2"])]),
                   m4_max=float(np.nanmax(D3["m4"])), m4_max_t=float(D3["t"][np.nanargmax(D3["m4"])]), nonaxi_4=val(D3, 4.0, "nonaxi")[0], m1_4=val(D3, 4.0, "m1")[0], m2_4=val(D3, 4.0, "m2")[0],
                   nonaxi_0=float(D3["nonaxi"][0]), K4=val(D3, 4.0, "K_total")[0])
# helicity and magnetic-energy agreement over time
tt = np.arange(0.1, 4.01, 0.1)
def interp(dd, key, t): return np.interp(t, dd["t"], dd[key])
m2d = np.array([interp(d2, "M", t) if t > 1 else interp({"t": diag_of(50, 0.01, "before")["t"], "M": diag_of(50, 0.01, "before")["M"]}, "M", t) for t in tt])
m3d = interp(D3, "M", tt); h2d = interp(d2, "H", tt); h3d = interp(D3, "H", tt); H0 = float(d2["H"][0])
three["50"]["dM_rel_max_to3"] = float(np.nanmax(np.abs(m3d - m2d) / m2d * (tt <= 3.0)))
three["50"]["dM_rel_4"] = float((m3d[-1] - m2d[-1]) / m2d[-1]); three["50"]["dH_abs_max_over_H0"] = float(np.nanmax(np.abs(h3d - h2d)) / abs(H0))
# the extension to t = 8
three["ext"] = dict(K4=val(EXT, 4.0, "K_total")[0], K8=val(EXT, 8.0, "K_total")[0], M4=val(EXT, 4.0, "M")[0], M8=val(EXT, 8.0, "M")[0],
                    H4=val(EXT, 4.0, "H")[0], H8=val(EXT, 8.0, "H")[0], nonaxi4=val(EXT, 4.0, "nonaxi")[0], nonaxi8=val(EXT, 8.0, "nonaxi")[0],
                    m1_4=val(EXT, 4.0, "m1")[0], m1_8=val(EXT, 8.0, "m1")[0], m2_4=val(EXT, 4.0, "m2")[0], m2_8=val(EXT, 8.0, "m2")[0],
                    t0=float(EXT["t"][0]), t1=float(EXT["t"][-1]), K4_main=val(D3, 4.0, "K_total")[0], M4_main=val(D3, 4.0, "M")[0], H4_main=val(D3, 4.0, "H")[0])
for k in ("K", "M", "H"):
    a, b = three["ext"][k + "4"], three["ext"][k + "8"]; three["ext"]["tau_" + k] = float(4.0 / np.log(a / b))
d2b = diag_of(1000, 0.05, "before"); d2a = diag_of(1000, 0.05, "after")
three["1000"] = dict(M1_2d=at(d2b, 1.0, "M", -1), M1_3d=val(E3, 1.0, "M")[0], H1_2d=at(d2b, 1.0, "H", -1), H1_3d=val(E3, 1.0, "H")[0],
                     M4_2d=at(d2a, 4.0, "M"), M4_3d=val(E3, 4.0, "M")[0], H4_2d=at(d2a, 4.0, "H"), H4_3d=val(E3, 4.0, "H")[0],
                     nonaxi_release=val(E3, 1.0, "nonaxi")[0], nonaxi_max=float(np.nanmax(E3["nonaxi"])), nonaxi_max_t=float(E3["t"][np.nanargmax(E3["nonaxi"])]),
                     m1_max=float(np.nanmax(E3["m1"])), m1_max_t=float(E3["t"][np.nanargmax(E3["m1"])]), m2_max=float(np.nanmax(E3["m2"])), m2_max_t=float(E3["t"][np.nanargmax(E3["m2"])]),
                     nonaxi_4=val(E3, 4.0, "nonaxi")[0], m1_4=val(E3, 4.0, "m1")[0], m2_4=val(E3, 4.0, "m2")[0], nonaxi_0=float(E3["nonaxi"][0]))
m2d = np.array([interp(d2a, "M", t) if t > 1 else interp(d2b, "M", t) for t in E3["t"]]); h2d = np.array([interp(d2a, "H", t) if t > 1 else interp(d2b, "H", t) for t in E3["t"]])
three["1000"]["dM_rel_max"] = float(np.nanmax(np.abs(E3["M"] - m2d) / m2d)); three["1000"]["dH_abs_max_over_H0"] = float(np.nanmax(np.abs(E3["H"] - h2d)) / abs(d2b["H"][0]))
OUT["three"] = three
print(json.dumps(three, indent=1))
json.dump(OUT, open(HERE + "/tables.json", "w"), indent=1)
