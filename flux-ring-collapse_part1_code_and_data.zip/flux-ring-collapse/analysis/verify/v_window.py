import os, json, glob, sys, numpy as np
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
sys.path.insert(0, B + "/analysis"); import cuspfit as Cf
R = B + "/figures/data/results/"; dz = 16/1024
for d in sorted(glob.glob(R + "*/")):
    if "LRref" in d or "d87ab6" in d: continue
    s = json.load(open(d + "data/summary.json")); p = json.load(open(d + "data/params.json"))
    ts = (s.get("split") or {}).get("t_s")
    if ts is None: continue
    rows = Cf.tracks_beta(json.load(open(d + "data/tracks.json")), t_window=(ts - 0.001, ts + 0.06), dmin=5e-4)[:15]
    nres = 0
    for r in rows:
        # width of the triplet used: O-X separation on the shallow side
        nres += (r["depth"] >= 1e-3)
    print(f"eta={p['eta']:<5g} eps={p['eps_b']:>5g}: window records with depth>=1e-3: {nres}/15; depth range {min(r['depth'] for r in rows):.1e}-{max(r['depth'] for r in rows):.1e}")
# Fig 2b: eps=50 eta=0.01 ridge maxima at t=0.9 from tracks
tr = json.load(open(glob.glob(R + "LR_e50_eta0.01_*/data/tracks.json")[0]))
q = min(tr, key=lambda x: abs(x["t"] - 0.9)); print("eps=50 eta=0.01 t=%.4f ridge O psi:" % q["t"], [(round(c["z"], 2), round(c["psi"], 3)) for c in q["cps"] if c["kind"] == "O"], "X:", [(round(c["z"], 2), round(c["psi"], 3)) for c in q["cps"] if c["kind"] == "X"])
