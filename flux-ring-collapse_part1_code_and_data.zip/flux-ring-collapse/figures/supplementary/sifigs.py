"""Drawing helpers for the supplementary figures: flux-surface panels from snapshots, ridge critical points,
ridge profiles, critical points against time. Style of the main figures (figures/style.py)."""
import sys, os, numpy as np
from silib import *
sys.path.insert(0, SCR + "/figures")
from style import plt, MM, WIDTH, C_ETA, GOLD, letter, pow_ticks, plain_log
import matplotlib
from matplotlib.colors import TwoSlopeNorm

OUT = SCR + "/figures/out/"
os.makedirs(OUT, exist_ok=True)
GREY = "#868e96"; GREEN = "#2b8a3e"; BLUE = "#1971c2"; RED = "#c92a2a"
FLUX_LINE = dict(colors="#495057", linewidths=0.35)

def ridge_points(Psi, r, z, frac=0.25, dmin=1e-3, cells=3):
    """critical points of the flux ridge max_r Psi(r, z) from a snapshot, with the same filters as the tracks"""
    R = Psi.max(axis=0); ir = Psi.argmax(axis=0); Rm = R.max()
    keep = R >= frac * Rm
    cps = []
    for j in range(1, len(z) - 1):
        if not (keep[j - 1] and keep[j] and keep[j + 1]): continue
        if R[j] > R[j - 1] and R[j] >= R[j + 1]: cps.append(dict(kind="O", z=float(z[j]), psi=float(R[j] / Rm), r=float(r[ir[j]])))
        elif R[j] < R[j - 1] and R[j] <= R[j + 1]: cps.append(dict(kind="X", z=float(z[j]), psi=float(R[j] / Rm), r=float(r[ir[j]])))
    return resolve(cps, dmin=dmin, cells=cells), R / Rm

def flux_panel(ax, snap, rwin, zwin, nlev=18, bphi=False, flow=False, points=True, frac_min=0.03, lw=0.35, cmap_b="RdBu_r", zoom_pts=None, bsign=1):
    """mirrored meridional section: flux surfaces (thin), optional B_phi colour and total-flow streamlines, O (gold) and X (black)"""
    r, z, Psi = snap["r"], snap["z"], snap["Psi"]
    ir = r <= rwin * 1.02; jz = np.abs(z) <= zwin * 1.02
    rr, zz, P = r[ir], z[jz], Psi[np.ix_(ir, jz)]
    Pm = Psi.max(); X = np.concatenate([-rr[::-1], rr]); Z = zz
    PP = np.concatenate([P[::-1], P], axis=0)
    if bphi:
        B = snap["Bphi"][np.ix_(ir, jz)]; BB = np.concatenate([bsign * B[::-1], B], axis=0); vm = np.abs(B).max()   # bsign = -1: the mirrored half shows -B_phi
        ax.pcolormesh(X, Z, BB.T, cmap=cmap_b, norm=TwoSlopeNorm(0.0, -vm, vm), rasterized=True, shading="nearest")
    levels = Pm * np.linspace(frac_min, 1.0, nlev)
    ax.contour(X, Z, PP.T, levels=levels, colors="#495057", linewidths=lw)
    if flow and "Vr" in snap:
        Vr = snap["Vr"][np.ix_(ir, jz)]; Vz = snap["Vz"][np.ix_(ir, jz)]
        VR = np.concatenate([-Vr[::-1], Vr], axis=0); VZ = np.concatenate([Vz[::-1], Vz], axis=0)
        sp = np.hypot(VR, VZ); ax.streamplot(X, Z, VR.T, VZ.T, density=0.9, color=GREEN, linewidth=0.4, arrowsize=0.4, zorder=1)
    if points:
        cps, _ = ridge_points(Psi, r, z)
        for c in cps:
            if abs(c["z"]) > zwin or c["r"] > rwin: continue
            if c["kind"] == "O":
                ax.plot([-c["r"], c["r"]], [c["z"], c["z"]], "o", color=GOLD, ms=3.6, mec="k", mew=0.4, zorder=5)
            else:
                ax.plot([-c["r"], c["r"]], [c["z"], c["z"]], "x", color="k", ms=4.2, mew=0.9, zorder=5)
    ax.set_xlim(-rwin, rwin); ax.set_ylim(-zwin, zwin); ax.set_aspect("equal")
    ax.set_xlabel("$r$ (mirrored)")

def ridge_profile(snap, frac=0.0):
    r, z, Psi = snap["r"], snap["z"], snap["Psi"]
    R = Psi.max(axis=0) / Psi.max(); return z, R

def plot_world_lines(ax, tracks, tw, resolved=True, ms=1.8):
    TO, ZO, PO, TX, ZX, PX = world_lines(tracks, tw, resolved)
    ax.plot(TX, ZX, ".", color="k", ms=ms * 0.9, mew=0, rasterized=True)
    ax.plot(TO, ZO, ".", color=GOLD, ms=ms, mew=0, rasterized=True)
    ax.set_xlim(*tw); ax.set_xlabel("$t$")

def legend_ox(ax, loc="upper left"):
    h = [plt.Line2D([], [], color=GOLD, marker="o", ms=3.2, lw=0, label="magnetic axis (O)"), plt.Line2D([], [], color="k", marker="o", ms=3.2, lw=0, label="saddle (X)")]
    ax.legend(handles=h, loc=loc, handletextpad=0.2, borderaxespad=0.2)

def save(fig, name):
    fig.savefig(OUT + name + ".pdf"); fig.savefig(OUT + name + ".png", dpi=170)
    from style import min_font_report
    mf, w, h = min_font_report(OUT + name + ".pdf", width_mm=183.0)
    print(f"{name}: {w:.0f} x {h:.0f} mm, min font {mf:.2f} pt at 183 mm" if mf else f"{name}: {w:.0f} x {h:.0f} mm")
