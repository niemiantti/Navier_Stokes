import json, glob, os, csv, numpy as np
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
R = B + "/figures/data/results/"
def rd(fn):
    rows = list(csv.DictReader(open(fn)))
    return {k: np.array([float(r[k]) if r[k] not in ("", None) else np.nan for r in rows]) for k in rows[0]}
def at(D, key, t):
    i = np.argmin(np.abs(D["t"] - t)); return D[key][i], D["t"][i]
out = []
for d in sorted(glob.glob(R + "*/")):
    if "LRref" in d or "d5fc33" in d: continue
    s = json.load(open(d + "data/summary.json")); p = json.load(open(d + "data/params.json"))
    D = rd(d + "data/diag.csv")
    # values just before / after release: rows with t == 1 (there may be two)
    i1 = np.where(np.abs(D["t"] - 1.0) < 1e-9)[0]
    H0 = D["H"][0]; H1, t1 = at(D, "H", 1.0); H4, t4 = at(D, "H", 4.0)
    M1 = D["M"][i1]; K1 = D["Ktot"][i1]; Bm1 = D["Bmax"][i1]
    S = np.sqrt(p["eps_b"]) * Bm1 / p["eta"]
    out.append((p["eta"], p["eps_b"], H1 / H0, H4 / H1, t4, K1 / M1, S, len(i1), s["helicity_kept_to_release"], s["helicity_kept_after_release"], s["kinetic_over_magnetic_after_release"], s["lundquist_at_release"], D["t"][-1]))
out.sort(key=lambda r: (-r[0], r[1]))
for r in out:
    print(f"eta={r[0]:<5g} eps={r[1]:>6g} H1/H0={r[2]:.4f} (summ {r[8]:.4f})  H4/H1={r[3]:.4f} @t={r[4]:.3f} (summ {r[9]:.4f})  K/M(t=1 rows)={np.round(r[5],4)} (summ {r[10]:.4g})  S={np.round(r[6],2)} (summ {r[11]:.4g})  n_t1rows={r[7]} tlast={r[12]:.3f}")
for eta in (0.05, 0.01):
    q = [r for r in out if r[0] == eta]
    print(eta, "H1/H0 range %.4f-%.4f" % (min(r[2] for r in q), max(r[2] for r in q)), "H4/H1 range %.4f-%.4f" % (min(r[3] for r in q), max(r[3] for r in q)))
print("S range", min(np.min(r[6]) for r in out), max(np.max(r[6]) for r in out))
print("K/M range", min(np.min(r[5]) for r in out), max(np.max(r[5]) for r in out))
