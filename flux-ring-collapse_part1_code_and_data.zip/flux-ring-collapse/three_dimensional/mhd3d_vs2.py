#!/usr/bin/env python3
"""
mhd3d_vs2.py - three-dimensional version of the hopfion-in-a-collapse simulations (the mhd3d_vs2 package) (pseudo-spectral, periodic box).

Same model as the axisymmetric code: incompressible resistive MHD for the response flow v and the field B in the
background of the prescribed Lei-Ren-inspired collapse flow U(x, t) (column cutoff, swirl, box taper, regularized
singularity), spheromak seed of radius 1, sudden release at t = 1 (U is handed to the fluid), free evolution to t_end.
    d v/dt = P[ u x w - U x W + eps_B J x B ] + nu Lap v        (u = U + v, w = curl u, W = curl U, P = solenoidal projection)
    d B/dt = curl(u x B) + eta Lap B
Fourier pseudo-spectral in a periodic box |x|<Lx, |y|<Ly, |z|<Lz with N^3 points, 2/3 dealiasing, SSP-RK3 with an
integrating factor for the diffusion terms. mhd3d_vs2 version 2.0 is the mhd3d solver (version 1.4) with the azimuthally averaged
velocity written to every avg2d file, so that the movies can show the swirling fluid together with the magnetic structure
(mhd3d version 1.0 treated diffusion explicitly, which became unstable when the time step reached dt_max after the flow had
decayed, from t = 2.2 on in the eps_B = 50 run). The background is evaluated on an (r, z) table with the 2D module openai_mhd_3d.py and mapped to the cube.
Backend: torch (Apple GPU 'mps', CUDA, or CPU) if installed, else numpy + scipy.fft.

    python3 mhd3d_vs2.py --preset e50_eta0.01          # eps_B = 50, eta = 0.01, nu = 0.1, box 4 x 4 x 5.5, 256^3, t_end = 4
    python3 mhd3d_vs2.py --preset e1000_eta0.05        # eps_B = 1000, eta = 0.05, nu = 0.1, box 5 x 5 x 7
    python3 mhd3d_vs2.py --preset e50_eta0.01 --set N=96 --set t_end=0.2   # quick test
    python3 mhd3d_vs2.py --resume runs/<name>           # continue from the last checkpoint
    python3 mhd3d_vs2.py --extend runs/<name> --set N=320 --set Nz=384 --set "box=[5.0,5.0,8.25]" --set t_end=8   # continue in a larger box
    python3 make_movie_vs2.py movie.mp4 "title" 3.0 7.0 runs/<name> runs/ext_<name>   # movie with the fluid filaments
Outputs in runs/<name>/: diag.csv (energies, helicity, maxima, azimuthal-mode fractions), avg2d_t*.npz (azimuthal
averages on an (r, z) grid, small: Psi, Bphi, Br, Bz of the field and Vr, Vphi, Vz, PsiV of the total velocity u = U + v), snap3d_t*.npz (full B and v in float16 at the snapshot times),
ckpt_*.npz (restart state), log.txt.
"""
import os, sys, json, time, math, argparse, csv
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "axisymmetric"))   # the kernel
import openai_mhd_3d as mhd

# ----------------------------------------------------------------------------- backend
try:
    import torch
    HAVE_TORCH = True
    DEV = "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu")
except Exception:
    HAVE_TORCH = False; DEV = "numpy"

class Backend:
    def __init__(self, N, L, Nz=None):
        self.N = N; self.Nz = Nz or N; self.shape = (N, N, self.Nz); self.L = np.array(L, float); self.h = 2 * self.L / np.array([N, N, self.Nz])
        if HAVE_TORCH:
            self.dev = torch.device(DEV); self.f32 = torch.float32
            kx = 2 * np.pi * np.fft.fftfreq(N, d=self.h[0]); ky = 2 * np.pi * np.fft.fftfreq(N, d=self.h[1]); kz = 2 * np.pi * np.fft.rfftfreq(self.Nz, d=self.h[2])
            KX, KY, KZ = np.meshgrid(kx, ky, kz, indexing="ij")
            self.K = [torch.tensor(a, dtype=torch.float32, device=self.dev) for a in (KX, KY, KZ)]
            K2 = KX**2 + KY**2 + KZ**2; K2[0, 0, 0] = 1.0
            self.K2 = torch.tensor(K2, dtype=torch.float32, device=self.dev); self.iK2 = 1.0 / self.K2
            dm = (np.abs(kx)[:, None, None] <= (2 / 3) * np.abs(kx).max()) & (np.abs(ky)[None, :, None] <= (2 / 3) * np.abs(ky).max()) & (kz[None, None, :] <= (2 / 3) * kz.max())
            self.dealias = torch.tensor(dm, dtype=torch.float32, device=self.dev)
        else:
            import scipy.fft as sf
            self.sf = sf
            kx = 2 * np.pi * np.fft.fftfreq(N, d=self.h[0]); ky = 2 * np.pi * np.fft.fftfreq(N, d=self.h[1]); kz = 2 * np.pi * np.fft.rfftfreq(self.Nz, d=self.h[2])
            KX, KY, KZ = np.meshgrid(kx, ky, kz, indexing="ij"); self.K = [a.astype(np.float32) for a in (KX, KY, KZ)]
            K2 = (KX**2 + KY**2 + KZ**2).astype(np.float32); K2[0, 0, 0] = 1.0; self.K2 = K2; self.iK2 = 1.0 / K2
            self.dealias = ((np.abs(kx)[:, None, None] <= (2 / 3) * np.abs(kx).max()) & (np.abs(ky)[None, :, None] <= (2 / 3) * np.abs(ky).max()) & (kz[None, None, :] <= (2 / 3) * kz.max())).astype(np.float32)
    # transforms
    def r2c(self, a):
        return torch.fft.rfftn(a, dim=(0, 1, 2)) if HAVE_TORCH else self.sf.rfftn(a, axes=(0, 1, 2), workers=-1)
    def c2r(self, a):
        return torch.fft.irfftn(a, s=self.shape, dim=(0, 1, 2)) if HAVE_TORCH else self.sf.irfftn(a, s=self.shape, axes=(0, 1, 2), workers=-1)
    def to_dev(self, a):
        return torch.tensor(np.asarray(a, np.float32), device=self.dev) if HAVE_TORCH else np.asarray(a, np.float32)
    def to_np(self, a):
        return a.detach().cpu().numpy() if HAVE_TORCH else np.asarray(a)
    def zeros_c(self):
        return [torch.zeros((self.N, self.N, self.Nz // 2 + 1), dtype=torch.complex64, device=self.dev) for _ in range(3)] if HAVE_TORCH else [np.zeros((self.N, self.N, self.Nz // 2 + 1), np.complex64) for _ in range(3)]
    # vector calculus in Fourier space
    def curl_k(self, F):
        KX, KY, KZ = self.K
        return [1j * (KY * F[2] - KZ * F[1]), 1j * (KZ * F[0] - KX * F[2]), 1j * (KX * F[1] - KY * F[0])]
    def project(self, F):
        KX, KY, KZ = self.K; div = (KX * F[0] + KY * F[1] + KZ * F[2]) * self.iK2
        return [F[0] - KX * div, F[1] - KY * div, F[2] - KZ * div]
    def cross(self, a, b):
        return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
    def sum(self, a):
        return float(torch.sum(a)) if HAVE_TORCH else float(np.sum(a))
    def amax(self, a):
        return float(torch.max(a)) if HAVE_TORCH else float(np.max(a))

# ----------------------------------------------------------------------------- background and seed tables (r, z)
class Tables:
    """axisymmetric fields on an (r, z) table from the 2D module, mapped to the cube by bilinear interpolation"""
    def __init__(self, cfg, be):
        self.be = be; L = be.L
        rmax = float(np.hypot(L[0], L[1])) + 0.1; self.nr, self.nz = cfg["table_nr"], cfg["table_nz"]
        self.p = mhd.Params(nr=self.nr, nz=self.nz, rbox=rmax, zbox=L[2], r_t=cfg["taper_r"], r_o=cfg["taper_r"] + 0.15 * L[0], z_t=cfg["taper_z"], z_o=cfg["taper_z"] + 0.15 * L[2],
                            profile="leiren", tau_f=cfg["tau_f"], lr_S=cfg["lr_S"], lr_XR=cfg["lr_XR"], lr_Xc=cfg["lr_Xc"], lr_Rc=cfg["lr_Rc"], lr_cutoff=cfg["lr_cutoff"], lr_L0=cfg["lr_L0"],
                            lr_j=cfg["lr_j"], lr_swirl_sign=cfg["swirl_sign"], seed_sign=float(cfg["seed_sign"]), eps_b=cfg["eps_b"], eta=cfg["eta"], nu=cfg["nu"])
        self.g = mhd.Grid(self.p); self.r, self.z = self.g.r, self.g.z
        N = be.N; Nz = be.Nz; x = -L[0] + be.h[0] * (np.arange(N) + 0.5); y = -L[1] + be.h[1] * (np.arange(N) + 0.5); z = -L[2] + be.h[2] * (np.arange(Nz) + 0.5)
        self.x, self.y, self.z3 = x, y, z
        X, Y = np.meshgrid(x, y, indexing="ij"); R = np.sqrt(X**2 + Y**2); self.cos = (X / (R + 1e-12)).astype(np.float32); self.sin = (Y / (R + 1e-12)).astype(np.float32)
        # normalized sampling coordinates for the (r, z) table: r in [0, rmax], z in [-Lz, Lz]
        self.ir = np.clip(R / self.g.dr - 0.5, 0, self.nr - 1).astype(np.float32); self.iz = np.clip((z + L[2]) / self.g.dz - 0.5, 0, self.nz - 1).astype(np.float32)
        if HAVE_TORCH:
            gr = torch.tensor(self.ir / (self.nr - 1) * 2 - 1, device=be.dev); gz = torch.tensor(self.iz / (self.nz - 1) * 2 - 1, device=be.dev)
            GR = gr[:, :, None].expand(N, N, Nz); GZ = gz[None, None, :].expand(N, N, Nz)
            self.grid = torch.stack([GZ, GR], dim=-1).reshape(1, N, N * Nz, 2)       # grid_sample samples (x=col=z index, y=row=r index)
            self.cos_t = torch.tensor(self.cos, device=be.dev)[:, :, None]; self.sin_t = torch.tensor(self.sin, device=be.dev)[:, :, None]
    def sample(self, table2d):
        """bilinear interpolation of an (nr, nz) table onto the cube -> array (N, N, N)"""
        N = self.be.N; Nz = self.be.Nz
        if HAVE_TORCH:
            T = torch.tensor(np.asarray(table2d, np.float32), device=self.be.dev)[None, None]       # (1, 1, nr, nz): rows r, cols z
            out = torch.nn.functional.grid_sample(T, self.grid, mode="bilinear", padding_mode="border", align_corners=True)
            return out.reshape(N, N, Nz)
        from scipy.ndimage import map_coordinates
        IR = np.broadcast_to(self.ir[:, :, None], (N, N, Nz)); IZ = np.broadcast_to(self.iz[None, None, :], (N, N, Nz))
        return map_coordinates(np.asarray(table2d, np.float32), [IR.ravel(), IZ.ravel()], order=1, mode="nearest").reshape(N, N, Nz)
    def cyl_to_cart(self, Fr, Fphi, Fz):
        c, s = (self.cos_t, self.sin_t) if HAVE_TORCH else (self.cos[:, :, None], self.sin[:, :, None])
        return [Fr * c - Fphi * s, Fr * s + Fphi * c, Fz]
    def background(self, tau, scale=1.0):
        """U and curl U on the cube (physical space), from the 2D background at tau"""
        bt = self.g.background_terms(tau); g = self.g
        Ur, Uz, Uphi = bt["Ur"] * scale, bt["Uz"] * scale, g.rc * bt["OU"] * scale
        dr, dz = g.dr, g.dz
        Wr = -np.gradient(Uphi, dz, axis=1); Wz = np.gradient(g.rc * Uphi, dr, axis=0) / g.rc; Wphi = np.gradient(Ur, dz, axis=1) - np.gradient(Uz, dr, axis=0)
        U = self.cyl_to_cart(self.sample(Ur), self.sample(Uphi), self.sample(Uz)); W = self.cyl_to_cart(self.sample(Wr), self.sample(Wphi), self.sample(Wz))
        return U, W
    def seed(self):
        P0, q0 = mhd.spheromak_seed(self.p, self.g); g = self.g
        Psi = g.rc**2 * P0; Bphi = g.rc * q0
        Br = -np.gradient(Psi, g.dz, axis=1) / g.rc; Bz = np.gradient(Psi, g.dr, axis=0) / g.rc
        return self.cyl_to_cart(self.sample(Br), self.sample(Bphi), self.sample(Bz))

# ----------------------------------------------------------------------------- the simulation
PRESETS = {
    "e50_eta0.01": dict(eps_b=50.0, eta=0.01, nu=0.1, box=[4.0, 4.0, 5.5]),
    "e1000_eta0.05": dict(eps_b=1000.0, eta=0.05, nu=0.1, box=[5.0, 5.0, 7.0]),
}
DEFAULTS = dict(N=256, box=[4.0, 4.0, 5.5], eps_b=50.0, eta=0.01, nu=0.1, t_end=4.0, t_off=1.0, tau_f=0.05, cfl=0.4, dt_max=2.5e-3,
                lr_S=2.0, lr_XR=8.0, lr_Xc=0.5, lr_Rc=16.0, lr_cutoff="column", lr_L0=1.0, lr_j=0.001, swirl_sign=1, seed_sign=-1,
                perturbation=1e-3, perturbation_seed=1001, table_nr=512, table_nz=1024, taper_r=None, taper_z=None, bg_every=1,
                diag_every=0.02, avg2d_every=0.1, snap_times=[0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0], ckpt_minutes=15, label="")

def helicity(be, Bk):
    A = be.curl_k(Bk); A = [a * be.iK2 for a in A]            # A_k = i k x B_k / k^2  (curl_k gives i k x B; divide by k^2)
    s = 0.0
    for a, b in zip(A, Bk):
        prod = (a * (b.conj() if HAVE_TORCH else np.conj(b))).real
        # rfft: count the kz > 0 planes twice
        w = 2.0 * prod; w[..., 0] = prod[..., 0]
        if be.N % 2 == 0: w[..., -1] = prod[..., -1]
        s += be.sum(w)
    vol = float(np.prod(2 * be.L)); return s * vol / float(np.prod(be.shape))**2

def energy(be, Fphys):
    dV = float(np.prod(be.h)); return 0.5 * sum(be.sum(f * f) for f in Fphys) * dV

def azimuthal_fractions(be, tab, Bphys, nphi=64, nr=48, nzz=64, rmax=2.0, zmax=None):
    """fraction of |B|^2 in azimuthal modes m = 1, 2, 3, 4 and all m >= 1, on cylindrical rings inside r < rmax, |z| < zmax"""
    L = be.L; zmax = zmax or 0.8 * L[2]
    rr = (np.arange(nr) + 0.5) * rmax / nr; ph = np.linspace(0, 2 * np.pi, nphi, endpoint=False); zz = np.linspace(-zmax, zmax, nzz)
    R, PH, Z = np.meshgrid(rr, ph, zz, indexing="ij"); X = R * np.cos(PH); Y = R * np.sin(PH)
    ix = (X + L[0]) / be.h[0] - 0.5; iy = (Y + L[1]) / be.h[1] - 0.5; iz = (Z + L[2]) / be.h[2] - 0.5
    comps = []
    for Bc in Bphys:
        if HAVE_TORCH:
            T = Bc[None, None]; g = torch.stack([torch.tensor(iz / (be.Nz - 1) * 2 - 1, dtype=torch.float32, device=be.dev), torch.tensor(iy / (be.N - 1) * 2 - 1, dtype=torch.float32, device=be.dev), torch.tensor(ix / (be.N - 1) * 2 - 1, dtype=torch.float32, device=be.dev)], dim=-1)[None]
            comps.append(torch.nn.functional.grid_sample(T, g, mode="bilinear", padding_mode="border", align_corners=True)[0, 0].cpu().numpy())
        else:
            from scipy.ndimage import map_coordinates
            comps.append(map_coordinates(np.asarray(Bc), [ix.ravel(), iy.ravel(), iz.ravel()], order=1, mode="nearest").reshape(R.shape))
    cyl = [comps[0] * np.cos(PH) + comps[1] * np.sin(PH), -comps[0] * np.sin(PH) + comps[1] * np.cos(PH), comps[2]]   # (B_r, B_phi, B_z)
    P = np.fft.rfft(np.stack(cyl), axis=2); pw = (np.abs(P)**2).sum(axis=0).sum(axis=(0, 2)); tot = pw.sum()
    return dict(m1=pw[1] / tot, m2=pw[2] / tot, m3=pw[3] / tot, m4=pw[4] / tot, nonaxi=pw[1:].sum() / tot)

def azimuthal_average(be, tab, Bphys, nr=192, nzz=512):
    L = be.L; rr = (np.arange(nr) + 0.5) * (L[0] / nr); zz = np.linspace(-L[2], L[2], nzz); nphi = 48
    ph = np.linspace(0, 2 * np.pi, nphi, endpoint=False); R, PH, Z = np.meshgrid(rr, ph, zz, indexing="ij"); X = R * np.cos(PH); Y = R * np.sin(PH)
    ix = (X + L[0]) / be.h[0] - 0.5; iy = (Y + L[1]) / be.h[1] - 0.5; iz = (Z + L[2]) / be.h[2] - 0.5
    comps = []
    for Bc in Bphys:
        if HAVE_TORCH:
            g = torch.stack([torch.tensor(iz / (be.Nz - 1) * 2 - 1, dtype=torch.float32, device=be.dev), torch.tensor(iy / (be.N - 1) * 2 - 1, dtype=torch.float32, device=be.dev), torch.tensor(ix / (be.N - 1) * 2 - 1, dtype=torch.float32, device=be.dev)], dim=-1)[None]
            comps.append(torch.nn.functional.grid_sample(Bc[None, None], g, mode="bilinear", padding_mode="border", align_corners=True)[0, 0].cpu().numpy())
        else:
            from scipy.ndimage import map_coordinates
            comps.append(map_coordinates(np.asarray(Bc), [ix.ravel(), iy.ravel(), iz.ravel()], order=1, mode="nearest").reshape(R.shape))
    Br = (comps[0] * np.cos(PH) + comps[1] * np.sin(PH)).mean(axis=1); Bphi = (-comps[0] * np.sin(PH) + comps[1] * np.cos(PH)).mean(axis=1); Bz = comps[2].mean(axis=1)
    Psi = np.cumsum(rr[:, None] * Bz, axis=0) * (rr[1] - rr[0])
    return dict(r=rr, z=zz, Psi=Psi, Bphi=Bphi, Br=Br, Bz=Bz)

def run(cfg, resume_dir=None):
    N = cfg["N"]; be = Backend(N, cfg["box"], cfg.get("Nz") or N); L = be.L
    cfg["taper_r"] = cfg["taper_r"] or 0.72 * float(L[0]); cfg["taper_z"] = cfg["taper_z"] or 0.75 * float(L[2])
    tab = Tables(cfg, be)
    name = (cfg["label"] + "_" if cfg["label"] else "") + f"e{cfg['eps_b']:g}_eta{cfg['eta']:g}_nu{cfg['nu']:g}_N{N}" + (f"x{be.Nz}" if be.Nz != N else "") + f"_box{L[0]:g}x{L[1]:g}x{L[2]:g}"
    out = resume_dir or os.path.join("runs", name); os.makedirs(out, exist_ok=True)
    logf = open(os.path.join(out, "log.txt"), "a")
    def log(s):
        line = time.strftime("%Y-%m-%d %H:%M:%S ") + s; print(line, flush=True); logf.write(line + "\n"); logf.flush()
    json.dump(cfg, open(os.path.join(out, "config.json"), "w"), indent=1)
    diag_path = os.path.join(out, "diag.csv"); fields = ["t", "K_total", "K_response", "M", "H", "Bmax", "umax", "m1", "m2", "m3", "m4", "nonaxi", "dt"]
    # ---- state
    cks = sorted([f for f in os.listdir(out) if f.startswith("ckpt_")]) if resume_dir else []
    if cfg.get("extend_from"):
        # embed the last checkpoint of a finished run (same cell sizes, smaller box) into this larger box by zero-padding
        src = cfg["extend_from"]; ck = sorted([f for f in os.listdir(src) if f.startswith("ckpt_")])[-1]; c = np.load(os.path.join(src, ck))
        scfg = json.load(open(os.path.join(src, "config.json"))); sN = scfg["N"]; sNz = scfg.get("Nz") or sN; sbe = Backend(sN, scfg["box"], sNz)
        cz = int(cfg.get("coarsen", 1)); assert cz >= 1 and sN % cz == 0 and sNz % cz == 0, "coarsen must divide the old grid sizes"
        for h_old, h_new in zip(sbe.h, be.h): assert abs(cz * h_old - h_new) < 1e-9 * h_new, "the new cells must equal the old cells (times coarsen): choose N, Nz and box accordingly"
        t = float(c["t"]); step = int(c["step"]); handed = bool(c["handed"]); assert handed, "extension is meant for the free phase after the release"
        if cz > 1:     # spectral low-pass to the new Nyquist wavenumbers before taking every cz-th point (version 1.4)
            KXo, KYo, KZo = [sbe.to_np(k) for k in sbe.K]
            lp = (np.abs(KXo) < np.pi / be.h[0]) & (np.abs(KYo) < np.pi / be.h[1]) & (np.abs(KZo) < np.pi / be.h[2])
            lp = torch.tensor(lp, device=be.dev) if HAVE_TORCH else lp
        sNc, sNzc = sN // cz, sNz // cz
        def embed(arr_k):
            ak = torch.tensor(arr_k, device=be.dev) if HAVE_TORCH else arr_k.astype(np.complex64)
            if cz > 1: ak = ak * lp
            phys = sbe.to_np(sbe.c2r(ak))[::cz, ::cz, ::cz]
            big = np.zeros(be.shape, np.float32); ox, oz = (N - sNc) // 2, (be.Nz - sNzc) // 2; big[ox:ox + sNc, ox:ox + sNc, oz:oz + sNzc] = phys
            return be.r2c(be.to_dev(big))
        vk = be.project([embed(c[f"v{i}"]) for i in range(3)]); Bk = be.project([embed(c[f"B{i}"]) for i in range(3)])
        with open(diag_path, "w") as fh: csv.DictWriter(fh, fieldnames=fields).writeheader()
        log(f"{name}: extended from {src} ({ck}, t = {t:.4f}) into box {L.tolist()} with shape {be.shape}, coarsened x{cz}; backend {'torch/' + DEV if HAVE_TORCH else 'numpy'}")
    elif cks:
        c = np.load(os.path.join(out, cks[-1])); t = float(c["t"]); step = int(c["step"]); handed = bool(c["handed"])
        vk = [be.to_dev(c[f"v{i}"].real) * 0 for i in range(3)]  # placeholder shapes
        vk = [torch.tensor(c[f"v{i}"], device=be.dev) if HAVE_TORCH else c[f"v{i}"].astype(np.complex64) for i in range(3)]
        Bk = [torch.tensor(c[f"B{i}"], device=be.dev) if HAVE_TORCH else c[f"B{i}"].astype(np.complex64) for i in range(3)]
        log(f"resumed from {cks[-1]} at t = {t:.6f}, step {step}")
    else:
        t, step, handed = 0.0, 0, False
        Bp = tab.seed(); Bk = [be.r2c(b) for b in Bp]
        if cfg["perturbation"] > 0:
            rng = np.random.default_rng(cfg["perturbation_seed"]); amp = cfg["perturbation"]
            noise = [be.r2c(be.to_dev(rng.standard_normal(be.shape).astype(np.float32))) for _ in range(3)]
            # smooth, solenoidal, localized noise scaled to the requested relative L2 amplitude
            KX, KY, KZ = be.K; filt = (be.K2 <= (6.0 * 2 * np.pi / (2 * L[2]))**2) * be.dealias
            noise = be.project([n * filt for n in noise]); npys = [be.c2r(n) for n in noise]
            win = tab.sample(np.exp(-((tab.r[:, None]**2 + tab.z[None, :]**2) / 1.2)))
            npys = [n * win for n in npys]; e_n = math.sqrt(sum(be.sum(n * n) for n in npys)); e_B = math.sqrt(sum(be.sum(b * b) for b in Bp))
            Bk = [bk + be.r2c(n) * (amp * e_B / e_n) for bk, n in zip(Bk, npys)]
        Bk = be.project(Bk); vk = be.zeros_c()
        with open(diag_path, "w") as fh: csv.DictWriter(fh, fieldnames=fields).writeheader()
        log(f"{name}: N = {N}, box {L.tolist()}, h = {be.h.tolist()}, backend {'torch/' + DEV if HAVE_TORCH else 'numpy'}; eps_B = {cfg['eps_b']}, eta = {cfg['eta']}, nu = {cfg['nu']}, perturbation {cfg['perturbation']}")
    eps, eta, nu = cfg["eps_b"], cfg["eta"], cfg["nu"]; K2 = be.K2
    bg_cache = {"tau": None, "U": None, "W": None}
    def background(tau):
        if handed: return None, None
        if bg_cache["tau"] is None or abs(bg_cache["tau"] - tau) > 1e-12:
            U, W = tab.background(tau); bg_cache.update(tau=tau, U=U, W=W)
        return bg_cache["U"], bg_cache["W"]
    stage_exact = HAVE_TORCH or cfg.get("bg_exact_stages", False)
    def rhs(vk, Bk, tt, t0=None):
        U, W = background(1.0 - (tt if stage_exact or t0 is None else t0))     # on the CPU backend the background is evaluated once per step
        v = [be.c2r(f) for f in vk]; w = [be.c2r(f) for f in be.curl_k(vk)]
        B = [be.c2r(f) for f in Bk]; J = [be.c2r(f) for f in be.curl_k(Bk)]
        if U is not None:
            u = [a + b for a, b in zip(v, U)]; wt = [a + b for a, b in zip(w, W)]
            Nv = be.cross(u, wt); UW = be.cross(U, W); Nv = [a - b for a, b in zip(Nv, UW)]
        else:
            u = v; Nv = be.cross(u, w)
        JB = be.cross(J, B); Nv = [a + eps * b for a, b in zip(Nv, JB)]
        NB = be.cross(u, B)
        Nvk = be.project([be.r2c(f) * be.dealias for f in Nv]); NBk = be.curl_k([be.r2c(f) * be.dealias for f in NB])
        dv = Nvk; dB = NBk                                  # diffusion is applied exactly by the integrating factor
        umax = math.sqrt(max(be.amax(sum(a * a for a in u)), 1e-30)); Bmax = math.sqrt(max(be.amax(sum(a * a for a in B)), 1e-30))
        return dv, dB, umax, Bmax, u, B
    expo = (lambda x: torch.exp(x)) if HAVE_TORCH else (lambda x: np.exp(x))
    wall = time.time(); last_ck = wall; next_diag = (math.floor(t / cfg["diag_every"] + 1e-9) + 1) * cfg["diag_every"]
    next_avg = (math.floor(t / cfg["avg2d_every"] + 1e-9) + 1) * cfg["avg2d_every"]
    snaps = [s for s in cfg["snap_times"] if s > t + 1e-12]
    hmin = float(min(be.h)); t_end = cfg["t_end"]; t_off = cfg["t_off"]
    def write_diag(dt_used):
        v = [be.c2r(f) for f in vk]; B = [be.c2r(f) for f in Bk]
        U = tab.background(1.0 - t)[0] if not handed else None
        ut = [a + b for a, b in zip(v, U)] if U is not None else v
        d = dict(t=t, K_total=energy(be, ut), K_response=energy(be, v), M=eps * energy(be, B), H=helicity(be, Bk),
                 Bmax=math.sqrt(be.amax(sum(a * a for a in B))), umax=math.sqrt(be.amax(sum(a * a for a in ut))), dt=dt_used)
        d.update(azimuthal_fractions(be, tab, B))
        with open(diag_path, "a") as fh: csv.DictWriter(fh, fieldnames=fields).writerow({k: (f"{d[k]:.6g}" if isinstance(d[k], float) else d[k]) for k in fields})
        log(f"t = {t:.4f} step {step} dt = {dt_used:.2e}  K_tot = {d['K_total']:.4g} M = {d['M']:.4g} H = {d['H']:.4g} Bmax = {d['Bmax']:.3f} umax = {d['umax']:.3g}  non-axisymmetric {d['nonaxi']:.2e} (m1 {d['m1']:.1e}, m2 {d['m2']:.1e})  [{(time.time() - wall) / 60:.1f} min]")
    if step == 0: write_diag(0.0)
    while t < t_end - 1e-12:
        dv, dB, umax, Bmax, u, B = rhs(vk, Bk, t, t)
        dt = min(cfg["cfl"] * hmin / (umax + math.sqrt(eps) * Bmax + 1e-9), cfg["dt_max"])
        events = [e for e in [next_diag, next_avg, t_end, t_off] + snaps if e > t + 1e-12]; nxt = min(events); dt = min(dt, nxt - t)
        # SSP-RK3 with the integrating factor for diffusion (exact exponential damping; no diffusive step-size limit)
        Ev, Eb = expo(-nu * K2 * dt), expo(-eta * K2 * dt); Evh, Ebh = expo(-nu * K2 * 0.5 * dt), expo(-eta * K2 * 0.5 * dt)
        v1 = [Ev * (a + dt * b) for a, b in zip(vk, dv)]; B1 = [Eb * (a + dt * b) for a, b in zip(Bk, dB)]
        dv1, dB1, _, _, _, _ = rhs(v1, B1, t + dt, t)
        v2 = [0.75 * Evh * a + 0.25 * (b + dt * c) / Evh for a, b, c in zip(vk, v1, dv1)]
        B2 = [0.75 * Ebh * a + 0.25 * (b + dt * c) / Ebh for a, b, c in zip(Bk, B1, dB1)]
        dv2, dB2, _, _, _, _ = rhs(v2, B2, t + 0.5 * dt, t)
        vk = [Ev * a / 3 + 2 / 3 * Evh * (b + dt * c) for a, b, c in zip(vk, v2, dv2)]
        Bk = [Eb * a / 3 + 2 / 3 * Ebh * (b + dt * c) for a, b, c in zip(Bk, B2, dB2)]
        t += dt; step += 1
        if abs(t - nxt) < 1e-10: t = nxt
        if step % 50 == 0: Bk = be.project(Bk)
        # ---- events
        if not handed and abs(t - t_off) < 1e-10:
            U, W = tab.background(1.0 - t)
            Bp = [be.c2r(f) for f in Bk]; up = [be.c2r(f) for f in vk]
            np.savez_compressed(os.path.join(out, f"snap3d_t{t:.3f}_before_release.npz"), t=t, x=tab.x, y=tab.y, z=tab.z3, config=json.dumps(cfg),
                                B=np.stack([be.to_np(b) for b in Bp]).astype(np.float16), v=np.stack([be.to_np(a + b) for a, b in zip(up, U)]).astype(np.float16))
            vk = be.project([a + be.r2c(b) for a, b in zip(vk, U)]); handed = True; bg_cache.update(tau=None, U=None, W=None)
            log(f"t = {t:.3f}: sudden release, imposed flow handed to the fluid")
        if abs(t - next_diag) < 1e-10 or t >= t_end - 1e-12:
            write_diag(dt); next_diag += cfg["diag_every"]
        if abs(t - next_avg) < 1e-10:
            B = [be.c2r(f) for f in Bk]; av = azimuthal_average(be, tab, B)
            # azimuthal average of the total velocity (imposed + response before the release): Vr, Vphi, Vz and the Stokes
            # stream function PsiV = int r Vz dr, so that the movies can show the flow (version 1.3)
            vv = [be.c2r(f) for f in vk]; Ub = tab.background(1.0 - t)[0] if not handed else None
            ut = [a + b for a, b in zip(vv, Ub)] if Ub is not None else vv; avv = azimuthal_average(be, tab, ut)
            np.savez_compressed(os.path.join(out, f"avg2d_t{t:.3f}.npz"), t=t, **av, Vr=avv["Br"], Vphi=avv["Bphi"], Vz=avv["Bz"], PsiV=avv["Psi"]); next_avg += cfg["avg2d_every"]
        if snaps and abs(t - snaps[0]) < 1e-10:
            B = [be.c2r(f) for f in Bk]; v = [be.c2r(f) for f in vk]
            U = tab.background(1.0 - t)[0] if not handed else None; ut = [a + b for a, b in zip(v, U)] if U is not None else v
            np.savez_compressed(os.path.join(out, f"snap3d_t{t:.3f}.npz"), t=t, x=tab.x, y=tab.y, z=tab.z3, config=json.dumps(cfg),
                                B=np.stack([be.to_np(b) for b in B]).astype(np.float16), v=np.stack([be.to_np(a) for a in ut]).astype(np.float16))
            log(f"snapshot written at t = {t:.3f}"); snaps.pop(0)
        if time.time() - last_ck > 60 * cfg["ckpt_minutes"] or t >= t_end - 1e-12:
            np.savez(os.path.join(out, f"ckpt_{step:08d}.npz"), t=t, step=step, handed=handed, **{f"v{i}": be.to_np(vk[i]) for i in range(3)}, **{f"B{i}": be.to_np(Bk[i]) for i in range(3)})
            for f in sorted([f for f in os.listdir(out) if f.startswith("ckpt_")])[:-2]: os.remove(os.path.join(out, f))
            last_ck = time.time(); log(f"checkpoint at t = {t:.4f}")
    log(f"finished at t = {t:.4f} after {step} steps ({(time.time() - wall) / 3600:.2f} h)")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--preset", choices=list(PRESETS)); ap.add_argument("--set", action="append", default=[]); ap.add_argument("--resume")
    ap.add_argument("--extend", help="run folder of a finished run to continue in a larger box (same cell sizes; set N, Nz, box, t_end with --set)")
    a = ap.parse_args()
    if a.resume:
        cfg = json.load(open(os.path.join(a.resume, "config.json"))); run(cfg, resume_dir=a.resume); return
    cfg = dict(DEFAULTS); cfg.update(PRESETS[a.preset] if a.preset else {})
    if a.extend:
        cfg = json.load(open(os.path.join(a.extend, "config.json"))); cfg["extend_from"] = a.extend; cfg["label"] = (cfg.get("label") or "") + "ext"; cfg["coarsen"] = 1
    for s in a.set:
        k, v = s.split("=", 1); cfg[k] = json.loads(v) if v[0] in "[{" or v.replace(".", "").replace("-", "").replace("e", "").isdigit() else v
        if k in ("N", "Nz", "coarsen"): cfg[k] = int(cfg[k])
    run(cfg)

if __name__ == "__main__":
    main()
