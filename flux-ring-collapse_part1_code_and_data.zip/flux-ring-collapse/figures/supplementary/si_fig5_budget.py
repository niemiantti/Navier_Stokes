"""Supplementary Figure 5: closure of the helicity, magnetic-energy and energy budgets in time for the three
re-integrated runs (data/budgets/budget_*.csv, written by budget.py with the production code)."""
from paths import *
import csv, numpy as np
from style import plt, MM, WIDTH, letter

RUNS = [("e50_eta0.05_t0-1", r"$\epsilon_B$ = 50, $\eta$ = 0.05", "#c92a2a"),
        ("e50_eta0.01_t0.5-1", r"$\epsilon_B$ = 50, $\eta$ = 0.01", "#1971c2"),
        ("e1000_eta0.05_t0.9-1.4", r"$\epsilon_B$ = 1000, $\eta$ = 0.05", "#2b8a3e")]

def load(lab):
    R = list(csv.DictReader(open(f"{DATA}/budgets/budget_{lab}.csv")))
    g = lambda k: np.array([float(r[k]) for r in R])
    return {k: g(k) for k in R[0]}

fig = plt.figure(figsize=(WIDTH, 52 * MM))
X0 = [0.068, 0.40, 0.732]; W = 0.25; Y0 = 0.19; H = 0.66
axes = [fig.add_axes([x, Y0, W, H]) for x in X0]
for lab, name, col in RUNS:
    d = load(lab); t = d["t"]
    # a: helicity residual relative to the initial helicity of the interval
    axes[0].plot(t, 100 * d["RH"] / d["H"][0], color=col, lw=1.0)
    # b: magnetic-energy residual relative to the resistive dissipation accumulated so far (after the first 0.05 time units)
    ok = t > t[0] + 0.05
    axes[1].plot(t[ok], 100 * d["RM"][ok] / d["IDeta"][ok], color=col, lw=1.0)
    # c: energy residual with the quadrature imbalance of the imposed flow removed, relative to the energy dissipated
    axes[2].plot(t[ok], 100 * (d["RE"][ok] + d["Ipure"][ok]) / (d["IDnu"][ok] + d["IDeta"][ok]), color=col, lw=1.0, label=name)
for ax in axes:
    ax.axvline(1.0, color="k", ls=":", lw=0.7); ax.axhline(0, color="k", lw=0.5)
    ax.set_xlim(0, 1.4); ax.set_xlabel("$t$")
axes[0].set_ylabel("residual of $H$ / $H(t_0)$ (%)")
axes[1].set_ylabel(r"residual of $M$ / $\int D_\eta\,dt$ (%)")
axes[2].set_ylabel(r"residual of $E$ / $\int(D_\nu + D_\eta)\,dt$ (%)")
axes[0].set_ylim(-0.5, 0.5); axes[1].set_ylim(-6, 6); axes[2].set_ylim(-1.5, 1.5)
axes[2].legend(loc="lower left", fontsize=6.4, handlelength=1.4)
letter(axes[0], "a", "helicity", x=-0.2, y=1.03)
letter(axes[1], "b", "magnetic energy", x=-0.2, y=1.03)
letter(axes[2], "c", "total energy", x=-0.2, y=1.03)
for ax in axes: ax.text(0.995, ax.get_ylim()[1] * 0.93, "release", fontsize=6.2, ha="right", va="top", color="k")
out = OUT + "/si_fig5_budget.pdf"; fig.savefig(out); fig.savefig(out.replace(".pdf", ".png"), dpi=200); print("written", out)
# the numbers quoted in Supplementary Note 5
for lab, *_ in RUNS:
    d = load(lab); i = -1
    print(lab, "max |R_H|/H0 = %.3f%%" % (100 * np.max(np.abs(d["RH"])) / abs(d["H"][0])),
          "| R_M / int D_eta at the end = %.2f%%" % (100 * d["RM"][i] / d["IDeta"][i]),
          "| (R_E + I_pure) / dissipated at the end = %.3f%%" % (100 * (d["RE"][i] + d["Ipure"][i]) / (d["IDnu"][i] + d["IDeta"][i])))
