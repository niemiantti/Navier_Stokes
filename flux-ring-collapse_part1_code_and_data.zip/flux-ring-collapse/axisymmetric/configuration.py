"""Validated input, complete configuration fingerprints, and model mapping."""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import hashlib
import json
import math
import re
import numpy as np
import openai_mhd_3d as mhd

VERSION = "3b.2"
SCHEMA = "leiren_bigbox_vs3b/1"
DEFAULTS = dict(
    profile="leiren", eps_b=10.0, eta=0.05, nu=0.01,
    r_box=2.0, z_box=2.0, nr=512,
    t_start=0.0, t_end=3.0, t_off=1.0, mode="sudden", t_ramp=0.1,
    tau_f=0.05, lr_a=4.0, lr_delta=0.005, lr_j=0.001, lr_L0=0.1,
    lr_Rc=32.0, lr_cutoff="column", lr_S=2.0, lr_XR=8.0, lr_Xc=0.5,
    swirl_sign=1, seed="spheromak", orientation="-1", seed_w=0.3,
    seed_lam=4.4934094579090641753, seed_taper_start=0.7,
    surrogate_lr0=2.0, surrogate_lz0=2.0, surrogate_h=0.005,
    surrogate_j0=0.05, surrogate_cp=1.0, surrogate_cs=1.0,
    flow_window="ellipsoid", flow_r0=0.5, flow_z0=0.5,
    flow_inner=0.7, flow_window_evolution="similarity",
    require_small_flow=True, small_flow_radius=0.5, small_flow_fraction=0.95,
    min_feature_cells=3.0, preferred_feature_cells=6.0,
    cfl=0.5, diff_frac=0.6, dt_max=0.0025,
    light_dt=0.05, full_snap_times=None, diagnostic_steps=20, track_steps=2,
    checkpoint_seconds=600.0, checkpoint_keep=3, log_steps=200, threads=4,
    runs_dir="~/leiren_bigbox_vs3b_runs", label="",
    parent_run="", parent_t=0.0,     # continuation: start from the final checkpoint of run parent_run (at t = parent_t)
)
# These affect neither the integration nor the field definition. Everything
# else, including diagnostics/snapshot schedule, is included in the identity.
OPERATIONAL = {"runs_dir", "label", "threads", "checkpoint_seconds", "checkpoint_keep", "log_steps"}
GENERATED = {"schema", "version", "config_sha256", "name", "nz", "r_t", "r_o", "z_t", "z_o",
             "seed_sign", "orientation_report", "origin_vs3"}


def canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def box_fields(raw):
    unknown = set(raw) - set(DEFAULTS) - GENERATED
    if unknown:
        raise ValueError("Unknown parameter(s): " + ", ".join(sorted(unknown)))
    d = dict(DEFAULTS)
    d.update(raw)
    if d.get("schema", SCHEMA) != SCHEMA:
        raise ValueError("This driver cannot resume a vs3 checkpoint. Use --import-vs3 for a NEW experiment.")
    d["schema"] = SCHEMA
    d["version"] = VERSION
    for k in ("nr", "diagnostic_steps", "track_steps", "checkpoint_keep", "log_steps", "threads"):
        v = d[k]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or int(v) != v or v <= 0:
            raise ValueError(f"{k} must be a positive integer")
        d[k] = int(v)
    if not 16 <= d["nr"] <= 4096:
        raise ValueError("nr must lie between 16 and 4096; small grids are software tests only")
    for k, default in DEFAULTS.items():
        if isinstance(default, float):
            if isinstance(d[k], bool):
                raise ValueError(f"{k} must be numeric, not bool")
            try:
                d[k] = float(d[k])
            except (ValueError, TypeError):
                raise ValueError(f"{k} must be a real number") from None
            if not math.isfinite(d[k]):
                raise ValueError(f"{k} must be finite")
    positive = ["r_box", "z_box", "tau_f", "lr_L0", "lr_Rc", "lr_XR", "lr_Xc", "seed_w",
                "flow_r0", "flow_z0", "small_flow_radius", "min_feature_cells", "preferred_feature_cells",
                "cfl", "diff_frac", "dt_max", "light_dt", "checkpoint_seconds", "t_ramp",
                "surrogate_lr0", "surrogate_lz0", "seed_lam"]
    for k in positive:
        if d[k] <= 0:
            raise ValueError(f"{k} must be positive")
    for k in ("eps_b", "eta", "nu", "lr_S"):
        if d[k] < 0:
            raise ValueError(f"{k} must be nonnegative")
    if min(d["r_box"], d["z_box"]) <= 1.05:
        raise ValueError("The radius-one magnetic seed needs r_box and z_box > 1.05")
    if not (0 <= d["t_start"] < 1 and d["t_end"] > d["t_start"] and d["t_off"] > d["t_start"]):
        raise ValueError("Require 0 <= t_start < 1, t_end > t_start, and t_off > t_start")
    d["mode"] = "sudden" if d["mode"] == "free" else d["mode"]
    choices = dict(profile=("leiren", "surrogate"), mode=("sudden", "ramp", "kept"),
                   lr_cutoff=("cone", "column"), seed=("spheromak", "pair"),
                   flow_window=("none", "ellipsoid"), flow_window_evolution=("fixed", "similarity"))
    for k, vals in choices.items():
        if d[k] not in vals:
            raise ValueError(f"{k} must be one of {vals}")
    if d["swirl_sign"] not in (-1, 1):
        raise ValueError("swirl_sign must be +1 or -1")
    d["swirl_sign"] = int(d["swirl_sign"])
    d["orientation"] = str(d["orientation"])
    if d["orientation"] not in ("auto", "1", "-1"):
        raise ValueError("orientation must be auto, 1 or -1")
    if not isinstance(d["require_small_flow"], bool):
        raise ValueError("require_small_flow must be true or false")
    if not (0 <= d["lr_delta"] < 0.5 and 0 <= d["surrogate_h"] < 0.5):
        raise ValueError("Need 0 <= lr_delta < 0.5 and 0 <= surrogate_h < 0.5")
    if not (0 < d["flow_inner"] < 1 and 0 < d["seed_taper_start"] < 1):
        raise ValueError("flow_inner and seed_taper_start must lie strictly between 0 and 1")
    if not (0 < d["small_flow_fraction"] <= 1 and d["cfl"] <= 0.5 and d["diff_frac"] <= 0.6):
        raise ValueError("Need fraction in (0,1], cfl <= 0.5 and diff_frac <= 0.6")
    if d["checkpoint_keep"] < 2:
        raise ValueError("Keep at least two checkpoint generations")
    d["nz"] = int(round(d["nr"] * 2*d["z_box"] / d["r_box"]))
    if d["nz"] < 16:
        raise ValueError("nz must be at least 16")
    d["r_t"], d["r_o"] = .75*d["r_box"], .9*d["r_box"]
    d["z_t"], d["z_o"] = .75*d["z_box"], .9*d["z_box"]
    snaps = d["full_snap_times"]
    if snaps is not None:
        if not isinstance(snaps, list) or any(not isinstance(v, (float,int)) or not math.isfinite(v) for v in snaps):
            raise ValueError("full_snap_times must be a list of finite times or null")
        if any(v < d["t_start"] or v > d["t_end"] for v in snaps):
            raise ValueError("A full snapshot is outside [t_start,t_end]")
        d["full_snap_times"] = sorted(set(float(v) for v in snaps))
    if not isinstance(d["label"], str) or (d["label"] and not re.fullmatch(r"[A-Za-z0-9_.-]{1,45}",d["label"])):
        raise ValueError("label must use only letters/digits/._- and be at most 45 characters")
    if not isinstance(d["runs_dir"], str) or not d["runs_dir"]:
        raise ValueError("runs_dir must be a path string")
    return d


def make_params(d, seed_sign=None):
    return mhd.Params(
        nr=d["nr"], nz=d["nz"], rbox=d["r_box"], zbox=d["z_box"],
        r_t=d["r_t"], r_o=d["r_o"], z_t=d["z_t"], z_o=d["z_o"],
        eta=d["eta"], nu=d["nu"], eps_b=d["eps_b"], tau_f=d["tau_f"], profile=d["profile"],
        lr_a=d["lr_a"], lr_delta=d["lr_delta"], lr_j=d["lr_j"], lr_L0=d["lr_L0"],
        lr_Rc=d["lr_Rc"], lr_cutoff=d["lr_cutoff"], lr_S=d["lr_S"], lr_XR=d["lr_XR"],
        lr_Xc=d["lr_Xc"], lr_swirl_sign=float(d["swirl_sign"]),
        lr0=d["surrogate_lr0"], lz0=d["surrogate_lz0"], h=d["surrogate_h"],
        j0=d["surrogate_j0"], cp=d["surrogate_cp"], cs=d["surrogate_cs"]*d["swirl_sign"],
        seed=d["seed"], seed_sign=float(d.get("seed_sign",1) if seed_sign is None else seed_sign),
        seed_w=d["seed_w"], lam=d["seed_lam"], s_c=d["seed_taper_start"],
        cfl=d["cfl"], diff_frac=d["diff_frac"],
        flow_window=d["flow_window"], flow_r0=d["flow_r0"], flow_z0=d["flow_z0"],
        flow_inner=d["flow_inner"], flow_window_evolution=d["flow_window_evolution"], flow_t0=d["t_start"])


def orientation_check(d):
    """A local diagnostic, NOT a global twist-alignment guarantee.

    Samples adapt to the compact inner envelope. Auto is intentionally not the
    default: comparisons should keep the same explicitly selected magnetic seed.
    """
    p = make_params(d,seed_sign=1)
    tau = 1-d["t_start"]
    if d["flow_window"] == "ellipsoid":
        ar, az = mhd.envelope_axes(p,tau)
    else:
        ar = az = min(1.0, max(d["lr_L0"],0.05))
    rr = ar*np.array([.08,.2])[:,None]
    zz = az*np.array([.15,.3])[None,:]
    h = max(az*1e-5,1e-10)
    upper=(mhd.background(p,rr,zz+h,tau)[1]-mhd.background(p,rr,zz-h,tau)[1])/(2*h)
    lower=(mhd.background(p,rr,-zz+h,tau)[1]-mhd.background(p,rr,-zz-h,tau)[1])/(2*h)
    present = bool(np.max(np.abs(upper))+np.max(np.abs(lower))>1e-14)
    sa=int(np.sign(np.mean(upper))) if present else 0
    sb=int(np.sign(np.mean(lower))) if present else 0
    return dict(swirl_present=present, induced_sign_above=sa, induced_sign_below=sb,
                samples_r=rr[:,0].tolist(),samples_z=zz[0].tolist(),
                qualification="local sign of d_z Omega only; not full B dot grad Omega or global alignment")


def identity_payload(d):
    return dict(schema=SCHEMA, inputs={k:d[k] for k in DEFAULTS if k not in OPERATIONAL},
                seed_sign=d["seed_sign"], solver_params=asdict(make_params(d)))


def finish_params(raw):
    d=box_fields(raw)
    ori=orientation_check(d)
    expected=float((ori["induced_sign_above"] or 1) if d["orientation"]=="auto" else int(d["orientation"]))
    if "seed_sign" in raw and float(raw["seed_sign"]) != expected:
        raise ValueError("Saved seed_sign conflicts with the requested orientation; start a NEW configuration")
    d["seed_sign"]=expected
    d["orientation_report"]=ori
    digest=hashlib.sha256(canonical_json(identity_payload(d)).encode()).hexdigest()
    if raw.get("config_sha256") and raw["config_sha256"] != digest:
        raise ValueError("Configuration fingerprint mismatch: the saved parameters were changed. Use --set for a NEW run.")
    d["config_sha256"]=digest
    tag="LRref" if d["profile"]=="leiren" else "Surrogate"
    prefix=d["label"] or f"{tag}_e{d['eps_b']:g}_eta{d['eta']:g}_nu{d['nu']:g}_n{d['nr']}"
    window=f"_a{d['flow_r0']:g}_b{d['flow_z0']:g}" if d["flow_window"]=="ellipsoid" else "_unconfined"
    name=f"{prefix}{window}_{digest[:12]}"
    if raw.get("name") and raw["name"]!=name:
        raise ValueError("Saved run name does not match this configuration fingerprint")
    d["name"]=name
    return d


def apply_overrides(raw, assignments):
    d=dict(raw)
    if assignments:
        for k in GENERATED:
            d.pop(k,None)
    for assignment in assignments or []:
        if "=" not in assignment:
            raise ValueError("--set expects key=value")
        key,value=assignment.split("=",1)
        if key not in DEFAULTS:
            raise ValueError(f"Unknown setting {key}")
        try:
            d[key]=json.loads(value)
        except json.JSONDecodeError:
            d[key]=value
    return d


def import_vs3(raw):
    """Import input parameters only, never checkpoints or success markers.

    New confinement remains OFF to avoid silently replacing the old experiment.
    Explicit --set flow_window=ellipsoid enables the new physical modification.
    """
    d={k:v for k,v in raw.items() if k in DEFAULTS}
    d.update(schema=SCHEMA, runs_dir=DEFAULTS["runs_dir"], label="imported_vs3",
             flow_window="none", require_small_flow=False)
    # vs3 defaults are different; preserve them when absent from a saved file.
    d.setdefault("lr_L0",1.0)
    d.setdefault("lr_cutoff","cone")
    d.setdefault("r_box",6.0); d.setdefault("z_box",8.0); d.setdefault("nr",384)
    d.setdefault("orientation","auto")
    d["origin_vs3"]="Input-only import; old checkpoints cannot be resumed by vs3b"
    return d
