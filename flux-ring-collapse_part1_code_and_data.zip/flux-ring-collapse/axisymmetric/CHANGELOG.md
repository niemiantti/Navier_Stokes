# Changes from vs3b.1 to vs3b.2 (4 October)

- `--extend NAME --set t_end=T`: continue a FINISHED run to a later time as a new experiment. The new run starts from the parent's final checkpoint (recorded in the parent's finished.json), keeps the lattice and all physical parameters (checked), carries the parent's tracks and diagnostics, and writes `continuation_provenance.json` (parent name, checkpoint, configuration and code hashes). The parent's data are not touched. The final checkpoint of every finished run was already retained by vs3b.1; this makes it usable.
- `--flow-panels` (and automatically after every run): figure `figures/flow_panels.png/.pdf` with the imposed flows of this configuration, surrogate (a) and Lei-Ren-inspired (b), at t = 0, 0.4, 0.8, 0.95 in the whole box, with speed, streamlines, swirl contours and the initial spheromak's flux surfaces. Kinematic: no run data needed.
- Two new identity fields in the configuration: `parent_run`, `parent_t` (empty / 0 for ordinary runs). VERSION 3b.2.

# Changes from the uploaded vs3 to vs3b.1

## Geometry and defaults

Added an independent physical ellipsoidal envelope to BOTH SU and angular velocity before spatial differentiation. Outer radial/axial semi-axes, flat-inner fraction and fixed/similarity evolution are explicit controls. The flow remains incompressible at continuum level; discrete divergence has truncation errors and must be checked. L0 remains the original fixed-strain internal rescaling. The seed size and magnetic seed formula are preserved; a stable small-argument series avoids cancellation in j1(x)/x very near the origin.

The new compact pilot defaults are deliberately smaller: L0=0.1, outer axes 0.5/0.5, box radius and half-height 2/2, 512 x 1024 cells, fixed seed sign -1. The -1 choice preserves the usual earlier auto choice for positive swirl but, unlike auto, is held fixed when changing background. Legacy geometry is available explicitly. There is no automatic read or overwrite of old results.

## Diagnostics and scientific labeling

Corrected the physical-time derivative sign in Pext and dKU_dt. Corrected the axis ghost parity for physical radial/toroidal velocity in this diagnostic. Added parameter-aware preflight, component energy enclosure, sampled resolution and velocity-derivative error checks. Added total-velocity/current/ohmic/RMS magnetic-length outputs. Corrected the postprocessing convention for meridional toroidal flux. Output titles identify the flow as a reference-inspired model; pair seeds are opposite-twist configurations, not certified individual Hopf charges.

## Release

Preserved the vs3 conservative handover and added a runtime continuity guard and physical-acceleration comparison. Ramp transfer is now evaluated in all RK stages with the compensating -A' U0 source, rather than by a first-order stepwise reassignment. Its precise effective force is documented in the README. No change was made to the core MHD RHS or the advection, diffusion and Poisson formulas.

## Safety and reproducibility

All fields, not only P, are checked for nonfinite values. Only reaching the requested endpoint with finite accepted data writes a success marker. Failures retain usable checkpoints and a failure record. Graceful interrupt/termination checkpoints the last accepted state. Three verified generations are retained by default even after completion. Corrupt newest checkpoints can fall back to older compatible ones; later snapshots are archived, not mixed with a replayed trajectory.

Configuration fingerprints include former collision fields such as Rc and Xc and all physical/numerical controls. Source hashes reject cross-version state reuse. Exclusive writer locks prevent duplicate jobs. Existing foreign output directories and parameter files are not silently reused. Input-only vs3 import always creates a new experiment.

## Not changed into something else

This is still the uploaded axisymmetric finite-difference MHD model, not the separate full-Cartesian 3-D package. The numerical changes do not construct the actual Lei–Ren solution, establish Hopf charges, or prove a production result converged. Compact support of U does not imply compact support of the total response V or B.
