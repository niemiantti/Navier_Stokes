import json, glob, os, sys, numpy as np
B = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))   # repository root
sys.path.insert(0, B + "/analysis"); import cuspfit as Cf
R = B + "/figures/data/results/"
dz = 16.0/1024
for d in sorted(glob.glob(R + "*/")):
    if "LRref" in d or "d87ab6" in d: continue
    s = json.load(open(d + "data/summary.json")); p = json.load(open(d + "data/params.json"))
    sp = s.get("split") or {}; ts = sp.get("t_s")
    tr = [q for q in json.load(open(d + "data/tracks.json")) if q["t"] <= 1.0 + 1e-9]
    # first record with dmax >= 1e-3 (summary definition) and its ratio
    f1 = next((q for q in tr if q["dmax"] >= 1e-3), None)
    # first record with an island deeper than 1e-3 AND wider than 3 cells (caption definition of 'resolved')
    f2 = next((q for q in tr if q["dmax"] >= 1e-3 and (q["sep"] or 0) > 3*dz), None)
    def ratio(q):
        c = sorted(q["cps"], key=lambda x: x["z"]); best = None
        for i, x in enumerate(c):
            if x["kind"] == "X" and 0 < i < len(c)-1:
                dl, dh = c[i-1]["psi"]-x["psi"], c[i+1]["psi"]-x["psi"]
                if best is None or min(dl, dh) > best[0]: best = (min(dl, dh), min(dl, dh)/max(dl, dh))
        return best[1] if best else None
    line = f"eta={p['eta']:<5g} eps={p['eps_b']:>5g} ts(summary)={ts if ts is None else round(ts,5)} ratio(summary)={sp.get('island_ratio') if ts is None else round(sp['island_ratio'],3)}"
    if f1: line += f" | first dmax>=1e-3 at t={f1['t']:.4f} ratio={ratio(f1):.3f}"
    if f2: line += f" | first >=1e-3 & >3 cells at t={f2['t']:.4f}"
    if ts is not None:
        rows = Cf.tracks_beta(tr, t_window=(ts - 0.001, ts + 0.06), dmin=5e-4)[:15]
        b = np.array([r["beta"] for r in rows]); qq = np.array([r["ratio"] for r in rows])
        bm, qm = np.median(b), np.median(qq); b25, b75 = np.percentile(b, [25, 75]); q25, q75 = np.percentile(qq, [25, 75])
        bs = np.linspace(b25, b75, 400); Rv = np.array([Cf.cusp_ratio(x) for x in bs])
        hbar = Rv.min() <= qm <= Rv.max(); vbar = q25 <= Cf.cusp_ratio(bm) <= q75
        rect = (Rv.max() >= q25) and (Rv.min() <= q75)
        # minimal vertical distance between the cross and the curve
        line += f" | median15 ratio={qm:.3f} beta={bm:.3f} cross_touches={hbar or vbar} (h={hbar}, v={vbar}) rect={rect}"
    print(line)
