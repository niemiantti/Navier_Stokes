#!/usr/bin/env python3
"""
Axisymmetric resistive-MHD kernel for leiren_bigbox_vs3b.

This evolves three-component axisymmetric fields on an (r,z) grid, NOT a
Cartesian 3-D calculation. The Lei-Ren-inspired background is a regularized
kinematic model, NOT the completed Lei-Ren profile or a verified NS blow-up
solution. A separate compact window may be applied to BOTH the meridional
streamfunction and angular velocity, before velocity differentiation.

The original vs3 MHD RHS, Poisson matrix, advection and diffusion operators
are retained. Use leiren_bigbox_vs3b.py, not this module's inherited standalone
entry point, for the vs3b driver, configuration checks and safe run management.
"""
import argparse
import json
import csv
import os
import time
from dataclasses import dataclass, asdict

import numpy as np
from scipy.fft import dst, idst
from scipy.linalg import eigh


# =============================================================================
# Parameters
# =============================================================================
@dataclass
class Params:
    # grid / domain  (S1.60)-(S1.61)
    nr: int = 256
    nz: int = 512
    rbox: float = 4.0
    zbox: float = 4.0
    # physics  (S1.72)
    eta: float = 0.02
    nu: float = 0.02
    eps_b: float = 0.01
    # background flow  (S1.16)-(S1.26)
    h: float = 0.005
    j0: float = 0.05
    lr0: float = 2.0
    lz0: float = 2.0
    cp: float = 1.0
    cs: float = 1.0
    tau_f: float = 0.0
    reverse: str = "none"     # continuation through t = 1: "none" | "envelope" (|sigma|, no sign change)
                              # | "bounce" (meridional flow reversed)
                              # | "full" (meridional flow and swirl reversed), via sigma = tau / tau_eff
    t_off: float = 1.0e9      # force switched off at t = t_off: the imposed flow is handed to the response
    U_scale: float = 1.0      # amplitude factor of the imposed flow (ramped release: 1 -> 0, the removed part handed to the response)
                              # (v <- v + U) and U = 0 afterwards, so V evolves freely (NS + Lorentz)
    r_t: float = 3.0
    r_o: float = 3.6
    z_t: float = 3.0
    z_o: float = 3.6
    # seed  (S1.48)-(S1.51); first zero of j1
    lam: float = 4.4934094579090641753
    s_c: float = 0.7
    # time stepping
    tau_end: float = 0.5
    cfl: float = 0.5          # on sum |V_r|/dr + |V_z|/dz (+ Alfven speed)
    diff_frac: float = 0.6    # fraction of the RK3 real-axis limit (2.51)
    snap_dtau: float = 0.1
    # imposed-flow profile: "surrogate" (the Gaussian surrogate above) or "leiren" (the leading-order
    # reference-inspired kinematic flow: u_z = (lr_a Z + lr_j) / lambda^(1+delta) with
    # lambda^2 - lambda^(2 delta) z^2 = tau_eff, Z = z / lambda^(1-delta), R = r^2 / (2 lambda^2), optional model swirl,
    # meridional flow switched off smoothly between R = lr_Rc and 2 lr_Rc)
    profile: str = "surrogate"
    lr_a: float = 4.0
    lr_j: float = 0.001
    lr_delta: float = 0.005
    lr_Rc: float = 32.0
    lr_L0: float = 1.0               # INTERNAL fixed-strain length scale, not overall support radius
    lr_cutoff: str = "cone"          # "cone": cutoff at the local similarity radius R = r^2/(2 lambda(z)^2) (widens with |z|)
                                     # "column": cutoff at r^2/(2 lambda(0)^2): a column of radius sqrt(2 R_c tau_eff) around the axis
    # OpenAI-type swirl added to the Lei-Ren flow: u_theta = lambda^-(1+delta) E(R, Z), E = S f(Z) g(R) with
    # f = 1/(1+Z^2), g ~ sqrt(R) (solid body) inside R_c, ~ R^(1/10) up to the ring R_s, ~ R^(-1/2) beyond it
    lr_S: float = 0.0
    lr_XR: float = 8.0
    lr_Xc: float = 0.5
    lr_swirl_sign: float = 1.0
    # magnetic seed: "spheromak" (one twisted torus, B_phi even in z) or "pair" (opposite toroidal twist: B_phi odd in z,
    # q0 = seed_sign lam P0 tanh(z/seed_w)); seed_sign multiplies the toroidal field (helicity sign)
    seed: str = "spheromak"
    seed_sign: float = 1.0
    seed_w: float = 0.3
    # OpenAI-type swirl for the Lei-Ren flow (u_theta = E / lambda^(1+delta)), E = P_s f(Z) g(R):
    # f = 1/(1 + Z^2); g rises like (R/R_s)^(1/10) (reference branch), is regular at the axis (u_theta ~ r inside
    # the core radius R_core) and falls like (R/R_s)^(-1/2) beyond the ring at R_s (potential vortex)

    # Compact physical envelope, in seed-radius units. Defaults in this kernel
    # are off for regression tests; the vs3b DRIVER defaults to ellipsoid.
    flow_window: str = "none"       # none | ellipsoid
    flow_r0: float = 0.5            # OUTER radial semi-axis at flow_t0
    flow_z0: float = 0.5            # OUTER axial semi-axis at flow_t0
    flow_inner: float = 0.7         # flat interior in normalized ellipsoidal radius
    flow_window_evolution: str = "similarity"  # similarity | fixed
    flow_t0: float = 0.0            # initial time used to normalize envelope sizes


# =============================================================================
# Background flow  (S1.16)-(S1.26)
# =============================================================================
def taper(x):
    """Smooth step C(x) of (S1.24): 1 for x <= 0, 0 for x >= 1."""
    x = np.asarray(x, dtype=float)
    out = np.where(x <= 0.0, 1.0, 0.0)
    m = (x > 0.0) & (x < 1.0)
    xm = x[m]
    with np.errstate(over="ignore"):
        out[m] = 1.0 / (1.0 + np.exp(-1.0 / xm + 1.0 / (1.0 - xm)))
    return out


def scales(p, tau):
    te = np.sqrt(tau**2 + p.tau_f**2)
    return te, p.lr0 * te**0.5, p.lz0 * te**(0.5 - p.h)


def envelope_axes(p, tau):
    """Outer physical semi-axes at time tau=1-t, normalized at flow_t0.

    Similarity envelope is an explicit modelling choice, NOT the paper's
    global matching. At flow_t0 the axes are exactly flow_r0 and flow_z0.
    """
    ar, az = float(p.flow_r0), float(p.flow_z0)
    if p.flow_window_evolution == "fixed":
        return ar, az
    if p.flow_window_evolution != "similarity":
        raise ValueError("flow_window_evolution must be fixed or similarity")
    te = float(np.hypot(tau, p.tau_f))
    te0 = float(np.hypot(1.0 - p.flow_t0, p.tau_f))
    if te <= 0 or te0 <= 0:
        raise ValueError("compact envelope requires a positive regularized time scale")
    ez = ((1.0 - p.lr_delta) / 2.0 if p.profile == "leiren" else 0.5 - p.h)
    return ar * (te / te0)**0.5, az * (te / te0)**ez


def flow_envelope(p, r, z, tau):
    """C-infinity compact ellipsoid, applied BEFORE taking spatial derivatives.

    Using rho**2 avoids a square-root derivative at the axis/origin. This
    squared-radius taper is 1 for rho<=flow_inner and 0 for rho>=1. It is
    a documented change from the linear-rho illustrative window in the audit.
    """
    if p.flow_window == "none":
        return 1.0
    if p.flow_window != "ellipsoid":
        raise ValueError("flow_window must be none or ellipsoid")
    ar, az = envelope_axes(p, tau)
    if ar <= 0 or az <= 0 or not (0 < p.flow_inner < 1):
        raise ValueError("invalid compact-envelope axes or inner fraction")
    rho2 = (np.asarray(r, dtype=float) / ar)**2 + (np.asarray(z, dtype=float) / az)**2
    return taper((rho2 - p.flow_inner**2) / (1.0 - p.flow_inner**2))


def background(p, r, z, tau):
    """Regular streamfunction S_U (S1.21) and angular velocity Omega_U (S1.23).
    Even in r (uses |r|), so it can be evaluated at mirrored ghost points."""
    if 1.0 - tau >= getattr(p, "t_off", 1.0e9) - 1e-12:        # force removed: no imposed flow
        zero = np.zeros(np.broadcast(np.asarray(r), np.asarray(z)).shape)
        return zero, zero.copy()
    sc = getattr(p, "U_scale", 1.0)
    if getattr(p, "profile", "surrogate") == "leiren":
        SU, OU = background_leiren(p, r, z, tau)
        window = flow_envelope(p, r, z, tau)
        return SU * window * sc, OU * window * sc
    te, lr, lz = scales(p, tau)
    R, Z = r / lr, z / lz
    chi = (taper((np.abs(r) - p.r_t) / (p.r_o - p.r_t))
           * taper((np.abs(z) - p.z_t) / (p.z_o - p.z_t)))
    G = (Z + p.j0) * np.exp(-0.5 * Z**2)
    SU = p.cp * (lz / te) * np.exp(-0.5 * R**2) * G * chi
    OU = ((p.cs * lz / (te * lr)) * chi * (1.0 + R**2)**(-1.0 - p.h)
          * (1.0 + np.exp(-0.5 * R**2) / (1.0 + Z**2)) * np.exp(-0.5 * Z**2))
    rev = getattr(p, "reverse", "none")
    if rev == "envelope":             # same envelope as the bounce, no sign change: |tau| / tau_eff
        SU = SU * (np.abs(tau) / te)
    if rev in ("bounce", "full"):
        sigma = tau / te              # +1 before the peak, 0 at t = 1, -1 after (smooth over ~tau_f)
        SU = SU * sigma
        if rev == "full":
            OU = OU * sigma
    window = flow_envelope(p, r, z, tau)
    return SU * window * sc, OU * window * sc


def lambda_leiren(te, z, delta, n_iter=10):
    """lambda(t, z) of the Lei-Ren similarity variables: lambda^2 - lambda^(2 delta) z^2 = tau_eff
    (fixed-point iteration; contraction factor <= delta)."""
    z2 = np.asarray(z, dtype=float)**2
    lam = np.sqrt(te + z2)
    for _ in range(n_iter):
        lam = np.sqrt(te + lam**(2.0 * delta) * z2)
    return lam


def background_leiren(p, r, z, tau):
    """Unwindowed, reference-inspired kinematic background (not the paper's core).
    The INTERNAL scaling is U_L(x,t)=L0 U_1(x/L0,t), at fixed strain.
    Radial cutoffs act on SU; the driver-independent flow_envelope is applied
    by background() to BOTH SU and OU. All velocities are then differentiated
    from the resulting streamfunction. Smooth swirl is optional.
    """
    te = np.sqrt(tau**2 + p.tau_f**2)
    d = p.lr_delta
    L0 = getattr(p, "lr_L0", 1.0)
    rr = np.abs(np.asarray(r, dtype=float)) / L0                 # the profile in units of its own scale L0
    zz = np.asarray(z, dtype=float) / L0
    lam = lambda_leiren(te, zz, d)
    Z = zz / lam**(1.0 - d)
    R = rr**2 / (2.0 * lam**2)
    if getattr(p, "lr_cutoff", "cone") == "column":
        Rcut = rr**2 / (2.0 * te)                                     # midplane similarity radius: a column, not a cone
    else:
        Rcut = R
    B = taper((Rcut - p.lr_Rc) / p.lr_Rc)                        # smooth radial turn-off
    chi = (taper((rr * L0 - p.r_t) / (p.r_o - p.r_t)) * taper((np.abs(zz) * L0 - p.z_t) / (p.z_o - p.z_t)))
    SU = L0 * 0.5 * (p.lr_a * Z + p.lr_j) / lam**(1.0 + d) * B * chi   # u_L(x) = L0 u(x / L0): same strain rates
    if p.lr_S == 0.0:
        return SU, np.zeros_like(SU)
    # OpenAI-type swirl: u_theta = lambda^-(1+delta) E(R, Z) with E = S f(Z) g(R), f = 1/(1+Z^2); g ~ sqrt(R)
    # (solid body) inside R_c = lr_Xc, ~ R^(1/10) up to the ring R_s = lr_XR, ~ R^(-1/2) beyond it.
    # Omega_U = u_theta / r is finite on the axis.
    Rc, Rs = p.lr_Xc, p.lr_XR
    g_over_r = (((R + Rc) / Rs)**0.1 * (1.0 + (R / Rs)**2)**(-0.3) / (np.sqrt(2.0 * (R + Rc)) * lam**(2.0 + d)))
    OU = p.lr_swirl_sign * p.lr_S / (1.0 + Z**2) * g_over_r * chi
    return SU, OU


# =============================================================================
# Grid, operators, Poisson solver
# =============================================================================
class Grid:
    def __init__(self, p, build_poisson=True):
        self.p = p
        self.nr, self.nz = p.nr, p.nz
        self.dr = p.rbox / p.nr
        self.dz = 2.0 * p.zbox / p.nz
        self.r = (np.arange(p.nr) + 0.5) * self.dr
        self.z = -p.zbox + (np.arange(p.nz) + 0.5) * self.dz
        self.rc = self.r[:, None]
        rp = (np.arange(p.nr) + 1.0) * self.dr          # outer face radii
        rm = np.arange(p.nr) * self.dr                   # inner face radii
        mvol = (rp**4 - rm**4) / 4.0                     # int r^3 dr over a cell
        self.rp3, self.rm3 = (rp**3)[:, None], (rm**3)[:, None]
        self.den = (self.dr * mvol)[:, None]
        self.rghost = p.rbox + (np.arange(2) + 0.5) * self.dr
        self.dV = (2.0 * np.pi * self.r * self.dr * self.dz)[:, None] * np.ones((1, p.nz))
        # extended coordinates with 3 ghost layers (background evaluation)
        self.rE = (np.arange(-3, p.nr + 3) + 0.5) * self.dr
        self.zE = -p.zbox + (np.arange(-3, p.nz + 3) + 0.5) * self.dz
        self.rE2 = self.rE[1:-1][:, None]
        if build_poisson:
            self._build_poisson(rp, rm, mvol)

    # --- Poisson:  L5 S = -zeta,  S = 0 on r = R and z = +-Z -----------------
    def _build_poisson(self, rp, rm, mvol):
        n, dr = self.nr, self.dr
        K = np.zeros((n, n))
        i = np.arange(n)
        K[i, i] = -(rp**3 + rm**3) / dr
        K[i[:-1], i[:-1] + 1] = rp[:-1]**3 / dr
        K[i[1:], i[1:] - 1] = rm[1:]**3 / dr
        K[n - 1, n - 1] = -(rm[-1]**3 + 2.0 * rp[-1]**3) / dr   # odd ghost at wall
        mu, V = eigh(K, np.diag(mvol))                            # V^T M V = I
        self.mu, self.V, self.VtM = mu, V, V.T * mvol[None, :]
        k = np.arange(1, self.nz + 1)
        self.kap = -(4.0 / self.dz**2) * np.sin(np.pi * k / (2.0 * self.nz))**2
        self.lam_max = np.abs(mu).max() + np.abs(self.kap).max()

    def solve_poisson(self, zeta):
        zh = dst(zeta, type=2, axis=1, norm="ortho")
        c = -(self.VtM @ zh) / (self.mu[:, None] + self.kap[None, :])
        return idst(self.V @ c, type=2, axis=1, norm="ortho")

    # --- ghost-cell padding (2 layers) ---------------------------------------
    def pad(self, f, rbc="odd", zbc="odd"):
        out = np.empty((f.shape[0] + 4, f.shape[1] + 4))
        out[2:-2, 2:-2] = f
        out[1, 2:-2], out[0, 2:-2] = f[0], f[1]                  # axis: even
        if rbc == "odd":                                         # Dirichlet
            out[-2, 2:-2], out[-1, 2:-2] = -f[-1], -f[-2]
        elif rbc == "robin":                                     # d_r(r^2 q) = 0
            out[-2, 2:-2] = f[-1] * (self.r[-1] / self.rghost[0])**2
            out[-1, 2:-2] = f[-2] * (self.r[-2] / self.rghost[1])**2
        else:                                                    # Neumann
            out[-2, 2:-2], out[-1, 2:-2] = f[-1], f[-2]
        s = -1.0 if zbc == "odd" else 1.0
        out[:, 1], out[:, 0] = s * out[:, 2], s * out[:, 3]
        out[:, -2], out[:, -1] = s * out[:, -3], s * out[:, -4]
        return out

    # --- derivatives of padded arrays, returned on the interior --------------
    def ddr(self, g):
        return (g[3:-1, 2:-2] - g[1:-3, 2:-2]) / (2.0 * self.dr)

    def ddz(self, g):
        return (g[2:-2, 3:-1] - g[2:-2, 1:-3]) / (2.0 * self.dz)

    def L5(self, g):
        f0 = g[2:-2, 2:-2]
        lr = (self.rp3 * (g[3:-1, 2:-2] - f0) - self.rm3 * (f0 - g[1:-3, 2:-2])) / self.den
        lz = (g[2:-2, 3:-1] - 2.0 * f0 + g[2:-2, 1:-3]) / self.dz**2
        return lr + lz

    def advect(self, g, vr, vz):
        """(V_p . grad) f, third-order upwind-biased in each direction."""
        f0 = g[2:-2, 2:-2]
        a2, a1, b1, b2 = g[0:-4, 2:-2], g[1:-3, 2:-2], g[3:-1, 2:-2], g[4:, 2:-2]
        back = (2.0 * b1 + 3.0 * f0 - 6.0 * a1 + a2) / (6.0 * self.dr)
        fwd = (-b2 + 6.0 * b1 - 3.0 * f0 - 2.0 * a1) / (6.0 * self.dr)
        out = vr * np.where(vr > 0.0, back, fwd)
        a2, a1, b1, b2 = g[2:-2, 0:-4], g[2:-2, 1:-3], g[2:-2, 3:-1], g[2:-2, 4:]
        back = (2.0 * b1 + 3.0 * f0 - 6.0 * a1 + a2) / (6.0 * self.dz)
        fwd = (-b2 + 6.0 * b1 - 3.0 * f0 - 2.0 * a1) / (6.0 * self.dz)
        return out + vz * np.where(vz > 0.0, back, fwd)

    # --- background quantities on the grid ------------------------------------
    def background_terms(self, tau):
        p, dr, dz = self.p, self.dr, self.dz
        SU, OU = background(p, self.rE[:, None], self.zE[None, :], tau)   # 3 ghosts
        c = slice(1, -1)
        SUr = (SU[2:, c] - SU[:-2, c]) / (2 * dr)                          # 2 ghosts
        SUz = (SU[c, 2:] - SU[c, :-2]) / (2 * dz)
        SUrr = (SU[2:, c] - 2 * SU[c, c] + SU[:-2, c]) / dr**2
        SUzz = (SU[c, 2:] - 2 * SU[c, c] + SU[c, :-2]) / dz**2
        zetaU2 = -(SUrr + 3.0 / self.rE2 * SUr + SUzz)                    # (S1.36)
        OU2 = OU[1:-1, 1:-1]
        r = self.rc
        return dict(
            SU=SU[3:-3, 3:-3], OU=OU[3:-3, 3:-3], OU2=OU2,
            Ur=-r * SUz[2:-2, 2:-2], Uz=2 * SU[3:-3, 3:-3] + r * SUr[2:-2, 2:-2],
            alphaU=-SUz[2:-2, 2:-2], zetaU=zetaU2[2:-2, 2:-2],
            zetaU_r=self.ddr(zetaU2), zetaU_z=self.ddz(zetaU2),
            OU_r=self.ddr(OU2), OU_z=self.ddz(OU2))


# =============================================================================
# Seed field  (S1.48)-(S1.51)
# =============================================================================
def spheromak_seed(p, grid):
    s = np.sqrt(grid.rc**2 + grid.z[None, :]**2)
    k = abs(p.lam)
    x = k * s
    small = np.abs(x) < 1.0e-3
    safe_x = np.where(small, 1.0, x)
    j1_over_x = np.sin(safe_x) / safe_x**3 - np.cos(safe_x) / safe_x**2
    series = 1.0/3.0 - x*x/30.0 + x**4/840.0 - x**6/45360.0
    P0 = taper((s - p.s_c) / (1.0 - p.s_c)) * 1.5 * np.where(small, series, j1_over_x)
    sgn = getattr(p, "seed_sign", 1.0)
    if getattr(p, "seed", "spheromak") == "pair":                # opposite-twist seed; no individual Hopf-charge certification
        return P0, sgn * p.lam * P0 * np.tanh(grid.z[None, :] / p.seed_w)
    return P0, sgn * p.lam * P0


# =============================================================================
# Right-hand side of (S1.38)-(S1.41)
# =============================================================================
def rhs(grid, state, t):
    p, g = grid.p, grid
    zeta, a, P, q = state
    bg = g.background_terms(1.0 - t)
    r = g.rc

    S = g.solve_poisson(zeta)                                   # (S1.31)
    Sg = g.pad(S)
    Sr, Sz = g.ddr(Sg), g.ddz(Sg)
    vr, vz, alphav = -r * Sz, 2.0 * S + r * Sr, -Sz            # (S1.28), (S1.35)
    Vr, Vz = bg["Ur"] + vr, bg["Uz"] + vz

    zg, ag, Pg = g.pad(zeta), g.pad(a), g.pad(P)
    qg = g.pad(q, "robin", "even")
    Pr, Pz, qr, qz = g.ddr(Pg), g.ddz(Pg), g.ddr(qg), g.ddz(qg)
    Br, Bz = -r * Pz, 2.0 * P + r * Pr                          # (S1.34)
    Jz = 2.0 * q + r * qr                                       # (S1.43)
    L5P = g.L5(Pg)
    L5Pg = g.pad(L5P)                                           # J_phi = 0 on walls
    Lzeta = -(Br * g.ddr(L5Pg) + Bz * g.ddz(L5Pg)) - g.ddz(qg**2)   # = (S1.47)
    La = qz * Bz - Pz * Jz                                      # (S1.44)

    dzeta = (-g.advect(zg, Vr, Vz) - (vr * bg["zetaU_r"] + vz * bg["zetaU_z"])
             + g.ddz(2.0 * bg["OU2"] * ag + ag**2) + p.nu * g.L5(zg)
             + p.eps_b * Lzeta)                                 # (S1.38)
    da = (-g.advect(ag, Vr, Vz) - (vr * bg["OU_r"] + vz * bg["OU_z"])
          - 2.0 * (bg["alphaU"] * a + alphav * bg["OU"] + alphav * a)
          + p.nu * g.L5(ag) + p.eps_b * La)                     # (S1.39)
    dP = (-g.advect(Pg, Vr, Vz) - 2.0 * (bg["alphaU"] + alphav) * P
          + p.eta * L5P)                                        # (S1.40)
    dq = (-g.advect(qg, Vr, Vz) + Br * (bg["OU_r"] + g.ddr(ag))
          + Bz * (bg["OU_z"] + g.ddz(ag)) + p.eta * g.L5(qg))   # (S1.41)
    aux = dict(Vr=Vr, Vz=Vz, Babs=np.sqrt(Br**2 + Bz**2 + (r * q)**2))
    return (dzeta, da, dP, dq), aux


def derived(grid, state, tau):
    """Physical fields and diagnostics for a state at time tau."""
    p, g = grid.p, grid
    zeta, a, P, q = state
    r = g.rc
    bg = g.background_terms(tau)
    S = g.solve_poisson(zeta)
    Sg, Pg, qg = g.pad(S), g.pad(P), g.pad(q, "robin", "even")
    Pr, Pz, qr, qz = g.ddr(Pg), g.ddz(Pg), g.ddr(qg), g.ddz(qg)
    f = dict(
        tau=tau, S=S, zeta=zeta, a=a, P=P, q=q,
        vr=-r * g.ddz(Sg), vz=2 * S + r * g.ddr(Sg), vphi=r * a,
        Br=-r * Pz, Bz=2 * P + r * Pr, Bphi=r * q,
        Jr=-r * qz, Jphi=-r * g.L5(Pg), Jz=2 * q + r * qr,
        Psi=r**2 * P, SU=bg["SU"], OU=bg["OU"], Ur=bg["Ur"], Uz=bg["Uz"],
        Uphi=r * bg["OU"], chi=r**2 * bg["SU"])
    return f


def diagnostics(grid, state, tau):
    p, g = grid.p, grid
    f = derived(grid, state, tau)
    B2 = f["Br"]**2 + f["Bphi"]**2 + f["Bz"]**2
    BJ = f["Br"] * f["Jr"] + f["Bphi"] * f["Jphi"] + f["Bz"] * f["Jz"]
    v2 = f["vr"]**2 + f["vphi"]**2 + f["vz"]**2
    U2 = f["Ur"]**2 + f["Uphi"]**2 + f["Uz"]**2
    r3 = (g.r**3)[:, None]
    return dict(
        t=1.0 - tau, tau=tau,
        H=4.0 * np.pi * np.sum(r3 * f["P"] * f["q"]) * g.dr * g.dz,          # (S1.55)
        dHdt_res=-2.0 * p.eta * np.sum(BJ * g.dV),                          # (S1.56)
        M=0.5 * p.eps_b * np.sum(B2 * g.dV), K=0.5 * np.sum(v2 * g.dV),
        Bmax=np.sqrt(B2.max()), Jmax=np.sqrt((f["Jr"]**2 + f["Jphi"]**2 + f["Jz"]**2).max()),
        vmax=np.sqrt(v2.max()), Umax=np.sqrt(U2.max()),
        Psi_max=f["Psi"].max(), Psi_min=f["Psi"].min())


# =============================================================================
# Time integration
# =============================================================================
def regrid(src, dst, F, rbc="odd", zbc="odd"):
    """Cubic interpolation of a cell-centred field from grid src to grid dst,
    using the boundary parities (ghost cells) of src."""
    from scipy.interpolate import RectBivariateSpline
    Fp = src.pad(F, rbc, zbc)
    rE = (np.arange(-2, src.nr + 2) + 0.5) * src.dr
    zE = -src.p.zbox + (np.arange(-2, src.nz + 2) + 0.5) * src.dz
    return RectBivariateSpline(rE, zE, Fp, kx=3, ky=3)(dst.r, dst.z)


def regrid_state(src, dst, state):
    bcs = [("odd", "odd"), ("odd", "odd"), ("odd", "odd"), ("robin", "even")]
    return [regrid(src, dst, F, *bc) for F, bc in zip(state, bcs)]


def _read_csv(path):
    with open(path) as fh:
        return [{k: float(v) for k, v in r.items()} for r in csv.DictReader(fh)]


def _write_csv(path, rows):
    keys = list(rows[0].keys())
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys, restval="")
        w.writeheader()
        w.writerows(rows)


def save_snapshot(outdir, p, state, tau):
    np.savez_compressed(os.path.join(outdir, f"snapshot_tau{tau:.2f}.npz"),
                        zeta=state[0], a=state[1], P=state[2], q=state[3],
                        tau=tau, params=np.array([str(asdict(p))]))


def prepare_continuation(p, outdir, src_dir, tau_src):
    """Start a run in outdir from snapshot tau_src of the run in src_dir.  If the
    grids differ, the state is interpolated (cubic) onto the new grid, and the
    earlier snapshots are copied over on the new grid (the tau = 1 seed is
    re-evaluated exactly).  The earlier diagnostics are carried over so that the
    helicity balance continues; a column 'nr' records the grid of each row."""
    g = Grid(p)
    with open(os.path.join(src_dir, "params.json")) as fh:
        ps = Params(**json.load(fh))
    gs = Grid(ps)
    same = (ps.nr, ps.nz) == (p.nr, p.nz)
    tau_list = sorted({float(f[12:16]) for f in os.listdir(src_dir)
                       if f.startswith("snapshot_tau") and f.endswith(".npz")}, reverse=True)
    for tg in tau_list:
        if tg < tau_src - 1e-9:
            continue
        st, _ = load_snapshot(gs, os.path.join(src_dir, f"snapshot_tau{tg:.2f}.npz"))
        if abs(tg - 1.0) < 1e-12:
            P0, q0 = spheromak_seed(p, g)
            st = [np.zeros_like(P0), np.zeros_like(P0), P0, q0]
        elif not same:
            st = regrid_state(gs, g, st)
        save_snapshot(outdir, p, st, tg)
    state, _ = load_snapshot(g, os.path.join(outdir, f"snapshot_tau{tau_src:.2f}.npz"))
    rows = [r for r in _read_csv(os.path.join(src_dir, "diagnostics.csv"))
            if r["t"] <= 1.0 - tau_src + 1e-9]
    for r in rows:
        r.setdefault("nr", float(ps.nr))
    H0 = rows[0]["H"]
    last = rows[-1]
    res_int = last["H"] - H0 - last["H_balance_residual"] * abs(H0)
    return dict(state=state, t=1.0 - tau_src, H0=H0, M0=rows[0]["M"], res_int=res_int,
                rows=rows, step=0)


def run(p, outdir, cont=None, resume=False, max_wall=None, diag_every=1, log_every=100):
    """SSP-RK3 integration from tau = 1 (or from a continuation / checkpoint) to
    p.tau_end.  With max_wall (seconds) the run writes checkpoint.npz and stops;
    call again with resume=True to continue."""
    g = Grid(p)
    ck_path = os.path.join(outdir, "checkpoint.npz")
    csv_path = os.path.join(outdir, "diagnostics.csv")
    if resume:
        ck = np.load(ck_path)
        c = dict(state=[ck["zeta"], ck["a"], ck["P"], ck["q"]], t=float(ck["t"]),
                 H0=float(ck["H0"]), M0=float(ck["M0"]), res_int=float(ck["res_int"]),
                 step=int(ck["step"]), rows=_read_csv(csv_path))
    elif cont is not None:
        c = cont
    else:
        P0, q0 = spheromak_seed(p, g)
        st = [np.zeros_like(P0), np.zeros_like(P0), P0, q0]
        d0 = diagnostics(g, st, 1.0)
        d0["H_balance_residual"], d0["nr"] = 0.0, float(p.nr)
        save_snapshot(outdir, p, st, 1.0)
        c = dict(state=st, t=0.0, H0=d0["H"], M0=d0["M"], res_int=0.0, step=0, rows=[d0])
    state, t, H0, M0, res_int, step, rows = (c["state"], c["t"], c["H0"], c["M0"],
                                             c["res_int"], c["step"], c["rows"])
    t_end = 1.0 - p.tau_end
    taus = np.round(np.arange(1.0, p.tau_end - 1e-9, -p.snap_dtau), 10)
    snap_t = sorted({1.0 - tg for tg in taus if 1.0 - tg > t + 1e-9} | {t_end})
    dt_diff = p.diff_frac * 2.51 / (max(p.nu, p.eta) * g.lam_max)
    d = diagnostics(g, state, 1.0 - t)
    rate_prev, t_prev = d["dHdt_res"], t
    if resume and "t_prev" in ck.files:          # continue the trapezoid where it stopped
        rate_prev, t_prev = float(ck["rate_prev"]), float(ck["t_prev"])
    wall = time.time()
    print(f"grid {p.nr} x {p.nz}, dr = {g.dr:.4f}, dz = {g.dz:.4f}, start tau = {1 - t:.4f}, "
          f"diffusion-limited dt = {dt_diff:.2e}", flush=True)

    def checkpoint():
        np.savez(ck_path, zeta=state[0], a=state[1], P=state[2], q=state[3], t=t, H0=H0, M0=M0,
                 res_int=res_int, step=step, t_prev=t_prev, rate_prev=rate_prev)
        _write_csv(csv_path, rows)

    while snap_t:
        k1, aux = rhs(g, state, t)
        adv = np.max(np.abs(aux["Vr"]) / g.dr + np.abs(aux["Vz"]) / g.dz
                     + np.sqrt(p.eps_b) * aux["Babs"] * (1 / g.dr + 1 / g.dz))
        dt = 1.0 / (adv / p.cfl + 1.0 / dt_diff)
        dt = min(dt, 2.5e-3, snap_t[0] - t)
        u1 = [s + dt * k for s, k in zip(state, k1)]
        k2, _ = rhs(g, u1, t + dt)
        u2 = [0.75 * s + 0.25 * (s1 + dt * k) for s, s1, k in zip(state, u1, k2)]
        k3, _ = rhs(g, u2, t + 0.5 * dt)
        state = [s / 3.0 + 2.0 / 3.0 * (s2 + dt * k) for s, s2, k in zip(state, u2, k3)]
        t += dt
        step += 1
        at_snap = abs(t - snap_t[0]) < 1e-12
        if step % diag_every == 0 or at_snap:
            d = diagnostics(g, state, 1.0 - t)
            res_int += 0.5 * (rate_prev + d["dHdt_res"]) * (t - t_prev)
            rate_prev, t_prev = d["dHdt_res"], t
            d["H_balance_residual"] = (d["H"] - H0 - res_int) / abs(H0)
            d["nr"] = float(p.nr)
            rows.append(d)
        if step % log_every == 0:
            print(f"step {step:6d}  tau = {1 - t:.4f}  dt = {dt:.2e}  H/H0 = {d['H'] / H0:.4f}  "
                  f"M/M0 = {d['M'] / M0:.3f}  max|B| = {d['Bmax']:.2f}  "
                  f"max|v|/max|U| = {d['vmax'] / d['Umax']:.2e}  "
                  f"Psi in [{d['Psi_min']:.1e}, {d['Psi_max']:.4f}]  ({time.time() - wall:.0f} s)",
                  flush=True)
        if at_snap:
            save_snapshot(outdir, p, state, 1.0 - t)
            print(f"  snapshot tau = {1 - t:.2f}", flush=True)
            snap_t.pop(0)
            checkpoint()
        if max_wall is not None and time.time() - wall > max_wall and snap_t:
            checkpoint()
            print(f"checkpoint at tau = {1 - t:.4f} after {step} steps; resume with --resume",
                  flush=True)
            return g, False
    _write_csv(csv_path, rows)
    if os.path.exists(ck_path):
        os.remove(ck_path)
    print(f"done: {step} steps; helicity-balance residual {rows[-1]['H_balance_residual']:.2e}",
          flush=True)
    return g, True


def load_snapshot(grid, path):
    d = np.load(path)
    return [d["zeta"], d["a"], d["P"], d["q"]], float(d["tau"])


# =============================================================================
# Geometry helpers for the 3-D figures
# =============================================================================
class Meridional:
    """Cubic-spline interpolation of axisymmetric fields in the (r, z) half-plane.
    Each field is mirrored across the axis with its parity (odd for r-components)."""

    def __init__(self, grid, fields):
        from scipy import ndimage
        self._nd, self.g, self.coef = ndimage, grid, {}
        for name, (arr, parity) in fields.items():
            ext = np.concatenate([parity * arr[3::-1], arr], axis=0)
            self.coef[name] = ndimage.spline_filter(ext, order=3, mode="nearest")

    def __call__(self, name, r, z):
        i = r / self.g.dr - 0.5 + 4.0
        j = (z + self.g.p.zbox) / self.g.dz - 0.5
        return self._nd.map_coordinates(self.coef[name], [i, j], order=3,
                                        prefilter=False, mode="nearest")


def _contour_lines(grid, F, level):
    import contourpy
    gen = contourpy.contour_generator(x=grid.r, y=grid.z, z=F.T, line_type="Separate")
    return gen.lines(level)


def closed_loops(grid, F, level, min_pts=30):
    """Closed contours F = level in the (r, z) half-plane, largest first."""
    out = [ln[:-1] for ln in _contour_lines(grid, F, level)
           if len(ln) >= min_pts and np.hypot(*(ln[0] - ln[-1])) < 1e-9]
    return sorted(out, key=len, reverse=True)


def resample_closed(loop, n):
    pts = np.vstack([loop, loop[:1]])
    s = np.concatenate([[0.0], np.cumsum(np.hypot(*np.diff(pts, axis=0).T))])
    si = np.arange(n) * (s[-1] / n)
    return np.interp(si, s, pts[:, 0]), np.interp(si, s, pts[:, 1]), s[-1]


def line_on_surface(loop, M, names, n_turns, phi0=0.0, max_dphi=0.015, n0=1200):
    """Field line (or streamline) lying on the surface of revolution of a closed
    meridional contour.  names = (F_r, F_z, F_phi/r).  Integrates
    dphi/dl = (F_phi/r)/|F_p| along the contour, oriented along F_p.
    Returns (N, 3) Cartesian points and the toroidal advance per poloidal turn."""
    fr, fz, fw = names
    n = n0
    for _ in range(5):
        r, z, L = resample_closed(loop, n)
        Fr, Fz, Fw = M(fr, r, z), M(fz, r, z), M(fw, r, z)
        if np.sum(Fr * (np.roll(r, -1) - r) + Fz * (np.roll(z, -1) - z)) < 0:
            r, z, Fr, Fz, Fw = r[::-1], z[::-1], Fr[::-1], Fz[::-1], Fw[::-1]
            r, z, Fr, Fz, Fw = (np.roll(x, 1) for x in (r, z, Fr, Fz, Fw))
        rate = Fw / np.maximum(np.hypot(Fr, Fz), 1e-12)
        dphi = 0.5 * (rate + np.roll(rate, -1)) * (L / n)
        if np.abs(dphi).max() <= max_dphi:
            break
        n = int(n * np.abs(dphi).max() / max_dphi) + 1
    phi = np.concatenate([[0.0], np.cumsum(dphi)[:-1]])
    adv = dphi.sum()
    R, Z = np.tile(r, n_turns), np.tile(z, n_turns)
    PHI = phi0 + np.concatenate([phi + k * adv for k in range(n_turns)])
    return np.column_stack([R * np.cos(PHI), R * np.sin(PHI), Z]), adv


def _pieces(mask, pts, min_len=4):
    idx = np.flatnonzero(np.diff(np.concatenate([[0], mask.astype(int), [0]])))
    return [pts[a:b] for a, b in zip(idx[::2], idx[1::2]) if b - a >= min_len]


def in_phi(pts, phi0, phi1):
    return np.mod(np.arctan2(pts[:, 1], pts[:, 0]) - phi0, 2 * np.pi) <= (phi1 - phi0)


def in_box(pts, rmax, zmax):
    return (np.hypot(pts[:, 0], pts[:, 1]) <= rmax) & (np.abs(pts[:, 2]) <= zmax)


def clip_phi(pts, phi0, phi1, min_len=4):
    return _pieces(in_phi(pts, phi0, phi1), pts, min_len)


def camera(az_deg, el_deg, dist, focal=(0.0, 0.0, 0.0)):
    a, e = np.deg2rad(az_deg), np.deg2rad(el_deg)
    pos = (focal[0] + dist * np.cos(e) * np.cos(a), focal[1] + dist * np.cos(e) * np.sin(a),
           focal[2] + dist * np.sin(e))
    return [pos, focal, (0.0, 0.0, 1.0)]


def _pv():
    import pyvista as pv
    pv.OFF_SCREEN = True
    return pv


def polyline(pts):
    """One continuous polyline through pts (pv.lines_from_points would create
    separate segments, whose tubes show seams at every joint)."""
    pv = _pv()
    poly = pv.PolyData(np.asarray(pts, dtype=float))
    poly.lines = np.concatenate([[len(pts)], np.arange(len(pts))])
    return poly


def revolve_poly(r, z, ph):
    """Quad-mesh surface of revolution of the meridional polyline (r, z)."""
    pv = _pv()
    n, m = len(r), len(ph)
    X, Y = r[:, None] * np.cos(ph)[None, :], r[:, None] * np.sin(ph)[None, :]
    Z = np.repeat(z[:, None], m, axis=1)
    idx = np.arange(n * m).reshape(n, m)
    a, b, c, d = (idx[:-1, :-1].ravel(), idx[1:, :-1].ravel(),
                  idx[1:, 1:].ravel(), idx[:-1, 1:].ravel())
    faces = np.column_stack([np.full(a.size, 4), a, b, c, d]).ravel()
    mesh = pv.PolyData(np.column_stack([X.ravel(), Y.ravel(), Z.ravel()]), faces)
    return mesh.compute_normals(split_vertices=False, consistent_normals=True,
                                auto_orient_normals=False)


def surface_of_loop(loop, phi0, phi1, npol=400, nphi=181):
    r, z, _ = resample_closed(loop, npol)
    return revolve_poly(np.append(r, r[0]), np.append(z, z[0]), np.linspace(phi0, phi1, nphi))


def isosurface_axisym(grid, F, level, phi0, phi1, nphi=181):
    """F = level for axisymmetric F: revolved contour lines; open lines that end
    at the axis are extended onto it so the surface closes."""
    meshes = []
    for ln in _contour_lines(grid, F, level):
        if len(ln) < 10:
            continue
        r, z = ln[:, 0], ln[:, 1]
        if r[0] < 3 * grid.dr:
            r, z = np.r_[0.0, r], np.r_[z[0], z]
        if r[-1] < 3 * grid.dr:
            r, z = np.r_[r, 0.0], np.r_[z, z[-1]]
        meshes.append(revolve_poly(r, z, np.linspace(phi0, phi1, nphi)))
    return meshes


def meridional_face(grid, F, phi, rmax, zlim, clipF, clipval):
    """Half-plane at azimuth phi carrying scalar F, clipped smoothly to clipF >= clipval."""
    pv = _pv()
    ir = grid.r <= rmax
    jz = (grid.z >= zlim[0]) & (grid.z <= zlim[1])
    R, Z = np.meshgrid(grid.r[ir], grid.z[jz], indexing="ij")
    sg = pv.StructuredGrid(R * np.cos(phi), R * np.sin(phi), Z)
    sg["F"] = F[np.ix_(ir, jz)].ravel(order="F")
    sg["C"] = clipF[np.ix_(ir, jz)].ravel(order="F")
    return sg.clip_scalar(scalars="C", value=clipval, invert=False)


def ring_on_face(pl, loop, phi, radius, color):
    pv = _pv()
    r, z, _ = resample_closed(loop, 500)
    pts = np.column_stack([r * np.cos(phi), r * np.sin(phi), z])
    pl.add_mesh(polyline(np.vstack([pts, pts[:1]])).tube(radius=radius, n_sides=10),
                color=color, smooth_shading=True)


def tube(pl, pts, radius, color=None, scalars=None, cmap=None, clim=None, opacity=1.0):
    pv = _pv()
    poly = polyline(pts)
    kw = dict(smooth_shading=True, specular=0.45, specular_power=25, opacity=opacity)
    if scalars is not None:
        poly["s"] = scalars
        pl.add_mesh(poly.tube(radius=radius, n_sides=12), scalars="s", cmap=cmap, clim=clim,
                    show_scalar_bar=False, **kw)
    else:
        pl.add_mesh(poly.tube(radius=radius, n_sides=12), color=color, **kw)


# =============================================================================
# 3-D scenes
# =============================================================================
FIELD_CMAP = "YlOrRd"
FLOW_COLORS = ["#34568b", "#2b8cc4", "#35b3a3", "#93d36a", "#f7c948"]
FLOW_VIEW = dict(az=-55.0, el=20.0, dist=16.5)
FIELD_VIEW = dict(az=-55.0, el=22.0)
OVER_VIEW = dict(az=-55.0, el=20.0)


def flow_cmap():
    from matplotlib.colors import LinearSegmentedColormap
    return LinearSegmentedColormap.from_list("flow", FLOW_COLORS)


def field_extent(grid, f, level=0.1):
    """(r_max, z_min, z_max) of the flux surface(s) Psi = level * Psi_max."""
    loops = closed_loops(grid, f["Psi"], level * f["Psi"].max())
    pts = np.vstack(loops)
    return pts[:, 0].max(), pts[:, 1].min(), pts[:, 1].max()


def o_points(grid, Psi, frac=0.3, merge=0.25):
    """Local maxima of Psi (magnetic O-lines) above frac * max, merging maxima that
    lie closer than `merge` (flat ridges).  Returns [(r, z, Psi)] sorted by Psi."""
    from scipy import ndimage
    mx = (Psi == ndimage.maximum_filter(Psi, size=9)) & (Psi > frac * Psi.max())
    cand = sorted(((Psi[i, j], grid.r[i], grid.z[j]) for i, j in zip(*np.nonzero(mx))), reverse=True)
    out = []
    for v, r, z in cand:
        if all(np.hypot(r - r2, z - z2) > merge for r2, z2, _ in out):
            out.append((r, z, v))
    return out


def field_distance(zlo, zhi):
    """Camera distance that fits the vertical range [zlo, zhi] (30 deg view angle)."""
    return 1.12 * (max(abs(zlo), abs(zhi)) + 0.45) / np.tan(np.deg2rad(15.0))


def scene_flow(pl, grid, f, az, clim=(0.0, 4.0), omega_iso=1.25, box=3.0,
               levels=(0.04, 0.12, 0.25, 0.42, 0.62, 0.82), per_level=2,
               line_radius=0.02, iso=True, frame=True, wedge=None):
    """Background flow U.  Streamlines lie on Stokes-streamfunction surfaces
    chi = r^2 S_U = const (one poloidal circuit each, both cells, clipped to the
    untapered region |r|, |z| < box), coloured by |U|.  Optional cut-away
    isosurface of the swirl angular velocity Omega_U."""
    pv = _pv()
    chi, OU = f["chi"], f["OU"]
    Umag = np.sqrt(f["Ur"]**2 + f["Uz"]**2 + f["Uphi"]**2)
    M = Meridional(grid, dict(Ur=(f["Ur"], -1), Uz=(f["Uz"], 1), OU=(OU, 1), U=(Umag, 1)))
    a = np.deg2rad(az)
    if iso and OU.max() > omega_iso:
        w = np.deg2rad(120.0)
        for m in isosurface_axisym(grid, OU, omega_iso, a + w / 2, a + 2 * np.pi - w / 2):
            pl.add_mesh(m, color="#9cc3e0", opacity=0.33, smooth_shading=True,
                        specular=0.3, ambient=0.3)
    cmap = flow_cmap()
    for sgn, ref in ((1.0, chi.max()), (-1.0, chi.min())):
        for li, lev in enumerate(levels):
            loops = closed_loops(grid, sgn * chi, lev * abs(ref))
            if not loops:
                continue
            loop = np.roll(loops[0], -np.argmax(loops[0][:, 0]), axis=0)   # start at outer edge
            for k in range(per_level):
                pts, _ = line_on_surface(loop, M, ("Ur", "Uz", "OU"), 1,
                                         phi0=a + np.pi + 2 * np.pi * k / per_level + 0.35 * li)
                mask = in_box(pts, box, box)
                if wedge is not None:
                    mask &= in_phi(pts, *wedge)
                for pc in _pieces(mask, pts, 25):
                    tube(pl, pc, line_radius, cmap=cmap, clim=clim,
                         scalars=M("U", np.hypot(pc[:, 0], pc[:, 1]), pc[:, 2]))
    pl.add_mesh(pv.Line((0, 0, -box - 0.3), (0, 0, box + 0.3)).tube(radius=0.012), color="#444444")
    if frame:
        th = np.linspace(0, 2 * np.pi, 240)
        for zz in (-box, box):
            ring = np.column_stack([box * np.cos(th), box * np.sin(th), np.full_like(th, zz)])
            pl.add_mesh(polyline(ring), color="#c4c4c4", line_width=1.5)


def scene_field(pl, grid, f, az, clim=(0.1, 12.0), levels=(0.1, 0.4, 0.75), cut_width=105.0,
                extent=None, log=True):
    """Magnetic field: nested flux surfaces Psi = const cut open towards the viewer,
    field lines on them, |B| on the two cut faces, and the magnetic O-line."""
    pv = _pv()
    Psi = f["Psi"]
    Pm = Psi.max()
    Bmag = np.sqrt(f["Br"]**2 + f["Bz"]**2 + f["Bphi"]**2)
    M = Meridional(grid, dict(Br=(f["Br"], -1), Bz=(f["Bz"], 1), q=(f["q"], 1)))
    rmax, zlo, zhi = extent if extent is not None else field_extent(grid, f, levels[0])
    a = np.deg2rad(az)
    ph0 = a + np.deg2rad(cut_width) / 2
    ph1 = ph0 + 2 * np.pi - np.deg2rad(cut_width)
    for ph in (ph0, ph1):
        pl.add_mesh(meridional_face(grid, Bmag, ph, rmax + 0.1, (zlo - 0.1, zhi + 0.1),
                                    Psi, levels[0] * Pm),
                    scalars="F", cmap=FIELD_CMAP, clim=clim, show_scalar_bar=False, log_scale=log,
                    ambient=0.55, diffuse=0.5, smooth_shading=True)
    surf, opac = ["#f3e3cf", "#e8a674", "#c24a3a"], [0.33, 0.6, 1.0]
    linec, nline = ["#1f3556", "#4a1512", "#2b0a09"], [8, 6, 4]
    for k, lev in enumerate(levels):
        for loop in closed_loops(grid, Psi, lev * Pm):          # one loop per lobe
            pl.add_mesh(surface_of_loop(loop, ph0, ph1), color=surf[k], opacity=opac[k],
                        smooth_shading=True, specular=0.3, specular_power=20, ambient=0.25)
            for ph in (ph0, ph1):
                ring_on_face(pl, loop, ph, 0.007, "#3a2a2a")
            for m in range(nline[k]):
                pts, _ = line_on_surface(loop, M, ("Br", "Bz", "q"), 1, phi0=2 * np.pi * m / nline[k])
                for pc in clip_phi(pts, ph0, ph1):
                    tube(pl, pc, 0.011, color=linec[k])
    for lev in (0.25, 0.55, 0.9):
        for loop in closed_loops(grid, Psi, lev * Pm):
            for ph in (ph0, ph1):
                ring_on_face(pl, loop, ph, 0.004, "#6b4f4f")
    th = np.linspace(0, 2 * np.pi, 400)
    for rO, zO, _ in o_points(grid, Psi):                       # magnetic O-lines
        tube(pl, np.column_stack([rO * np.cos(th), rO * np.sin(th), np.full_like(th, zO)]),
             0.01, color="black")
    pl.add_mesh(pv.Line((0, 0, zlo - 0.35), (0, 0, zhi + 0.35)).tube(radius=0.008), color="#444444")
    return ph0, ph1


def scene_overlay(pl, grid, f, az, box=2.2, cut_width=105.0, extent=None, uclim=(0.0, 4.0)):
    """Magnetic structure embedded in the background flow; flow lines are cut
    away in the same wedge as the flux surfaces."""
    a = np.deg2rad(az)
    ph0 = a + np.deg2rad(cut_width) / 2
    wedge = (ph0, ph0 + 2 * np.pi - np.deg2rad(cut_width))
    scene_flow(pl, grid, f, az, box=box, iso=False, frame=False, line_radius=0.012, clim=uclim,
               levels=(0.02, 0.05, 0.1, 0.18, 0.3, 0.45), per_level=3, wedge=wedge)
    scene_field(pl, grid, f, az, cut_width=cut_width, extent=extent)


def render(scene, cam, size, **kw):
    pv = _pv()
    pl = pv.Plotter(off_screen=True, window_size=size)
    pl.set_background("white")
    pl.enable_depth_peeling(number_of_peels=12)
    scene(pl, **kw)
    pl.camera_position = cam
    pl.camera.view_angle = 30.0
    pl.enable_anti_aliasing("ssaa")
    img = pl.screenshot(return_img=True)
    pl.close()
    return img


def autocrop(imgs, pad=14, thresh=250):
    """Crop RGB renders to their common non-white bounding box."""
    b = []
    for im in imgs:
        nz = np.argwhere((im[..., :3] < thresh).any(axis=-1))
        b.append((*nz.min(0), *nz.max(0)))
    b = np.array(b)
    r0, c0 = max(b[:, 0].min() - pad, 0), max(b[:, 1].min() - pad, 0)
    r1, c1 = b[:, 2].max() + pad, b[:, 3].max() + pad
    return [im[r0:r1, c0:c1] for im in imgs]


# =============================================================================
# Figure composition (matplotlib)
# =============================================================================
def _mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "DejaVu Serif", "mathtext.fontset": "dejavuserif",
                         "font.size": 11, "axes.linewidth": 0.8})
    return plt


def _colorbar(fig, rect, cmap, clim, label, log=False):
    import matplotlib as mpl
    ax = fig.add_axes(rect)
    norm = mpl.colors.LogNorm(*clim) if log else mpl.colors.Normalize(*clim)
    sm = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)
    cb = fig.colorbar(sm, cax=ax)
    cb.set_label(label, fontsize=12)
    cb.outline.set_linewidth(0.6)


def compose(rows, path, width=12.0, suptitle=None, caption=None, row_labels=None, dpi=200):
    """Lay out rendered panels.  rows = [[(image, title, cbars), ...], ...] where
    cbars is a list of (cmap, clim, label) drawn to the right of that panel.
    Panels in a row share one height; widths follow the image aspect ratios."""
    import textwrap
    plt = _mpl()
    left, right, gap, cbw, tpad = (0.5 if row_labels else 0.15), 0.1, 0.25, 1.05, 0.42
    heights = []
    for row in rows:
        asp = sum(im.shape[1] / im.shape[0] for im, _, _ in row)
        fixed = left + right + gap * (len(row) - 1) + sum(cbw for _, _, cb in row if cb)
        heights.append((width - fixed) / asp)
    top = 0.6 if suptitle else 0.1
    cap = textwrap.fill(caption, int(width * 15.0)) if caption else ""
    cap_h = (0.25 + 0.16 * (cap.count("\n") + 1)) if caption else 0.1
    H = top + sum(h + tpad for h in heights) + cap_h
    fig = plt.figure(figsize=(width, H), dpi=dpi)
    y = H - top
    for k, (row, h) in enumerate(zip(rows, heights)):
        y -= tpad + h
        x = left
        for im, title, cbars in row:
            w = h * im.shape[1] / im.shape[0]
            ax = fig.add_axes([x / width, y / H, w / width, h / H])
            ax.imshow(im, interpolation="lanczos")
            ax.set_axis_off()
            if title:
                ax.set_title(title, fontsize=14, pad=4)
            x += w
            if cbars:
                n = len(cbars)
                slot = 0.8 * h / n
                for m, cb in enumerate(cbars):
                    yb = y + 0.1 * h + (n - 1 - m) * slot + 0.1 * slot
                    _colorbar(fig, [(x + 0.08) / width, yb / H, 0.15 / width, 0.8 * slot / H], *cb)
                x += cbw
            x += gap
        if row_labels:
            fig.text(0.22 / width, (y + h / 2) / H, row_labels[k], rotation=90,
                     va="center", ha="center", fontsize=15)
    if suptitle:
        fig.text(0.5, 1 - 0.32 / H, suptitle, ha="center", va="center", fontsize=15)
    if caption:
        fig.text(0.15 / width, 0.12 / H, cap, fontsize=8.8, color="#333333", va="bottom")
    fig.savefig(path, dpi=dpi)
    plt.close(fig)


FLOW_CAPTION = (r"Background flow: streamlines lie on Stokes-streamfunction surfaces "
                r"$r^2S_U=\mathrm{const}$ (one poloidal circuit per line, both cells), clipped where "
                r"the taper begins (grey rings at $r=3$, $|z|=3$); blue: cut-away isosurface of the "
                r"swirl, $\Omega_U=1.25$.")
FIELD_CAPTION = (r"Magnetic field: flux surfaces $\Psi/\Psi_{\max}=0.10,0.40,0.75$ cut open toward "
                 r"the viewer, with field lines drawn on them; the cut faces show $|\mathbf{B}|$ and "
                 r"further $\Psi$ contours; black ring: magnetic O-line; grey line: symmetry axis.")


def _tau_title(tau):
    return rf"$\tau = {tau:.2f}$   ($t = {1 - tau:.2f}$)"


# =============================================================================
# Meridional and diagnostic figures
# =============================================================================
def _mirror(grid, F):
    return np.concatenate([F[::-1], F], axis=0), np.concatenate([-grid.r[::-1], grid.r])


def fig_meridional(grid, fs, path, p):
    plt = _mpl()
    fig, axes = plt.subplots(len(fs), 3, figsize=(14.5, 5.6 * len(fs)), dpi=170,
                             gridspec_kw=dict(width_ratios=[1.45, 1, 1]), constrained_layout=True)
    axes = np.atleast_2d(axes)
    Z = grid.z
    for row, f in enumerate(fs):
        tt = rf"$\tau={f['tau']:.2f}$"
        ax = axes[row, 0]
        OU, x = _mirror(grid, f["OU"])
        chi, _ = _mirror(grid, f["chi"])
        import matplotlib as mpl
        pc = ax.pcolormesh(x, Z, np.maximum(OU, 0.05).T, cmap="YlGnBu", shading="auto", rasterized=True,
                           norm=mpl.colors.LogNorm(0.1, 30.0))
        cm = max(chi.max(), -chi.min())
        ax.contour(x, Z, chi.T, levels=np.linspace(-0.95, 0.95, 20) * cm, colors="k", linewidths=0.6)
        ax.plot([-3, 3, 3, -3, -3], [-3, -3, 3, 3, -3], "--", color="#777777", lw=0.8)
        ax.set_xlim(-3.7, 3.7); ax.set_ylim(-3.7, 3.7)
        fig.colorbar(pc, ax=ax, shrink=0.8, label=r"$\Omega_U$")
        ax.set_title(tt + r":  $\Omega_U$ (colour), $r^2S_U$ (contours)", fontsize=11)

        ax = axes[row, 1]
        Bp, x = _mirror(grid, f["Bphi"])
        Psi, _ = _mirror(grid, f["Psi"])
        pc = ax.pcolormesh(x, Z, Bp.T, cmap="RdBu_r", vmin=-0.7, vmax=0.7, shading="auto", rasterized=True)
        ax.contour(x, Z, Psi.T, levels=np.linspace(0.05, 0.95, 10) * Psi.max(), colors="k", linewidths=0.7)
        ax.set_xlim(-1.3, 1.3); ax.set_ylim(-2.7, 2.7)
        fig.colorbar(pc, ax=ax, shrink=0.8, label=r"$B_\phi$")
        ax.set_title(tt + rf":  $B_\phi$, $\Psi$ contours ($\Psi_{{\max}}={Psi.max():.4f}$)", fontsize=11)

        ax = axes[row, 2]
        v = np.sqrt(f["vr"]**2 + f["vz"]**2 + f["vphi"]**2)
        if v.max() > 0:
            vm, x = _mirror(grid, v)
            chv, _ = _mirror(grid, grid.rc**2 * f["S"])
            pc = ax.pcolormesh(x, Z, vm.T, cmap="PuBuGn", vmin=0, vmax=v.max(), shading="auto",
                               rasterized=True)
            lv = max(chv.max(), -chv.min())
            ax.contour(x, Z, chv.T, levels=np.linspace(-0.9, 0.9, 10) * lv, colors="k", linewidths=0.6)
            fig.colorbar(pc, ax=ax, shrink=0.8, label=r"$|\mathbf{v}|$", format="%.1e")
            ax.set_title(tt + r":  response $|\mathbf{v}|$, $r^2S$ contours", fontsize=11)
        else:
            ax.text(0.5, 0.5, r"$\mathbf{v}\equiv 0$ (initial condition)", ha="center",
                    va="center", transform=ax.transAxes, fontsize=12)
            ax.set_title(tt + r":  response flow $\mathbf{v}$", fontsize=11)
        ax.set_xlim(-1.3, 1.3); ax.set_ylim(-2.7, 2.7)
        for c, ax in enumerate(axes[row]):
            ax.set_aspect("equal")
            ax.set_xlabel(r"$r$ (mirrored)")
            if c == 0:
                ax.set_ylabel(r"$z$")
    fig.get_layout_engine().set(wspace=0.06)
    fig.savefig(path, dpi=170)
    plt.close(fig)


def fig_diagnostics(outdir, path, p):
    plt = _mpl()
    with open(os.path.join(outdir, "diagnostics.csv")) as fh:
        rows = list(csv.DictReader(fh))
    d = {k: np.array([float(r[k]) for r in rows]) for k in rows[0]}
    tau, t = d["tau"], d["t"]
    Hint = d["H"][0] + np.concatenate([[0.0], np.cumsum(0.5 * (d["dHdt_res"][1:] + d["dHdt_res"][:-1])
                                                         * np.diff(t))])
    fig, ax = plt.subplots(2, 2, figsize=(11.5, 7.8), dpi=170, constrained_layout=True)
    a = ax[0, 0]
    a.plot(tau, d["H"] / d["H"][0], "k-", lw=1.8, label=r"$H/H_0$")
    a.plot(tau, Hint / d["H"][0], "--", color="#d9480f", lw=1.4,
           label=r"$1-2\eta\int\!\!\int \mathbf{B}\cdot\mathbf{J}\,dV\,dt\,/H_0$")
    a.set_ylabel("magnetic helicity")
    a.legend(frameon=False, fontsize=9, loc="upper right")
    b = a.twinx()
    b.plot(tau, (d["H"] - Hint) / abs(d["H"][0]), color="#1c7ed6", lw=1.0)
    b.set_ylabel(r"$(H - H_0 + 2\eta\int\!\!\int\mathbf{B}\cdot\mathbf{J})/H_0$", color="#1c7ed6")
    b.tick_params(axis="y", colors="#1c7ed6")
    a.set_title("(a) helicity and its resistive balance (S1.56)", fontsize=11)

    a = ax[0, 1]
    a.plot(tau, d["M"] / d["M"][0], "k-", lw=1.8, label=r"$M/M_0$")
    a.plot(tau, d["Bmax"], "-", color="#c92a2a", lw=1.4, label=r"$\max|\mathbf{B}|$")
    a.set_ylabel("magnetic energy, field strength")
    a.legend(frameon=False, fontsize=9)
    a.set_title("(b) flux compression by the inflow", fontsize=11)

    a = ax[1, 0]
    ratio = np.where(d["Umax"] > 0, d["vmax"] / d["Umax"], np.nan)
    a.semilogy(tau[1:], ratio[1:], "k-", lw=1.8, label=r"$\max|\mathbf{v}|/\max|\mathbf{U}|$")
    a.semilogy(tau[1:], d["K"][1:] / d["M"][0], "-", color="#6741d9", lw=1.4, label=r"$K/M_0$")
    a.set_ylabel("response amplitude")
    a.legend(frameon=False, fontsize=9)
    a.set_title(rf"(c) back-reaction, $\epsilon_B={p.eps_b:g}$", fontsize=11)

    a = ax[1, 1]
    a.plot(tau, d["Psi_max"], "k-", lw=1.8, label=r"$\max\Psi$")
    a.axhline(d["Psi_max"][0], color="#888888", ls=":", lw=1.0, label=r"bound $\max\Psi(0)$")
    a.set_ylabel(r"$\Psi=r^2P$")
    b = a.twinx()
    b.plot(tau, d["Psi_min"], color="#1c7ed6", lw=1.0)
    b.set_ylabel(r"$\min\Psi$ (exactly $\geq 0$)", color="#1c7ed6")
    b.tick_params(axis="y", colors="#1c7ed6")
    a.legend(frameon=False, fontsize=9, loc="lower left")
    a.set_title("(d) maximum principle for the poloidal flux", fontsize=11)
    nr = d.get("nr")
    ref = [] if nr is None else [tau[k] for k in range(1, len(nr)) if nr[k] != nr[k - 1]]
    for a in ax.ravel():
        a.set_xlim(1.0, tau.min())
        a.set_xlabel(r"$\tau = 1 - t$")
        for tr in ref:
            a.axvline(tr, color="#999999", ls=":", lw=1.0)
    if ref:
        ax[0, 1].text(ref[0], ax[0, 1].get_ylim()[1], f"  grid {int(nr[0])}→{int(nr[-1])}",
                      va="top", fontsize=8, color="#666666")
    fig.savefig(path, dpi=170)
    plt.close(fig)


# =============================================================================
# Driver
# =============================================================================
def make_figures(p, outdir, do3d=True, taus=None):
    g = Grid(p)
    fs = []
    for tg in (taus or (1.0, p.tau_end)):
        st, tau = load_snapshot(g, os.path.join(outdir, f"snapshot_tau{tg:.2f}.npz"))
        fs.append(derived(g, st, tau))
    fig_diagnostics(outdir, os.path.join(outdir, "fig_diagnostics.png"), p)
    fig_meridional(g, fs, os.path.join(outdir, "fig_meridional.png"), p)
    print("2-D figures written", flush=True)
    if not do3d:
        return
    try:
        _pv()
    except ImportError:
        print("pyvista is not installed: skipping the 3-D figures (pip install pyvista)")
        return
    t0 = time.time()
    fv, bv, ov = FLOW_VIEW, FIELD_VIEW, OVER_VIEW
    ext = [field_extent(g, f) for f in fs]
    common = (max(e[0] for e in ext), min(e[1] for e in ext), max(e[2] for e in ext))
    umax = max(np.sqrt(f["Ur"]**2 + f["Uz"]**2 + f["Uphi"]**2).max() for f in fs)
    bmax = max(np.sqrt(f["Br"]**2 + f["Bz"]**2 + f["Bphi"]**2).max() for f in fs)
    uclim = (0.0, float(np.ceil(umax)))
    bclim = (0.1, float(max(3.0, np.ceil(1.1 * bmax))))
    cbU = (flow_cmap(), uclim, r"$|\mathbf{U}|$")
    cbB = (FIELD_CMAP, bclim, r"$|\mathbf{B}|$ (cut faces)", True)

    flows, fields_common = [], []
    for f in fs:
        flows.append(render(scene_flow, camera(fv["az"], fv["el"], fv["dist"]), (1300, 1150),
                            grid=g, f=f, az=fv["az"], clim=uclim))
        fields_common.append(render(scene_field,
                                    camera(bv["az"], bv["el"], field_distance(common[1], common[2])),
                                    (1000, 1350), grid=g, f=f, az=bv["az"], extent=common, clim=bclim))
    flows = autocrop(flows)
    fields_common = autocrop(fields_common)

    # per-time figures: flow | field (field camera fitted to that time)
    for f, e, flow in zip(fs, ext, flows):
        field = autocrop([render(scene_field, camera(bv["az"], bv["el"], field_distance(e[1], e[2])),
                                 (1000, 1350), grid=g, f=f, az=bv["az"], extent=e, clim=bclim)])[0]
        compose([[(flow, r"(a) background flow $\mathbf{U}$", [cbU]),
                  (field, r"(b) magnetic field $\mathbf{B}$", [cbB])]],
                os.path.join(outdir, f"fig3d_tau{f['tau']:.2f}.png"), width=13.0,
                suptitle=_tau_title(f["tau"]) + rf",   $\eta=\nu={p.eta:g}$,  $\epsilon_B={p.eps_b:g}$",
                caption="(a) " + FLOW_CAPTION + "  (b) " + FIELD_CAPTION)

    # evolution figure: one column per time, identical cameras and colour scales
    n = len(fs)
    compose([[(flows[k], _tau_title(fs[k]["tau"]), [cbU] if k == n - 1 else None) for k in range(n)],
             [(fields_common[k], None, [cbB] if k == n - 1 else None) for k in range(n)]],
            os.path.join(outdir, "fig3d_evolution.png"), width=5.0 * n + 1.5,
            row_labels=[r"background flow $\mathbf{U}$", r"magnetic field $\mathbf{B}$"],
            caption="Top: " + FLOW_CAPTION + "  Bottom: " + FIELD_CAPTION
            + "  All columns use the same camera and colour scales.")

    # overlay: the field inside the flow
    for f, e in zip(fs, ext):
        box = max(2.2, max(abs(e[1]), abs(e[2])) + 0.3)
        dist = max(12.5, 1.3 * field_distance(e[1], e[2]))
        img = autocrop([render(scene_overlay, camera(ov["az"], ov["el"], dist), (1500, 1500),
                               grid=g, f=f, az=ov["az"], extent=e, box=box, uclim=uclim)])[0]
        compose([[(img, None, [cbU, cbB])]],
                os.path.join(outdir, f"fig3d_overlay_tau{f['tau']:.2f}.png"), width=9.5,
                suptitle="Magnetic structure inside the collapsing flow,  " + _tau_title(f["tau"]),
                caption=rf"Coloured tubes: background streamlines (clipped to $r,|z|<{box:.1f}$ and cut "
                        r"in the same wedge as the flux surfaces). Flux surfaces, field lines and cut "
                        r"faces as in the field panels.")
    print(f"3-D figures written ({time.time() - t0:.0f} s)", flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--outdir", default="mhd_out")
    ap.add_argument("--nr", type=int, default=Params.nr)
    ap.add_argument("--nz", type=int, default=Params.nz)
    ap.add_argument("--tau-end", type=float, default=Params.tau_end)
    ap.add_argument("--eps-b", type=float, default=Params.eps_b)
    ap.add_argument("--eta", type=float, default=Params.eta)
    ap.add_argument("--nu", type=float, default=Params.nu)
    ap.add_argument("--tau-f", type=float, default=Params.tau_f,
                    help="bounded-collapse control: tau_eff = sqrt(tau^2 + tau_f^2)")
    ap.add_argument("--continue-from", metavar="DIR",
                    help="start from a snapshot of the run in DIR (interpolated if the grid differs)")
    ap.add_argument("--continue-tau", type=float, default=None,
                    help="snapshot time to continue from (default: that run's tau_end)")
    ap.add_argument("--resume", action="store_true", help="resume from outdir/checkpoint.npz")
    ap.add_argument("--max-wall", type=float, default=None,
                    help="stop after this many seconds, writing a checkpoint")
    ap.add_argument("--diag-every", type=int, default=1, help="diagnostics every N steps")
    ap.add_argument("--fig-taus", type=float, nargs="*", default=None,
                    help="snapshot times shown in the figures (default: 1.0 and tau_end)")
    ap.add_argument("--plot-only", action="store_true", help="re-plot saved snapshots")
    ap.add_argument("--no-3d", action="store_true", help="only the 2-D figures")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    pfile = os.path.join(args.outdir, "params.json")
    if args.plot_only or args.resume:
        with open(pfile) as fh:
            p = Params(**json.load(fh))
        if args.resume:
            p.tau_end = min(p.tau_end, args.tau_end) if args.tau_end != Params.tau_end else p.tau_end
    else:
        p = Params(nr=args.nr, nz=args.nz, tau_end=args.tau_end, eps_b=args.eps_b,
                   eta=args.eta, nu=args.nu, tau_f=args.tau_f)
        with open(pfile, "w") as fh:
            json.dump(asdict(p), fh, indent=1)
    done = True
    if not args.plot_only:
        cont = None
        if args.continue_from and not args.resume:
            with open(os.path.join(args.continue_from, "params.json")) as fh:
                tau_src = args.continue_tau or Params(**json.load(fh)).tau_end
            cont = prepare_continuation(p, args.outdir, args.continue_from, tau_src)
        _, done = run(p, args.outdir, cont=cont, resume=args.resume, max_wall=args.max_wall,
                      diag_every=args.diag_every)
    if done:
        make_figures(p, args.outdir, do3d=not args.no_3d, taus=args.fig_taus)


if __name__ == "__main__":
    raise SystemExit("Use python3 leiren_bigbox_vs3b.py (the checked vs3b driver).")
