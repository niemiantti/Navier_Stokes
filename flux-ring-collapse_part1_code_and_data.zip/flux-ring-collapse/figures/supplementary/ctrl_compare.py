"""Compare the symmetry/twist control runs with the reference eps_B = 50, eta = 0.05 run: split time, side and ratio of
the birth (fission_metrics of the production code), the cusp statistic (beta, ratio) over the first 15 records deeper
than 5e-4, and the asymmetry diagnostics of asym.py."""
import sys, os, json, glob, numpy as np
from paths import *
os.chdir(CODE)
import leiren_bigbox_vs3b as drv
from silib import tracks_of, resolve
import cuspfit as Cf
def cusp_stat(tr, ts, dmin=5e-4, k=15):
    rr = []
    for q in tr:
        if q["t"] < ts - 1e-9: continue
        c = sorted(q["cps"], key=lambda x: x["z"])
        for i, x in enumerate(c):
            if x["kind"] == "X" and 0 < i < len(c) - 1:
                lo, hi = c[i - 1], c[i + 1]; d1, d2 = lo["psi"] - x["psi"], hi["psi"] - x["psi"]
                if min(d1, d2) >= dmin:
                    z1, z2, z3 = lo["z"], x["z"], hi["z"]; m = (z1 + z2 + z3) / 3; y1, y2, y3 = z1 - m, z2 - m, z3 - m
                    e2 = y1 * y2 + y1 * y3 + y2 * y3; e3 = y1 * y2 * y3; a = -e2; b = e3
                    rr.append(dict(t=q["t"], beta=abs(b) / a**1.5 if a > 0 else np.nan, ratio=min(d1, d2) / max(d1, d2), zX=z2, znew=(z1 if d1 < d2 else z3), zold=(z3 if d1 < d2 else z1)))
                    break
        if len(rr) >= k: break
    return rr
def report(name, tr):
    fm = drv.fission_metrics(tr)
    ts = fm["t_s"]; rr = cusp_stat(tr, ts)
    print(f"{name:>28s}: t_s={ts:.4f}  z_birth(saddle)={fm['z_birth']:+.3f}  ratio={fm['island_ratio']:.3f}  type={fm['type']}  | cusp: beta={np.median([q['beta'] for q in rr]):.3f} ratio={np.median([q['ratio'] for q in rr]):.3f} new axis at z={np.median([q['znew'] for q in rr]):+.3f}, old at {np.median([q['zold'] for q in rr]):+.3f}")
    return dict(name=name, t_s=ts, z_birth=fm["z_birth"], ratio=fm["island_ratio"], type=fm["type"], beta=float(np.median([q["beta"] for q in rr])), ratio15=float(np.median([q["ratio"] for q in rr])), znew=float(np.median([q["znew"] for q in rr])), zold=float(np.median([q["zold"] for q in rr])))
out = [report("reference (j=0.001, sigma=-1)", tracks_of(50, 0.05))]
for d in sorted(glob.glob(DATA + "/controls/symmetry/CTRL_*/")):
    if os.path.exists(d + "tracks.json"):
        tr = json.load(open(d + "tracks.json"))
        if tr: out.append(report(os.path.basename(d.rstrip("/")), tr))
json.dump(out, open(HERE + "/ctrl_compare.json", "w"), indent=1)
