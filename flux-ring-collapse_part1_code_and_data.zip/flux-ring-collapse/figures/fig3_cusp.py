"""Figure 3 at 183 mm: the cusp behind the splits. (a) the normal form, (b, c) the measured ridge profiles at t = 0.9
(data/derived/fig3_ridge_profiles_t0.9.csv), (d) the parameter-free test from the critical-point tracks, with the
spread over the 15-record window."""
import sys, os, glob, json, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); os.makedirs(HERE + "/out", exist_ok=True)
from style import plt, MM, WIDTH, C_ETA, letter
sys.path.insert(0, os.path.join(HERE, "..", "analysis")); import cuspfit as Cf
import csv

# ------------------------------------------------------------------ the ridge profiles at t = 0.9 of panels b, c
PROF = {}
for r in csv.DictReader(open(HERE + "/data/derived/fig3_ridge_profiles_t0.9.csv")):
    PROF.setdefault((float(r["eta"]), int(r["eps_B"])), []).append((float(r["z"]), float(r["ridge_over_Psi_max"])))
PROF = {k: np.array(v) for k, v in PROF.items()}
B_EPS = (50, 100, 200, 300, 500); C_EPS = (10, 50, 200, 500, 1000)
# the three curves of panel a: (a, b) of the normal form Psi(x) = -x^4/4 + a x^2/2 + b x
NF = {"before": (-0.6, 0.0), "pitchfork": (0.5, 0.0), "fold": (0.5, 0.12)}

# ------------------------------------------------------------------ the test, from the tracks
pts = []
for d in sorted(glob.glob(HERE + "/data/results/*/")):
    if "LRref" in d or "d87ab6" in d: continue
    s = json.load(open(d + "data/summary.json")); p = json.load(open(d + "data/params.json"))
    ts = (s.get("split") or {}).get("t_s")
    if ts is None: continue
    rows = Cf.tracks_beta(json.load(open(d + "data/tracks.json")), t_window=(ts - 0.001, ts + 0.06), dmin=5e-4)[:15]
    b = np.array([r["beta"] for r in rows]); q = np.array([r["ratio"] for r in rows])
    # islands on the ridge at the first record of the window (deeper than 2e-4 of the peak flux): one for a single-quartic
    # pinch, several where the ridge is already flat and rippled when the split is first resolved
    q0 = min((x for x in json.load(open(d + "data/tracks.json")) if abs(x["t"] - rows[0]["t"]) < 1e-9), key=lambda x: 0)
    c = sorted(q0["cps"], key=lambda x: x["z"]); pm = max(x["psi"] for x in c)
    nisl = sum(1 for i, x in enumerate(c) if x["kind"] == "X" and 0 < i < len(c) - 1 and min(c[i - 1]["psi"], c[i + 1]["psi"]) - x["psi"] > 2e-4 * pm)
    pts.append(dict(eps=p["eps_b"], eta=p["eta"], beta=np.median(b), ratio=np.median(q), b25=np.percentile(b, 25), b75=np.percentile(b, 75),
                    q25=np.percentile(q, 25), q75=np.percentile(q, 75), nisl=nisl, t0=rows[0]["t"], t1=rows[-1]["t"]))
LATE = {(100, 0.01), (200, 0.01), (300, 0.01), (500, 0.01)}       # late splits of the flat sheet: resolution-sensitive
RIPPLED = {(int(q["eps"]), q["eta"]) for q in pts if q["nisl"] > 1}
print("births on a rippled ridge:", sorted(RIPPLED), "; window lengths %.3f-%.3f" % (min(q["t1"] - q["t0"] for q in pts), max(q["t1"] - q["t0"] for q in pts)))
assert RIPPLED == {(50, 0.01), (100, 0.01), (200, 0.01), (300, 0.01), (500, 0.01), (1000, 0.05)}
for q in pts: print(f"eps={q['eps']:>5g} eta={q['eta']:<5g} islands={q['nisl']} beta={q['beta']:.3f} [{q['b25']:.3f},{q['b75']:.3f}] ratio={q['ratio']:.3f} [{q['q25']:.3f},{q['q75']:.3f}] R={Cf.cusp_ratio(q['beta']):.3f}")

fig = plt.figure(figsize=(WIDTH, 124 * MM))
W3 = 0.255; H1 = 0.27; Y1 = 0.665
axa = fig.add_axes([0.065, Y1, W3, H1]); axb = fig.add_axes([0.395, Y1, W3, H1]); axc = fig.add_axes([0.725, Y1, W3, H1])
# a
zz = np.linspace(-1.6, 1.6, 400)
for key, lc in (("before", "#868e96"), ("pitchfork", C_ETA[0.01]), ("fold", C_ETA[0.05])):
    a_, b_ = NF[key]
    f = -zz**4 / 4 + a_ * zz**2 / 2 + b_ * zz
    axa.plot(zz, f - f.max(), color=lc, lw=1.1)
axa.set_xlim(-1.6, 1.6); axa.set_ylim(-0.7, 0.17); axa.set_xlabel(r"$x$ along the ridge (normal-form units)"); axa.set_ylabel(r"$\Psi(x)-\Psi_{\max}$")
axa.set_yticks([-0.6, -0.4, -0.2, 0.0])
axa.text(0.0, -0.36, "before the\npinch, " + r"$a<0$", color="#868e96", ha="center", va="center", fontsize=7)
axa.text(-0.75, 0.025, r"pitchfork, $b=0$", color=C_ETA[0.01], ha="center", va="bottom", fontsize=7)
axa.text(0.85, 0.025, r"fold, $b\neq0$", color=C_ETA[0.05], ha="center", va="bottom", fontsize=7)
letter(axa, "a", r"normal form $\Psi(x)=-x^4/4+ax^2/2+bx$", x=-0.22, y=1.03)
# b, c
import matplotlib
EPSCOL = {e: matplotlib.colormaps["plasma"](x) for e, x in zip((10, 50, 100, 200, 300, 500, 1000), (0.04, 0.2, 0.36, 0.5, 0.62, 0.74, 0.86))}
for ax, eps_list, eta, lab in ((axb, B_EPS, 0.01, "b"), (axc, C_EPS, 0.05, "c")):
    for e in eps_list:
        xy = PROF[(eta, e)]; ax.plot(xy[:, 0], xy[:, 1], color=EPSCOL[e], lw=1.0, label=(rf"$\epsilon_B$ = {e}" if e == eps_list[0] else f"{e}"))
    ax.set_ylim(0.3, 1.03); ax.set_xlabel(r"height $z$"); ax.set_ylabel(r"$\max_r\Psi(r,z)\,/\,\Psi_{\max}$")
    letter(ax, lab, rf"ridge at $t$ = 0.9, $\eta$ = {eta}", x=-0.22, y=1.03)
axb.set_xlim(-2.3, 2.3); axc.set_xlim(-2.3, 2.3)
for ax in (axb, axc):
    ax.legend(loc="upper center", bbox_to_anchor=(0.45, -0.25), ncol=5, handlelength=0.9, columnspacing=0.7, handletextpad=0.3)
# d
axd = fig.add_axes([0.065, 0.08, 0.52, 0.375])
bb = np.linspace(0, Cf.BETA_FOLD, 300); axd.plot(bb, [Cf.cusp_ratio(x) for x in bb], "k-", lw=1.2, zorder=2)
LABOFF = {(1, 0.05): (-9, -7), (1, 0.01): (5, 1), (3, 0.05): (5, 1), (10, 0.05): (6, 1), (10, 0.01): (5, 2), (20, 0.05): (-13, -9),
          (50, 0.05): (5, -3), (100, 0.05): (-6, -12), (200, 0.05): (-8, -11), (300, 0.05): (6, 3), (500, 0.05): (5, 2), (1000, 0.05): (-8, -11),
          (500, 0.01): (-19, -9), (50, 0.01): (5, 1), (100, 0.01): (6, 0), (200, 0.01): (-17, 3), (300, 0.01): (-10, 6)}
for q in pts:
    key = (int(q["eps"]), q["eta"]); rip = key in RIPPLED; late = key in LATE; col = C_ETA[q["eta"]]
    axd.plot([q["b25"], q["b75"]], [q["ratio"]] * 2, "-", color=col, lw=0.5, alpha=0.45, zorder=1)
    axd.plot([q["beta"]] * 2, [q["q25"], q["q75"]], "-", color=col, lw=0.5, alpha=0.45, zorder=1)
    axd.plot(q["beta"], q["ratio"], "s" if rip else "o", ms=(5.4 if late else 4.6) if rip else 4.4, mfc="white" if late else col, mec=col if late else "k",
             mew=0.9 if late else 0.5, zorder=3 if rip else 4)
    dx, dy = LABOFF.get(key, (4, 2))
    axd.annotate(f"{q['eps']:g}", (q["beta"], q["ratio"]), xytext=(dx, dy), textcoords="offset points", fontsize=7, color=col)
axd.set_xlim(0, 0.40); axd.set_ylim(0, 1.0)
axd.set_xlabel(r"asymmetry $\beta=|b|/a^{3/2}$ from the positions of the three critical points")
axd.set_ylabel("island-depth ratio from their flux values")
letter(axd, "d", "the measured ratio against the cusp prediction", x=-0.115, y=1.02)
GREY = "#868e96"
h = [plt.Line2D([], [], color="k", lw=1.2, label=r"cusp normal form $R(\beta)$, no free parameter"),
     plt.Line2D([], [], color=GREY, marker="o", mec="k", mew=0.5, ms=4.4, lw=0, label="single island on the ridge at the birth"),
     plt.Line2D([], [], color=GREY, marker="s", mec="k", mew=0.5, ms=4.6, lw=0, label="ridge already carrying several shallow\nislands at the birth"),
     plt.Line2D([], [], color=GREY, marker="s", mfc="white", mew=0.9, ms=5.4, lw=0, label="the same, and a late split at $\\eta$ = 0.01\n(resolution-sensitive)")]
fig.legend(handles=h, loc="upper left", bbox_to_anchor=(0.62, 0.45), frameon=False, labelspacing=0.45)
fig.text(0.62, 0.215, "Colour: $\\eta$ = 0.05 (red), $\\eta$ = 0.01 (blue).\nNumbers: $\\epsilon_B$. Points: medians over the first\n15 records after the birth in which the new\n"
         "island is deeper than $5\\times10^{-4}\\,\\Psi_{\\max}$; bars: their\ninterquartile range.", fontsize=7.2, va="top")
out = HERE + "/out/Fig3.pdf"; fig.savefig(out); fig.savefig(out.replace(".pdf", ".png"), dpi=300); print("written", out)
