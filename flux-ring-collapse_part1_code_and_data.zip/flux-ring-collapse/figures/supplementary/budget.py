"""Time-integrated energy and helicity budget closure of an axisymmetric production run.

Re-integrates a production configuration with the production code (version 3b.2, the same RK3 loop, time-step rule
and event times as the driver) from t0 to t1, evaluating every `every` steps the energies, the helicity and the rates
of the budgets of Supplementary Note 5, with the same discrete operators:

    dK/dt = P_ext + W_L - D_nu,   dM/dt = -W_L - D_eta,   dE/dt = P_ext - D_nu - D_eta,   dH/dt = -2 eta int J.B dV

The residuals  R_K, R_M, R_E, R_H  are the differences between the stored quantities and the time integrals of the rates
(trapezoid rule between evaluations).  Output: budget_<label>.csv with one row per evaluation.

usage: python3 budget.py <eps_b> <eta> <t0> <t1> <every> <label>
       t0 = 0 starts from the seed; otherwise the state is reconstructed from the snapshot light_t<t0>.npz of the run
       under data/raw/<run>/ (the runs write them; they are not part of the repository).
"""
import sys, os, json, time, csv, glob, numpy as np
from paths import *
os.chdir(CODE)
import openai_mhd_3d as mhd, configuration as cfg, checks
import leiren_bigbox_vs3b as drv

eps_b, eta, t0, t1, every, label = float(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4]), int(sys.argv[5]), sys.argv[6]
OUT = HERE                                           # the archived results are in data/budgets/
# --- the production configuration of this run
runs = []
for d in glob.glob(RES + "*/data/params.json"):
    pj = json.load(open(d))
    if abs(pj["eps_b"] - eps_b) < 1e-9 and abs(pj["eta"] - eta) < 1e-9:
        runs.append((os.path.dirname(d), pj))
runs.sort()
rdir, old = runs[0]
raw = {k: v for k, v in old.items() if k not in cfg.GENERATED and k in cfg.DEFAULTS}
d = cfg.finish_params(raw)
diffs = {k: (d[k], old[k]) for k in cfg.DEFAULTS if k not in cfg.OPERATIONAL and k in old and d[k] != old[k]}
assert not diffs, diffs
print("run", old["name"], "physical parameters reproduced; version", d.get("version"), "vs", old.get("version"), flush=True)
p = cfg.make_params(d); g = mhd.Grid(p)
r = g.rc

# --- initial state
if t0 == 0.0:
    P0, q0 = mhd.spheromak_seed(p, g)
    state = [np.zeros_like(P0), np.zeros_like(P0), P0, q0]
    handed = False
else:
    name = os.path.basename(rdir)
    cands = glob.glob(RAW + f"{name}/light_t{t0:.9f}.npz") + glob.glob(RAW + f"{name}/full_t{t0:.9f}.npz")
    f = np.load(cands[0]); assert abs(float(f["t"]) - t0) < 1e-9
    handed = t0 >= d["t_off"] - 1e-12
    p.t_off = d["t_off"] if handed else 1e99; p.U_scale = 1.0
    bg = g.background_terms(1 - t0)
    S_v = f["chi"].astype(np.float64) / r**2 - bg["SU"]
    state = [-g.L5(g.pad(S_v)), f["Omega"].astype(np.float64) - bg["OU"], f["Psi"].astype(np.float64) / r**2, f["Bphi"].astype(np.float64) / r]
    print("state reconstructed from", cands[0], flush=True)

# --- events (same as the driver: light snapshots, full snapshots, the release), only to clip the time step
t_end = t1
ld = d["light_dt"]
lights = {round(i * ld, 12) for i in range(int(np.ceil(d["t_start"] / ld)), int(np.floor(d["t_end"] / ld)) + 1)} | {d["t_start"], d["t_end"]}
fulls = set(drv.full_times(d))
events = sorted(lights | fulls | {d["t_end"]} | {d["t_off"]})

def phase(t, handed):
    drv.set_background_phase(p, t, d, handed)

def rates(state, t, handed):
    """energies, helicity and the budget rates at a state"""
    phase(t, handed)
    tau = 1 - t
    fd = mhd.derived(g, state, tau)
    Ur, Uz, Ut = fd["Ur"], fd["Uz"], fd["Uphi"]
    ur, uz, ut = Ur + fd["vr"], Uz + fd["vz"], Ut + fd["vphi"]
    Br, Bz, Bt = fd["Br"], fd["Bz"], fd["Bphi"]
    Jr, Jz, Jt = fd["Jr"], fd["Jz"], fd["Jphi"]
    dV = g.dV
    K = 0.5 * float(np.sum((ur**2 + uz**2 + ut**2) * dV))
    M = 0.5 * p.eps_b * float(np.sum((Br**2 + Bz**2 + Bt**2) * dV))
    H = 4.0 * np.pi * float(np.sum((g.r**3)[:, None] * fd["P"] * fd["q"])) * g.dr * g.dz
    rg = checks.component_pad(g, ur, "r"); zg = checks.component_pad(g, uz, "z"); tg = checks.component_pad(g, ut, "phi")
    Dnu = p.nu * float(np.sum((g.ddr(rg)**2 + g.ddz(rg)**2 + g.ddr(zg)**2 + g.ddz(zg)**2 + g.ddr(tg)**2 + g.ddz(tg)**2
                               + (ur**2 + ut**2) / r**2) * dV))
    J2 = float(np.sum((Jr**2 + Jz**2 + Jt**2) * dV))
    Deta = p.eps_b * p.eta * J2
    JxB_r = Jt * Bz - Jz * Bt; JxB_t = Jz * Br - Jr * Bz; JxB_z = Jr * Bt - Jt * Br
    WL = p.eps_b * float(np.sum((ur * JxB_r + ut * JxB_t + uz * JxB_z) * dV))
    JB = float(np.sum((Jr * Br + Jz * Bz + Jt * Bt) * dV))
    if handed or p.U_scale == 0:
        Pext = pure = KU = dKU = DnuU = 0.0
    else:
        b = checks.background_power(g, p, tau, state)
        Pext, pure, KU, dKU, DnuU = b["Pext"], b["pure_power_balance_residual"], b["KU"], b["dKU_dt"], b["dissipation"]
    return dict(t=t, K=K, M=M, E=K + M, H=H, Pext=Pext, WL=WL, Dnu=Dnu, Deta=Deta, JB=JB, pure=pure, KU=KU, dKU=dKU, DnuU=DnuU,
                phase=(1 if handed else 0))

rows = []
acc = dict(IK=0.0, IM=0.0, IE=0.0, IH=0.0, Ipure=0.0, IDnu=0.0, IDeta=0.0)   # time integrals of the rates
last = None
def record(state, t, handed):
    global last
    q = rates(state, t, handed)
    if last is not None:
        dt = q["t"] - last["t"]
        f = lambda a, b: 0.5 * dt * (a + b)
        acc["IK"] += f(last["Pext"] + last["WL"] - last["Dnu"], q["Pext"] + q["WL"] - q["Dnu"])
        acc["IM"] += f(-last["WL"] - last["Deta"], -q["WL"] - q["Deta"])
        acc["IE"] += f(last["Pext"] - last["Dnu"] - last["Deta"], q["Pext"] - q["Dnu"] - q["Deta"])
        acc["IH"] += f(-2 * p.eta * last["JB"], -2 * p.eta * q["JB"])
        acc["Ipure"] += f(last["pure"], q["pure"]); acc["IDnu"] += f(last["Dnu"], q["Dnu"]); acc["IDeta"] += f(last["Deta"], q["Deta"])
    q.update(acc)
    q.update(RK=q["K"] - rows[0]["K"] - acc["IK"] if rows else 0.0,
             RM=q["M"] - rows[0]["M"] - acc["IM"] if rows else 0.0,
             RE=q["E"] - rows[0]["E"] - acc["IE"] if rows else 0.0,
             RH=q["H"] - rows[0]["H"] - acc["IH"] if rows else 0.0)
    rows.append(q); last = q
    return q

def dump():
    keys = list(rows[0])
    with open(f"{OUT}/budget_{label}.csv", "w") as fh:
        fh.write(",".join(keys) + "\n")
        for q in rows:
            fh.write(",".join(f"{q[k]:.16g}" for k in keys) + "\n")

# --- integrate (the driver's loop)
t = t0; step = 0
D = max(p.nu, p.eta); dt_diff = p.diff_frac * 2.51 / (D * g.lam_max) if D > 0 else float("inf")
record(state, t, handed)
wall = time.time()
while t < t_end - 1e-12:
    phase(t, handed)
    k1, aux = drv.rhs_at(g, state, t, d)
    adv = float(np.max(np.abs(aux["Vr"]) / g.dr + np.abs(aux["Vz"]) / g.dz + np.sqrt(p.eps_b) * aux["Babs"] * (1 / g.dr + 1 / g.dz)))
    nxt = min((e for e in events if e > t + 1e-12), default=t_end); nxt = min(nxt, t_end)
    rate = adv / p.cfl + (1 / dt_diff if np.isfinite(dt_diff) else 0.0)
    dt = min(1 / rate if rate > 0 else d["dt_max"], d["dt_max"], nxt - t)
    u1 = [s + dt * k for s, k in zip(state, k1)]
    k2, _ = drv.rhs_at(g, u1, t + dt, d)
    u2 = [.75 * s + .25 * (s1 + dt * k) for s, s1, k in zip(state, u1, k2)]
    k3, _ = drv.rhs_at(g, u2, t + .5 * dt, d)
    new = [s / 3. + 2. / 3. * (s2 + dt * k) for s, s2, k in zip(state, u2, k3)]
    newt = t + dt
    if abs(newt - nxt) < 1e-11: newt = nxt
    state, t, step = new, newt, step + 1
    phase(t, handed)
    released = False
    if d["mode"] == "sudden" and abs(t - d["t_off"]) < 1e-12 and not handed:
        record(state, t, handed)                       # just before the release
        bt = g.background_terms(1 - t)
        state = [state[0] - g.L5(g.pad(bt["SU"])), state[1] + bt["OU"], state[2], state[3]]
        handed = True; phase(t, handed); released = True
        q = record(state, t, handed)                   # just after
        print(f"RELEASE at t={t}: K {rows[-2]['K']:.7g} -> {q['K']:.7g}, M {rows[-2]['M']:.7g} -> {q['M']:.7g}", flush=True)
    if step % every == 0 and not released:
        record(state, t, handed)
    if step % 100 == 0:
        q = rows[-1]
        print(f"t={t:.6f} step={step} dt={dt:.3e} K={q['K']:.6g} M={q['M']:.6g} H={q['H']:.6g} RE={q['RE']:.3e} RH={q['RH']:.3e} [{time.time()-wall:.0f}s]", flush=True)
        dump()
record(state, t, handed)
dump()
q = rows[-1]
print(f"DONE t={t:.6f} steps={step} K={q['K']:.6g} M={q['M']:.6g} H={q['H']:.6g} RE={q['RE']:.4e} RH={q['RH']:.4e} E0={rows[0]['E']:.6g} H0={rows[0]['H']:.6g} [{time.time()-wall:.0f}s]", flush=True)
