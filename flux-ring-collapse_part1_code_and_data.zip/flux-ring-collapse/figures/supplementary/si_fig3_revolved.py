"""Supplementary Figure 3: four outcomes of the axisymmetric runs as revolved flux surfaces, coloured by the toroidal
field, at the release and at two later times (eps_B = 1, eta = 0.05; 50, 0.01; 1000, 0.05; 1000, 0.01).
Inputs: the snapshots of these runs under data/raw/<run>/ (light_t*.npz or full_t*.npz), which the runs write and
which are not part of the repository; the rings are found with persistence_rings of the production driver.
usage: python3 si_fig3_revolved.py [snapshot root, default data/raw]"""
from paths import *
import glob, numpy as np, contourpy, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.colors import TwoSlopeNorm
from scipy.interpolate import RegularGridInterpolator
from leiren_bigbox_vs3b import persistence_rings
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
root = sys.argv[1] if len(sys.argv) > 1 else RAW

def rawdir(eps, eta):
    g = glob.glob(f"{root}/LR_e{eps}_eta{eta}_unconfined_*")
    return g[0] if g else f"{root}/legacy_geometry_unconfined_d87ab6fa32e4"
def fname(d, t):
    cands = [f"{d}/light_t{t:.9f}.npz", f"{d}/full_t{t:.9f}.npz", f"{d}/full_t{t:.9f}_before_release.npz", f"{d}/full_t{t:.9f}_after_release.npz"]
    if abs(t - 1.0) < 1e-9: cands += [f"{root}/legacy_geometry_unconfined_d5fc336787c6/full_t1.000000000_before_release.npz",
                                      f"{root}/legacy_geometry_unconfined_d5fc336787c6/full_t1.000000000_after_release.npz"]
    for f in cands:
        if glob.glob(f): return f
    return None
RUNS = [(1, 0.05, "a", r"$\epsilon_B=1,\ \eta=0.05$: passive doublet", (1.0, 2.0, 4.0)),
        (50, 0.01, "b", r"$\epsilon_B=50,\ \eta=0.01$: doublet with an island chain", (1.0, 2.0, 4.0)),
        (1000, 0.05, "c", r"$\epsilon_B=1000,\ \eta=0.05$: triplet", (1.0, 2.4, 4.0)),
        (1000, 0.01, "d", r"$\epsilon_B=1000,\ \eta=0.01$: no split, single ring", (1.0, 2.0, 4.0))]
PHI0, PHI1 = 0.0, 1.55 * np.pi
def loop_around(r, z, Psi, level, point):
    gen = contourpy.contour_generator(r, z, Psi.T); best = None
    for seg in gen.lines(level):
        if len(seg) > 8 and Path(seg).contains_point(point) and (best is None or len(seg) < len(best)): best = seg
    return best
def render(ax, fn, t):
    F = np.load(fn); r, z = F["r"], F["z"]; Psi = F["Psi"].astype(float); Bp = F["Bphi"].astype(float)
    interp = RegularGridInterpolator((r, z), Bp, bounds_error=False, fill_value=0.0)
    rings = persistence_rings(Psi, r, z, 4.5)
    im = np.unravel_index(np.argmax(Psi), Psi.shape); main = (float(r[im[0]]), float(z[im[1]]))
    items = [dict(point=main, depth=1.0, kind="main")] + [dict(point=(q["r"], q["z"]), depth=q["depth"], kind=("ring" if q["depth"] >= 0.05 else "remnant")) for q in rings if q["depth"] >= 0.05]
    vmax = max(np.abs(Bp).max(), 1e-12); norm = TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax); cmap = plt.get_cmap("RdBu_r")
    phi = np.linspace(PHI0, PHI1, 64)
    m = Psi > 0.05 * Psi.max(); ii, jj = np.nonzero(m); rlim = float(r[ii].max()) + 0.4; zlim = float(np.abs(z[jj]).max()) + 0.4
    for it in items:
        pO = Psi[np.argmin(abs(r - it["point"][0])), np.argmin(abs(z - it["point"][1]))]
        if it["kind"] == "main":
            pl = max([q["depth"] for q in rings if q["depth"] >= 0.05] + [0.0])
            levels = [pO * 0.65, pO * 0.35] if pl < 0.3 else [pO - 0.35 * pl * Psi.max(), pO - 0.7 * pl * Psi.max()]
        else:
            dep = it["depth"] * Psi.max(); levels = [pO - 0.4 * dep, pO - 0.8 * dep]
        for k, lev in enumerate(levels):
            seg = loop_around(r, z, Psi, lev, it["point"])
            if seg is None: continue
            rr, zz = seg[:, 0], seg[:, 1]
            X = rr[:, None] * np.cos(phi)[None, :]; Y = rr[:, None] * np.sin(phi)[None, :]; Z = np.repeat(zz[:, None], len(phi), axis=1)
            fc = np.repeat(cmap(norm(interp(np.c_[rr, zz])))[:, None, :], len(phi), axis=1)
            if it["kind"] == "remnant": fc[..., 3] = 0.35
            ax.plot_surface(X, Y, Z, facecolors=fc, rstride=2, cstride=2, linewidth=0, antialiased=False, shade=True, alpha=(0.95 if k else 0.55))
    ax.set_xlim(-rlim, rlim); ax.set_ylim(-rlim, rlim); ax.set_zlim(-zlim, zlim); ax.set_box_aspect((2 * rlim, 2 * rlim, 2 * zlim), zoom=1.12)
    ax.view_init(elev=18, azim=-55); ax.set_axis_off()
    ax.text2D(0.03, 0.03, f"$t$ = {t:.1f}" + ("  (before release)" if t == 1.0 else "") + f"\nbox $r<{rlim:.1f}$, $|z|<{zlim:.1f}$", transform=ax.transAxes, fontsize=8)
fig = plt.figure(figsize=(12.5, 17.5))
for i, (eps, eta, lab, title, times) in enumerate(RUNS):
    d = rawdir(eps, eta)
    for j, t in enumerate(times):
        ax = fig.add_subplot(4, 3, 3 * i + j + 1, projection="3d")
        fn = fname(d, t)
        if fn is None: ax.set_axis_off(); print(f"eps_B = {eps}, eta = {eta}, t = {t}: no snapshot"); continue
        render(ax, fn, t)
        if j == 0: ax.text2D(-0.02, 1.02, f"{lab}  " + title, transform=ax.transAxes, fontsize=10.5, fontweight="bold")
fig.subplots_adjust(left=0.0, right=1.0, top=0.97, bottom=0.0, wspace=0.0, hspace=0.12)
out = OUT + "/si_fig3_revolved.png"; fig.savefig(out, dpi=110); print("written", out)
