# Run configurations

`axisymmetric/<run>/params.json` is the complete parameter file of each production run and `preflight.txt` the
report printed before the time integration (energies of the imposed flow and the seed, the resolution check).
The eighteen runs of the paper are the seventeen `LR_e<eps_B>_eta<eta>_unconfined_*` runs and the eps_B = 1000,
eta = 0.05 run, which predates the `LR_` naming and was computed in two parts: `legacy_geometry_unconfined_d5fc336787c6`
from t = 0 to 1.5 and its `--extend` continuation `legacy_geometry_unconfined_d87ab6fa32e4` from t = 1.5 to 4
(`parent_run` and `parent_t` in its parameter file), whose tracks carry the full history. `axisymmetric_runs.csv`
lists them. The suffix of a run name is the first twelve characters of the SHA-256 of its configuration.

`three_dimensional/<run>/config.json` are the configurations of the two 3D runs of the paper (eps_B = 50,
eta = 0.01 in the box |x|, |y| < 4, |z| < 5.5, and eps_B = 1000, eta = 0.05 in |x|, |y| < 5, |z| < 7, both 256^3, t = 0
to 4) and of the extension of the first to t = 8 in the larger box (Supplementary Note 7, Supplementary Movie 3).

`controls/` holds the configurations of the control runs of the Supplementary Information (the data are in
`../data/controls/`):

| directory | run | where used |
|---|---|---|
| `symmetry/CTRL_j0_e50_eta0.05` | eps_B = 50, eta = 0.05 without the offset (j = 0) | Supplementary Note 2, Table 3, Fig. 4 |
| `symmetry/CTRL_twist_e50_eta0.05` | the same with the twist of the seed reversed (sigma = +1) | Supplementary Note 2, Table 3, Fig. 4 |
| `symmetry/CTRL_sym_e1_eta0.05` | eps_B = 1, eta = 0.05 without offset and swirl, the exact pitchfork | Supplementary Note 2, Table 3 |
| `refinement/CTRL_fine_e50_eta0.05_512x1365` | the fold at eps_B = 50, eta = 0.05 on 512 x 1365 cells, to t = 0.5 | Supplementary Note 3, Table 4; Methods |
| `release/ctrl_sudden_e1000_eta0.05` | restart of the eps_B = 1000, eta = 0.05 run at t = 0.9 with the sudden release, to t = 2.5 | Supplementary Note 5 |
| `release/ramp005_e1000_eta0.05` | the same with the force switched off smoothly over 0.05, to t = 2.5, continued to t = 3.25 | Supplementary Note 5; Methods |

The `config.json` of a control holds its parameters under `parameters` with the code and configuration hashes. The
configuration of the 512 x 1365 repeat is given as `params.json` (the physical parameters of the production run with
`nr = 512`, `nz = 1365`, `t_end = 0.5`); the archived data of that repeat are the author's run of this configuration.
The 512 x 1365 repeat of the eps_B = 100, eta = 0.01 run to t = 4 (Supplementary Table 4, lower block) has the same
parameters as that production run with `nr = 512`, `nz = 1365`; its data are held by the author.

Reproduce a run with

    python3 axisymmetric/leiren_bigbox_vs3b.py --params runs/axisymmetric/<run>/params.json
    python3 three_dimensional/mhd3d_vs2.py --preset e50_eta0.01      # or --set key=value for any entry of config.json

and the release-protocol tests with `figures/supplementary/restart.py` from the full snapshot at t = 0.9 that the
eps_B = 1000, eta = 0.05 run writes.
