# Analysis

- `cuspfit.py`: fits the pinch of the flux ridge to the cusp normal form -x^4/4 + a x^2/2 + b x, either from ridge
  profiles in snapshots (`python3 cuspfit.py frames <snapshot.npz> ...`) or from the critical-point tracks after the
  birth of the second axis (`python3 cuspfit.py tracks <tracks.json> ...`), returning beta = |b|/a^{3/2} from the
  positions and the island-depth ratio from the flux values. Used by Fig. 3d and by the Supplement scripts.
- `simp.py`: persistence simplification of the critical points along the ridge (removes O–X pairs shallower than a
  threshold), used to check the sequence of folds at eps_B = 1000 and the island counts.
- `oisl.py`: depth of every axis above the higher of its adjacent saddles (the island depths of Fig. 2h).
- `verify/`: the scripts with which every number quoted in the paper was re-derived from the data in `data/`
  (split times, depth ratios, the cusp test and its windows, ring histories and outcomes, helicity and energy
  ratios, the agreement of the three-dimensional runs, the index sum of every run). They are kept as they were
  used; each runs in a few seconds from this directory (`python3 verify/v_index.py`, and so on) and prints its
  comparison.

The critical-point tracking, the ring counting (union-find over the levels of Psi) and the split-time diagnostic are
part of the driver `axisymmetric/leiren_bigbox_vs3b.py` (functions `track`, `persistence_rings`, `fission_metrics`).
